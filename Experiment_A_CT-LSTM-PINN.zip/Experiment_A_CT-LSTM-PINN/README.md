# Experiment A — CT-LSTM-PINN

Experiment A compares seven models on three manufactured flows. The Taylor–Green
vortex (`case1_tgv`) and steady cavity (`case2_mms_cavity`) predict horizontal
velocity, vertical velocity and pressure. The Rayleigh–Bénard case (`case3_rbc`)
also predicts temperature.

CT-LSTM-PINN applies two LSTM layers of width 192 to the scalar coordinates of
one point in order: `x, y, t` for the transient cases and `x, y` for the steady
cavity. The state is reset for each point. Each case includes CT-LSTM-PINN,
PINN, Param-PINN, ResAtten-PINN, DP-PINN, Causal-PINN and PirateNet.
Each script configures 80,000 training updates with seed 0.

From the extracted directory, run the script for the desired case and model
with Python, NumPy, PyTorch and Matplotlib installed. For example:

```sh
python case1_tgv/train_ct-lstm.py
```

The CT-LSTM-PINN scripts write to their configured `LSTM-PINN` output directories.
