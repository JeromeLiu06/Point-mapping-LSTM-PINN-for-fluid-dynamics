"""Compatibility launcher for the 12 VR-LSTM-PINN jobs."""
from train_all_lstm import main


if __name__ == "__main__":
    main(default_models=("lstm1",))
