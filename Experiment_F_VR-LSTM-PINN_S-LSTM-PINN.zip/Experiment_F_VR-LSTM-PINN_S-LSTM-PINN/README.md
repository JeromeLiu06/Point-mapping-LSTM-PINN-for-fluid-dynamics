# Experiment F — VR-LSTM-PINN and S-LSTM-PINN

Experiment F compares the two state policies on Cases I–IV with model seeds
0, 1 and 2. The run matrix lists 24 runs of 80,000 optimizer updates.

| CLI model | Manuscript name | State policy |
| --- | --- | --- |
| `lstm1` | VR-LSTM-PINN | Evaluate each complete coordinate vector in a single LSTM step with fresh zero state. |
| `lstm2` | S-LSTM-PINN | Process the same coordinate vectors as ordered four-point windows and carry state within each window. |

Both models use the same class, input embedding (3 → 192), two recurrent
layers of width 192, dropout 0, and a 192 → 192 → output head with tanh.
A model has 631,299 trainable parameters for three outputs and 631,492 for
the four-output thermal case. Their frozen training and evaluation data,
sampler seed, loss weights, Adam settings, gradient clipping, and update
budget are shared. The PDE loss is evaluated at all four physical positions
in each sampled window under both state policies.

## Run from the extracted directory

Install NumPy and a CUDA-enabled PyTorch build as in `requirements.txt`.
The package includes its four input files under `data/locked/`. The launcher
checks their SHA-256 values against the case configurations.

```sh
python train_all_lstm.py --list
python train_all_lstm.py --check-inputs
python train_all_lstm.py --smoke-test --device cuda:0
python train_all_lstm.py --case case3_rbc --model lstm2 --seed 0 --device cuda:0
python train_all_lstm.py --device cuda:0
```

The smoke command runs one update for each case and both models at seed 0.
Smoke results default to `smoke_results/`. Full runs default to `results/`.
Use `--output-root` for another destination, or `--data-root` for
byte-identical copies of the frozen inputs. For a CPU smoke check, add
`--device cpu --allow-cpu` in place of the CUDA device option.

For PowerShell, `scripts/run_all_24.ps1` launches the complete matrix.
`scripts/run_one.ps1 -Case case3_rbc -Seed 0 -Model lstm2` launches one
S-LSTM run. `train_all_vr_lstm.py` and `scripts/run_all_12.ps1` remain
available for VR-only runs. The four `train_case*.py` files also accept
either model key.

## Evaluation

Case III uses a 120 × 120 grid at times 0, 0.5, 1, 1.5 and 2. Case IV
uses the audited FEM v4 velocity reference sampled on the 129 × 129 grid.
Pressure remains an output used by the PDE in Case IV, while saved
reference fields and errors use velocity.

For the paper's mean relative L2, take the arithmetic mean of the
per-field `metrics.field.<field>.relative_l2` values in
`metrics/final_metrics.json`. The trainer's `aggregate.primary` records
a joint norm. The package contains the verified inputs, launcher and code
for reruns. `SMOKE_TEST.json` records short-run validation, and
`SOURCE_PROVENANCE.json` and `MANIFEST.sha256` identify the sources and
contents of this release.
