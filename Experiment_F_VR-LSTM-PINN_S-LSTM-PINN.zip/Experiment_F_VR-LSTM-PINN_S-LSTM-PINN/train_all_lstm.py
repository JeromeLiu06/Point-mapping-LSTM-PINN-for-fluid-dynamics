"""Launch Experiment F (VR-LSTM-PINN and S-LSTM-PINN)."""
from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path
import subprocess
import sys

from experiment_c.config import (
    CASE_FILES, MODEL_NAMES, PACKAGE_ROOT as ROOT, dataset_path, load_case,
    load_protocol, sha256_file,
)


def read_jobs() -> list[dict[str, str]]:
    with (ROOT / "configs/run_matrix.csv").open(encoding="utf-8", newline="") as handle:
        jobs = list(csv.DictReader(handle))
    protocol = load_protocol()
    identities = [(r["case"], r["model"], int(r["model_seed"])) for r in jobs]
    expected = {
        (case, model, seed)
        for case in CASE_FILES for model in MODEL_NAMES for seed in protocol["model_seeds"]
    }
    if len(identities) != len(expected) or set(identities) != expected:
        raise RuntimeError("Run matrix must contain every Experiment F case, model, and seed once")
    for row in jobs:
        for key in ("iterations", "data_seed", "sampler_seed"):
            if int(row[key]) != protocol[key]:
                raise RuntimeError(f"Run {row['run_id']} disagrees with the protocol for {key}")
    return jobs


def check_inputs(cases: list[str], data_root: Path | None) -> None:
    for case in dict.fromkeys(cases):
        cfg = load_case(case)
        path = data_root / Path(cfg["dataset"]).name if data_root else dataset_path(cfg)
        if not path.is_file():
            raise FileNotFoundError(
                f"Missing frozen input: {path}. Use the included data/locked directory "
                "or specify a byte-identical copy with --data-root."
            )
        actual = sha256_file(path)
        if actual.lower() != cfg["dataset_sha256"].lower():
            raise RuntimeError(f"Dataset hash mismatch for {case}: expected {cfg['dataset_sha256']}, got {actual}")
        print(f"INPUT PASS {case}: {path}", flush=True)


def main(default_models: tuple[str, ...] = MODEL_NAMES) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=tuple(CASE_FILES), action="append", help="Repeat to select cases")
    parser.add_argument("--model", choices=default_models, action="append", help="Repeat to select models")
    parser.add_argument("--seed", choices=tuple(load_protocol()["model_seeds"]), type=int, action="append",
                        help="Repeat to select seeds; smoke tests default to seed 0")
    parser.add_argument("--data-root", type=Path, help="External folder containing the four original frozen .npz files")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-root", type=Path, default=ROOT / "results")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--list", action="store_true", help="Show jobs without loading PyTorch, data, or starting training")
    parser.add_argument("--check-inputs", action="store_true", help="Check input SHA-256 and exit without training")
    parser.add_argument("--smoke-test", action="store_true", help="One update per selected run; separate smoke_results output")
    parser.add_argument("--allow-cpu", action="store_true", help="Permit CPU smoke tests only")
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args()
    selected_seeds = args.seed
    if args.smoke_test and selected_seeds is None:
        selected_seeds = [0] if default_models == MODEL_NAMES else None
    jobs = [
        row for row in read_jobs()
        if row["model"] in (args.model or default_models)
        and (args.case is None or row["case"] in args.case)
        and (selected_seeds is None or int(row["model_seed"]) in selected_seeds)
    ]
    data_root = args.data_root.expanduser().resolve() if args.data_root else None
    if data_root is None and os.environ.get("VR_LSTM_DATA_ROOT"):
        data_root = Path(os.environ["VR_LSTM_DATA_ROOT"]).expanduser().resolve()
    if args.list:
        print("lstm1 = VR-LSTM-PINN, lstm2 = S-LSTM-PINN")
        for i, r in enumerate(jobs, 1):
            steps = 1 if args.smoke_test else int(r["iterations"])
            print(f"{i:02d}/{len(jobs):02d} case={r['case']} model={r['model']} seed={r['model_seed']} iterations={steps}")
        return
    check_inputs([r["case"] for r in jobs], data_root)
    if args.check_inputs:
        return
    if args.device.startswith("cpu") and not (args.smoke_test and args.allow_cpu):
        parser.error("CPU is supported only with --smoke-test --allow-cpu; the 80000-update campaign uses CUDA")
    output_root = args.output_root.expanduser().resolve()
    if args.smoke_test and output_root == (ROOT / "results").resolve():
        output_root = ROOT / "smoke_results"
    env = os.environ.copy()
    env.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if data_root:
        env["VR_LSTM_DATA_ROOT"] = str(data_root)
    for i, r in enumerate(jobs, 1):
        command = [
            args.python, str(ROOT / f"train_{r['case']}.py"),
            "--model", r["model"], "--seed", r["model_seed"], "--device", args.device,
            "--output-root", str(output_root), "--iterations",
            "1" if args.smoke_test else r["iterations"],
        ]
        if args.no_resume:
            command.append("--no-resume")
        if args.allow_cpu:
            command.append("--allow-cpu")
        print(f"RUN {i}/{len(jobs)}: {r['case']} {r['model']} seed={r['model_seed']}", flush=True)
        subprocess.run(command, cwd=ROOT, env=env, check=True)


if __name__ == "__main__":
    main()
