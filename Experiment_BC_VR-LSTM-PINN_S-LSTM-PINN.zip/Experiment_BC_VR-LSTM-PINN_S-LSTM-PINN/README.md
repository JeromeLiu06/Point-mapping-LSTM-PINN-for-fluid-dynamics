# Experiments B and C — VR-LSTM-PINN and S-LSTM-PINN

| Experiment | Flow cases | Models | Updates per run | Model seed |
|---|---|---|---:|---:|
| B | IV, unforced lid-driven cavity at Re = 100 | VR-LSTM-PINN, S-LSTM-PINN, Param-PINN, PINN | 40,000 | 1 |
| C | I–IV, Taylor–Green vortex, manufactured cavity, manufactured Rayleigh–Bénard convection and unforced lid-driven cavity | VR-LSTM-PINN, S-LSTM-PINN, Param-PINN, RNN-PINN | 80,000 | 0 |

VR-LSTM-PINN embeds the coordinates of each point as one vector and resets the
recurrent state for each point. S-LSTM-PINN carries the state across a
four-point window. Both have two LSTM layers of width 192 and use Adam at a
learning rate of 0.0001. The data and sampling seeds are 0. The training CLI
accepts `lstm1` for VR-LSTM-PINN, `lstm2` for S-LSTM-PINN, `param` for
Param-PINN, `pinn` for PINN and `rnn` for RNN-PINN.

## Training

Install the packages in `requirements.txt`. For Case IV, also extract
`Case4_FEM.zip` next to this package. From this package directory:

```sh
python -m epjplus_bc B --case 4 --model lstm1 --device cuda --fem-reference ../Case4_FEM_v4/levels/N256/velocity_reference_grid.npz --output runs/B/VR-LSTM-PINN
python -m epjplus_bc B --case 4 --model lstm2 --device cuda --fem-reference ../Case4_FEM_v4/levels/N256/velocity_reference_grid.npz --output runs/B/S-LSTM-PINN
python -m epjplus_bc C --case 1 --model lstm1 --device cuda --output runs/C/CaseI/VR-LSTM-PINN
```

All Experiment B models default to 40,000 optimizer updates. S-LSTM-PINN
uses four spatial points per window in this steady case. All Experiment C
models default to 80,000 updates and use the four datasets in `datasets/`.
Use `--steps` to set an explicit update count for diagnostics.

## Case IV results

The networks predict u, v and p. The Case IV comparison averages the separate
relative L2 errors of u and v against the N=256 FEM reference on the native
evaluation grid (120 × 120 in B, 129 × 129 in C). Speed is derived from u and v.
The updated B archive gives **0.149376** for VR-LSTM-PINN and **0.950722**
for S-LSTM-PINN at 40,000 updates. Their training histories are in
`archive/experiment_B_40k/`. To recompute the eight B/C velocity scores:

```sh
python reevaluate_case4.py --fem-reference ../Case4_FEM_v4/levels/N256/velocity_reference_grid.npz --output case4_metrics.json
```
