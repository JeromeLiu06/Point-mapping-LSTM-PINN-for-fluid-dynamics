"""CT-LSTM-PINN: case3_rbc, seed 0, formal budget 80,000 updates."""
from experiment_g.cli import main

if __name__ == "__main__":
    main(default_case="case3_rbc", default_seed=0)
