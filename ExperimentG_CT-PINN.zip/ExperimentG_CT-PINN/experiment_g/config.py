from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
CASE_FILES = {
    "case1_tgv": "case1_tgv.json", "case2_mms_cavity": "case2_mms_cavity.json",
    "case3_rbc": "case3_rbc.json", "case4_cavity_fem": "case4_cavity_fem.json",
}
MODEL_NAMES = ("ct_lstm",)


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_protocol() -> dict[str, Any]:
    return read_json(PACKAGE_ROOT / "configs/protocol.json")


def load_case(case: str) -> dict[str, Any]:
    return read_json(PACKAGE_ROOT / "configs/cases" / CASE_FILES[case])


def dataset_path(case_config: dict[str, Any]) -> Path:
    return PACKAGE_ROOT / case_config["dataset"]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_manifest() -> dict[str, str]:
    files = []
    for root in (PACKAGE_ROOT / "experiment_g", PACKAGE_ROOT / "configs"):
        files.extend(p for p in root.rglob("*") if p.is_file() and p.suffix in {".py", ".json"})
    files.extend(PACKAGE_ROOT.glob("train*.py"))
    return {p.relative_to(PACKAGE_ROOT).as_posix(): sha256_file(p) for p in sorted(set(files))}


def source_fingerprint(manifest: dict[str, str]) -> str:
    value = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(value).hexdigest()
