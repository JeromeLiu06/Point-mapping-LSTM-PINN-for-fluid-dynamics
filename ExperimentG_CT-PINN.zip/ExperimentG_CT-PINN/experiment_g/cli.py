from __future__ import annotations

import argparse
from contextlib import redirect_stdout, redirect_stderr
from pathlib import Path
import sys

from .config import CASE_FILES, PACKAGE_ROOT, load_case, load_protocol
from .trainer import run_training


class Tee:
    def __init__(self, console, log):
        self.console, self.log = console, log

    def write(self, value):
        self.console.write(value)
        self.log.write(value)
        self.log.flush()
        return len(value)

    def flush(self):
        self.console.flush()
        self.log.flush()


def main(default_case: str | None = None, default_seed: int | None = None) -> None:
    parser = argparse.ArgumentParser(description="Experiment G: CT-LSTM-PINN, four cases x seeds 0/1/2")
    if default_case is None:
        parser.add_argument("--case", choices=tuple(CASE_FILES), required=True)
    else:
        parser.set_defaults(case=default_case)
    if default_seed is None:
        parser.add_argument("--seed", choices=(0, 1, 2), type=int, required=True)
    else:
        parser.set_defaults(seed=default_seed)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-root", type=Path, default=None)
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--smoke", action="store_true", help="Diagnostic short run; never use for paper tables")
    parser.add_argument("--iterations", type=int, default=None, help="Only available with --smoke (1..10)")
    args = parser.parse_args()
    if args.iterations is not None and not args.smoke:
        parser.error("Formal runs are fixed at 80,000 updates; --iterations requires --smoke")
    if args.smoke and not 1 <= (args.iterations or 1) <= 10:
        parser.error("Smoke iterations must be between 1 and 10")
    if args.device == "cpu" and not args.smoke:
        parser.error("CPU is allowed only for smoke diagnostics")
    root = args.output_root or PACKAGE_ROOT / ("_smoke_results" if args.smoke else "results_G")
    output = root / args.case / "ct_lstm" / f"seed_{args.seed}"
    output.mkdir(parents=True, exist_ok=True)
    (output / "logs").mkdir(exist_ok=True)
    with (output / "logs/console.stdout.log").open("a", encoding="utf-8") as outlog, \
         (output / "logs/console.stderr.log").open("a", encoding="utf-8") as errlog, \
         redirect_stdout(Tee(sys.stdout, outlog)), redirect_stderr(Tee(sys.stderr, errlog)):
        run_training(
            case_config=load_case(args.case), protocol=load_protocol(), model_name="ct_lstm",
            model_seed=args.seed, output_dir=output, device_name=args.device,
            iterations=(args.iterations or 1) if args.smoke else None,
            resume=not args.no_resume, allow_cpu=args.smoke,
        )
