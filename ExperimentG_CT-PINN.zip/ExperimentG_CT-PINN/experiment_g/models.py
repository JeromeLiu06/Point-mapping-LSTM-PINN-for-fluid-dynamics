from __future__ import annotations

import torch
from torch import nn


class CoordinateTokenLSTMPINN(nn.Module):
    """Independent physical points; recurrence only over x/y[/t] scalars."""

    def __init__(self, output_dim: int, coordinate_dim: int, hidden: int = 192, layers: int = 2):
        super().__init__()
        if coordinate_dim not in (2, 3):
            raise ValueError("CT requires 2 (steady) or 3 (transient) scalar coordinates")
        self.coordinate_dim = coordinate_dim
        self.embedding = nn.Linear(1, hidden)
        self.core = nn.LSTM(hidden, hidden, num_layers=layers, batch_first=True, dropout=0.0)
        self.head = nn.Sequential(nn.Linear(hidden, hidden), nn.Tanh(), nn.Linear(hidden, output_dim))

    def forward(self, coordinates: torch.Tensor) -> torch.Tensor:
        if coordinates.ndim != 3 or coordinates.shape[-1] != 3:
            raise ValueError("Expected [batch, physical_tokens, 3] coordinates")
        # Keep the same four-position outer loop as archived VR. Only the
        # within-point scalar sequence differs; physical points never share h/c.
        scalar_tokens = coordinates[..., :self.coordinate_dim].unsqueeze(-1)
        embedded = self.embedding(scalar_tokens)
        token_outputs = []
        for token in range(coordinates.shape[1]):
            # Omitted (h0,c0) is zero for each physical point. State propagates
            # only over this point's x/y[/t] scalar tokens.
            with torch.backends.cudnn.flags(enabled=False):
                hidden, _ = self.core(embedded[:, token, :, :])
            token_outputs.append(hidden[:, -1:, :])
        return self.head(torch.cat(token_outputs, dim=1))


def build_model(model_name: str, output_dim: int, protocol: dict, *, case: str) -> nn.Module:
    if model_name != "ct_lstm":
        raise ValueError("This package trains CT-LSTM-PINN only")
    config = protocol["models"][model_name]
    return CoordinateTokenLSTMPINN(
        output_dim, len(config["coordinate_tokens"][case]),
        int(config["hidden_width"]), int(config["recurrent_layers"]),
    )


def parameter_count(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def expected_parameter_count(model_name: str, output_dim: int, protocol: dict) -> int:
    return int(protocol["expected_parameter_counts"][f"output_dim_{output_dim}"][model_name])
