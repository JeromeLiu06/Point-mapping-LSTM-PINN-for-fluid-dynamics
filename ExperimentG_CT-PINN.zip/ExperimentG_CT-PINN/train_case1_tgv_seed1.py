"""CT-LSTM-PINN: case1_tgv, seed 1, formal budget 80,000 updates."""
from experiment_g.cli import main

if __name__ == "__main__":
    main(default_case="case1_tgv", default_seed=1)
