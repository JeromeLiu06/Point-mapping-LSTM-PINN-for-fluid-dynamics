"""CT-LSTM-PINN: case4_cavity_fem, seed 0, formal budget 80,000 updates."""
from experiment_g.cli import main

if __name__ == "__main__":
    main(default_case="case4_cavity_fem", default_seed=0)
