"""CT-LSTM-PINN: case2_mms_cavity, seed 1, formal budget 80,000 updates."""
from experiment_g.cli import main

if __name__ == "__main__":
    main(default_case="case2_mms_cavity", default_seed=1)
