from experiment_c.cli import main

if __name__ == "__main__":
    main(default_case="case4_cavity_fem")

