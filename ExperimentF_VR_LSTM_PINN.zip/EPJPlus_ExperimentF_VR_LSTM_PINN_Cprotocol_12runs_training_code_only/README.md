# VR-LSTM-PINN: Experiment F using the archived C protocol

This is a **training-code-only** package for four cases and three initialization seeds (0, 1, 2): **12 runs**. The manuscript name VR-LSTM-PINN maps to the original source key `lstm1`. It resets the hidden and cell states before each token.

## Included

- The four original `train_case*.py` entry points.
- Original model, PDE, sampler, training, and per-run evaluation code in `experiment_c/`.
- Original numerical protocol and all four case configurations.
- A filtered 12-run matrix and VR-only Python/PowerShell launchers.
- Dependency requirements, input-file references, and source/checksum information.

There are **no frozen datasets, weights, checkpoints, prediction arrays, logs, training results, plots, or result-aggregation scripts** in this archive. The original shared `models.py` and `protocol.json` are kept byte-for-byte; their unused comparison-model definitions remain for source fidelity. This package's supported CLI model choice and all campaign jobs are restricted to `lstm1`.

## Environment

Use Python 3.10 or newer and the original requirements:

```powershell
python -m pip install -r requirements.txt
```

The requested 80000-update campaign requires a suitable CUDA installation of PyTorch. The numerical protocol is unchanged: Adam, learning rate 1e-4, float32, two LSTM layers of width 192, four-token windows, clipping norm 1.0, model seeds 0/1/2, and fixed data/sampler seeds 0.

## Frozen inputs are separate

Use the four `.npz` files from the source archive's `data/locked/` directory, or an existing byte-identical copy. Point `--data-root` to the directory containing those files. Their original filenames and expected SHA-256 hashes are in `configs/input_files.json` and the case configurations. Loading is refused when a hash does not match.

No training-data generation or replacement data is introduced. The original package-relative `data/locked/` convention still works if you provide the files there yourself. `VR_LSTM_DATA_ROOT` is the equivalent environment variable for the four original entry scripts.

## List and validate the 12 jobs

```powershell
python train_all_vr_lstm.py --list
python train_all_vr_lstm.py --check-inputs --data-root 'D:/your_original_data/locked'
```

These commands do not start training. The first does not require PyTorch or the data files.

## Train all four cases and three seeds

```powershell
python train_all_vr_lstm.py --data-root 'D:/your_original_data/locked' --device cuda:0
```

The 12 groups run sequentially. The original completion checks and resume logic are retained. Generated outputs go to `results/<case>/lstm1/seed_<n>/`, or the path supplied by `--output-root`; no pre-existing results are supplied in the archive.

PowerShell equivalent:

```powershell
powershell -File scripts/run_all_12.ps1 -DataRoot 'D:/your_original_data/locked' -Device cuda:0
```

## Train one case/seed

```powershell
python train_all_vr_lstm.py --case case3_rbc --seed 2 --data-root 'D:/your_original_data/locked' --device cuda:0
```

The original entry point is also available:

```powershell
$env:VR_LSTM_DATA_ROOT = 'D:/your_original_data/locked'
python train_case3_rbc.py --model lstm1 --seed 2 --device cuda:0
```

## Optional one-update checks

```powershell
python train_all_vr_lstm.py --smoke-test --data-root 'D:/your_original_data/locked' --device cuda:0
```

For a CPU-only functional check, add `--device cpu --allow-cpu`. The default smoke output directory is `smoke_results/`, separate from the 80000-update campaign.

## Case 4 source version

This package follows the supplied `EPJPlus_R2_ExperimentC_36runs_v1.zip`, rather than silently substituting a later case version. In this v1 source, Case 4 has network outputs `u,v,p`, uses only `u,v` in its primary error aggregate, and still computes gauge-aligned pressure diagnostics. Pressure remains necessary as a latent variable in the momentum PDE. The later manuscript decision to omit FEM-pressure figures is not a change to these training equations. If reproducing a later velocity-only evaluation revision, its different frozen data/reference and evaluation patch must be supplied explicitly; those changes are not fabricated here.

## Source fidelity

`SOURCE_PROVENANCE.json` records the original ZIP hash, unchanged source hashes, the filtered original run identifiers, and the two narrow edits to the configuration helper. Numerical settings, state-reset implementation, PDEs, loss weights, sampling, Adam updates, gradient clipping, and evaluation logic are retained from the source archive.

The narrow edits are: restrict `MODEL_NAMES` to `lstm1`; add an optional external data-root lookup to `dataset_path()`. Other source changes are limited to the 12-job launch/configuration files. This repackaged source has its own fingerprint. Do not use it to resume a checkpoint that records a different original source fingerprint; the original trainer intentionally refuses incompatible continuation.

`MANIFEST.sha256` covers all delivered files except itself. This is source organization and verification, not a claim that the 12 full 80000-update runs were rerun during packaging.

## Checks performed while assembling

- 44 functional checks passed. All 12 case/seed models matched the source in forward outputs and input gradients exactly; cross-token derivatives were zero.
- Each case/seed completed one reduced-minibatch loss/backward/Adam-update check with finite gradients. No full 80000-update campaign was run.
- The four external frozen input hashes were checked successfully. Python syntax, PowerShell syntax, the 12-job dry run, seed rejection, and VR-only CLI selection passed.
- The installed CPU environment used PyTorch 1.12.1 and NumPy 1.26.4 for these mathematical checks. This is not a fresh installation of the declared dependencies or a CUDA/full-campaign validation. Use `requirements.txt` for the supported training environment.
