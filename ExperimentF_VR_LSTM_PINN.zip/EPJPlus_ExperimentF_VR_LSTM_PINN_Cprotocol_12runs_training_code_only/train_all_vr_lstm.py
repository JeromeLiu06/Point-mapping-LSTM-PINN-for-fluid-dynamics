"""Launch the 12 VR-LSTM-PINN runs using the archived Experiment-C protocol."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CASES = ("case1_tgv", "case2_mms_cavity", "case3_rbc", "case4_cavity_fem")


def sha256_file(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read_jobs() -> list[dict[str, str]]:
    with (ROOT / "configs/run_matrix.csv").open(encoding="utf-8", newline="") as handle:
        jobs = list(csv.DictReader(handle))
    identities = [(r["case"], r["model"], int(r["model_seed"])) for r in jobs]
    expected = [(case, "lstm1", seed) for case in CASES for seed in (0, 1, 2)]
    if identities != expected or any(int(r["iterations"]) != 80000 for r in jobs):
        raise RuntimeError("Run matrix must contain exactly 4 cases x lstm1 x seeds 0/1/2 at 80000 updates")
    return jobs


def check_inputs(cases: list[str], data_root: Path | None) -> None:
    for case in dict.fromkeys(cases):
        cfg = json.loads((ROOT / f"configs/cases/{case}.json").read_text(encoding="utf-8"))
        path = data_root / Path(cfg["dataset"]).name if data_root else ROOT / cfg["dataset"]
        if not path.is_file():
            raise FileNotFoundError(
                f"Missing frozen input: {path}\nThis code-only package does not contain .npz datasets. "
                "Use --data-root to point to the source archive's data/locked directory."
            )
        actual = sha256_file(path)
        if actual.lower() != cfg["dataset_sha256"].lower():
            raise RuntimeError(f"Dataset hash mismatch for {case}: expected {cfg['dataset_sha256']}, got {actual}")
        print(f"INPUT PASS {case}: {path}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=CASES, action="append", help="Repeat to select cases; default: all four")
    parser.add_argument("--seed", choices=(0, 1, 2), type=int, action="append", help="Repeat to select seeds; default: 0,1,2")
    parser.add_argument("--data-root", type=Path, help="External folder containing the four original frozen .npz files")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-root", type=Path, default=ROOT / "results")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--list", action="store_true", help="Show jobs without loading PyTorch, data, or starting training")
    parser.add_argument("--check-inputs", action="store_true", help="Check input SHA-256 and exit without training")
    parser.add_argument("--smoke-test", action="store_true", help="One update per selected run; separate smoke_results output")
    parser.add_argument("--allow-cpu", action="store_true", help="Permit CPU smoke tests only")
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args()
    jobs = [r for r in read_jobs() if (not args.case or r["case"] in args.case) and (not args.seed or int(r["model_seed"]) in args.seed)]
    data_root = args.data_root.expanduser().resolve() if args.data_root else None
    if data_root is None and os.environ.get("VR_LSTM_DATA_ROOT"):
        data_root = Path(os.environ["VR_LSTM_DATA_ROOT"]).expanduser().resolve()
    if args.list:
        print("Display name: VR-LSTM-PINN; archived model key: lstm1")
        for i, r in enumerate(jobs, 1):
            print(f"{i:02d}/{len(jobs):02d} case={r['case']} model=lstm1 seed={r['model_seed']} iterations={r['iterations']}")
        return
    check_inputs([r["case"] for r in jobs], data_root)
    if args.check_inputs:
        return
    if args.device.startswith("cpu") and not (args.smoke_test and args.allow_cpu):
        parser.error("CPU is supported only with --smoke-test --allow-cpu; the 80000-update campaign uses CUDA")
    output_root = args.output_root.expanduser().resolve()
    if args.smoke_test and output_root == (ROOT / "results").resolve():
        output_root = ROOT / "smoke_results"
    env = os.environ.copy()
    env.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if data_root:
        env["VR_LSTM_DATA_ROOT"] = str(data_root)
    for i, r in enumerate(jobs, 1):
        command = [args.python, str(ROOT / f"train_{r['case']}.py"), "--model", "lstm1", "--seed", r["model_seed"], "--device", args.device, "--output-root", str(output_root), "--iterations", "1" if args.smoke_test else r["iterations"]]
        if args.no_resume:
            command.append("--no-resume")
        if args.allow_cpu:
            command.append("--allow-cpu")
        print(f"RUN {i}/{len(jobs)}: {r['case']} lstm1 seed={r['model_seed']}", flush=True)
        subprocess.run(command, cwd=ROOT, env=env, check=True)


if __name__ == "__main__":
    main()
