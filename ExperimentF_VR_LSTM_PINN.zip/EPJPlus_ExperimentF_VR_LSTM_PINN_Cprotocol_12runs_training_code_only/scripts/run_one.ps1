param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('case1_tgv','case2_mms_cavity','case3_rbc','case4_cavity_fem')]
    [string]$Case,
    [Parameter(Mandatory=$true)]
    [ValidateSet(0,1,2)]
    [int]$Seed,
    [string]$Python = 'python',
    [string]$Device = 'cuda:0',
    [string]$DataRoot = '',
    [string]$OutputRoot = '',
    [switch]$List,
    [switch]$CheckInputs,
    [switch]$SmokeTest,
    [switch]$AllowCpu,
    [switch]$NoResume
)
$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$commandArguments = @((Join-Path $packageRoot 'train_all_vr_lstm.py'), '--case', $Case, '--seed', $Seed, '--device', $Device)
if ($DataRoot) { $commandArguments += @('--data-root', $DataRoot) }
if ($OutputRoot) { $commandArguments += @('--output-root', $OutputRoot) }
if ($List) { $commandArguments += '--list' }
if ($CheckInputs) { $commandArguments += '--check-inputs' }
if ($SmokeTest) { $commandArguments += '--smoke-test' }
if ($AllowCpu) { $commandArguments += '--allow-cpu' }
if ($NoResume) { $commandArguments += '--no-resume' }
& $Python @commandArguments
if ($LASTEXITCODE -ne 0) { throw "VR-LSTM-PINN run failed with exit code $LASTEXITCODE" }
