param(
    [string]$Python = 'python',
    [string]$Device = 'cuda:0',
    [string]$DataRoot = '',
    [string]$OutputRoot = '',
    [switch]$List,
    [switch]$CheckInputs,
    [switch]$SmokeTest,
    [switch]$AllowCpu,
    [switch]$NoResume
)
$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$commandArguments = @((Join-Path $packageRoot 'train_all_vr_lstm.py'), '--device', $Device)
if ($DataRoot) { $commandArguments += @('--data-root', $DataRoot) }
if ($OutputRoot) { $commandArguments += @('--output-root', $OutputRoot) }
if ($List) { $commandArguments += '--list' }
if ($CheckInputs) { $commandArguments += '--check-inputs' }
if ($SmokeTest) { $commandArguments += '--smoke-test' }
if ($AllowCpu) { $commandArguments += '--allow-cpu' }
if ($NoResume) { $commandArguments += '--no-resume' }
& $Python @commandArguments
if ($LASTEXITCODE -ne 0) { throw "VR-LSTM-PINN launcher failed with exit code $LASTEXITCODE" }
