from __future__ import annotations

import math

import torch


def token_diagonal_gradient(
    value: torch.Tensor,
    coordinates: torch.Tensor,
    token: int,
) -> torch.Tensor:
    """Return d(value[:, token])/d(coordinates[:, token, :])."""
    full = torch.autograd.grad(
        value[:, token].sum(),
        coordinates,
        create_graph=True,
        retain_graph=True,
    )[0]
    return full[:, token, :]


def _second_derivative(
    first_derivative: torch.Tensor,
    coordinates: torch.Tensor,
    token: int,
    coordinate_index: int,
) -> torch.Tensor:
    full = torch.autograd.grad(
        first_derivative.sum(),
        coordinates,
        create_graph=True,
        retain_graph=True,
    )[0]
    return full[:, token, coordinate_index]


def tgv_reference(coordinates: torch.Tensor) -> torch.Tensor:
    x, y, t = coordinates[..., 0], coordinates[..., 1], coordinates[..., 2]
    decay = torch.exp(-t)
    return torch.stack(
        (
            torch.sin(x) * torch.cos(y) * decay,
            -torch.cos(x) * torch.sin(y) * decay,
            0.25 * (torch.cos(2.0 * x) + torch.cos(2.0 * y)) * decay.square(),
        ),
        dim=-1,
    )


def mms_cavity_reference(coordinates: torch.Tensor) -> torch.Tensor:
    x, y = coordinates[..., 0], coordinates[..., 1]
    f = x**2 - 2.0 * x**3 + x**4
    fp = 2.0 * x - 6.0 * x**2 + 4.0 * x**3
    g = y**3 - y**2
    gp = 3.0 * y**2 - 2.0 * y
    return torch.stack((f * gp, -fp * g, x * (1.0 - x) * y * (1.0 - y)), dim=-1)


def rbc_reference(coordinates: torch.Tensor) -> torch.Tensor:
    x, y, t = coordinates[..., 0], coordinates[..., 1], coordinates[..., 2]
    u = (
        2.0
        * math.pi
        * torch.sin(math.pi * x).square()
        * torch.sin(math.pi * y)
        * torch.cos(math.pi * y)
        * torch.sin(math.pi * t)
    )
    v = (
        -2.0
        * math.pi
        * torch.sin(math.pi * x)
        * torch.cos(math.pi * x)
        * torch.sin(math.pi * y).square()
        * torch.sin(math.pi * t)
    )
    p = 0.1 * torch.cos(math.pi * x) * torch.cos(math.pi * y) * torch.cos(math.pi * t)
    theta = torch.sin(math.pi * x) * torch.sin(math.pi * y) * torch.cos(math.pi * t)
    return torch.stack((u, v, p, theta), dim=-1)


def analytical_reference(case: str, coordinates: torch.Tensor) -> torch.Tensor:
    if case == "case1_tgv":
        return tgv_reference(coordinates)
    if case == "case2_mms_cavity":
        return mms_cavity_reference(coordinates)
    if case == "case3_rbc":
        return rbc_reference(coordinates)
    raise ValueError(f"Case {case} uses a numerical reference")


def _mms_cavity_forcing(z: torch.Tensor, nu: float) -> tuple[torch.Tensor, torch.Tensor]:
    x, y = z[:, 0], z[:, 1]
    f = x**2 - 2.0 * x**3 + x**4
    fp = 2.0 * x - 6.0 * x**2 + 4.0 * x**3
    fpp = 2.0 - 12.0 * x + 12.0 * x**2
    fppp = -12.0 + 24.0 * x
    g = y**3 - y**2
    gp = 3.0 * y**2 - 2.0 * y
    gpp = 6.0 * y - 2.0
    gppp = torch.full_like(y, 6.0)
    u = f * gp
    v = -fp * g
    ux, uy = fp * gp, f * gpp
    vx, vy = -fpp * g, -fp * gp
    laplace_u = fpp * gp + f * gppp
    laplace_v = -fppp * g - fp * gpp
    px = (1.0 - 2.0 * x) * y * (1.0 - y)
    py = x * (1.0 - x) * (1.0 - 2.0 * y)
    return (
        u * ux + v * uy + px - nu * laplace_u,
        u * vx + v * vy + py - nu * laplace_v,
    )


def _rbc_forcing(
    z: torch.Tensor,
    nu: float,
    kappa: float,
    beta: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    reference_coordinates = z.detach().clone().requires_grad_(True)
    x, y, t = (
        reference_coordinates[:, 0],
        reference_coordinates[:, 1],
        reference_coordinates[:, 2],
    )

    def derivative(value: torch.Tensor, variable: torch.Tensor) -> torch.Tensor:
        return torch.autograd.grad(
            value,
            variable,
            torch.ones_like(value),
            create_graph=True,
            retain_graph=True,
        )[0]

    stream = (
        torch.sin(math.pi * x).square()
        * torch.sin(math.pi * y).square()
        * torch.sin(math.pi * t)
    )
    u = derivative(stream, y)
    v = -derivative(stream, x)
    p = 0.1 * torch.cos(math.pi * x) * torch.cos(math.pi * y) * torch.cos(math.pi * t)
    theta = torch.sin(math.pi * x) * torch.sin(math.pi * y) * torch.cos(math.pi * t)
    ux, uy, ut = derivative(u, x), derivative(u, y), derivative(u, t)
    vx, vy, vt = derivative(v, x), derivative(v, y), derivative(v, t)
    tx, ty, tt = derivative(theta, x), derivative(theta, y), derivative(theta, t)
    force_u = ut + u * ux + v * uy + derivative(p, x) - nu * (
        derivative(ux, x) + derivative(uy, y)
    )
    force_v = vt + u * vx + v * vy + derivative(p, y) - nu * (
        derivative(vx, x) + derivative(vy, y)
    ) - beta * theta
    force_t = tt + u * tx + v * ty - kappa * (
        derivative(tx, x) + derivative(ty, y)
    )
    return force_u.detach(), force_v.detach(), force_t.detach()


def pde_loss_components(
    model: torch.nn.Module,
    coordinates: torch.Tensor,
    case: str,
    physics: dict,
) -> dict[str, torch.Tensor]:
    z = coordinates.detach().clone().requires_grad_(True)
    output = model(z)
    u, v, p = output[..., 0], output[..., 1], output[..., 2]
    momentum_u_terms = []
    momentum_v_terms = []
    divergence_terms = []
    temperature_terms = []
    nu = float(physics["nu"])

    for token in range(z.shape[1]):
        grad_u = token_diagonal_gradient(u, z, token)
        grad_v = token_diagonal_gradient(v, z, token)
        grad_p = token_diagonal_gradient(p, z, token)
        u_xx = _second_derivative(grad_u[:, 0], z, token, 0)
        u_yy = _second_derivative(grad_u[:, 1], z, token, 1)
        v_xx = _second_derivative(grad_v[:, 0], z, token, 0)
        v_yy = _second_derivative(grad_v[:, 1], z, token, 1)
        u_token, v_token = u[:, token], v[:, token]

        if case == "case1_tgv":
            x, y, t = z[:, token, 0], z[:, token, 1], z[:, token, 2]
            force_u = (2.0 * nu - 1.0) * torch.exp(-t) * torch.sin(x) * torch.cos(y)
            force_v = (1.0 - 2.0 * nu) * torch.exp(-t) * torch.cos(x) * torch.sin(y)
            residual_u = (
                grad_u[:, 2]
                + u_token * grad_u[:, 0]
                + v_token * grad_u[:, 1]
                + grad_p[:, 0]
                - nu * (u_xx + u_yy)
                - force_u
            )
            residual_v = (
                grad_v[:, 2]
                + u_token * grad_v[:, 0]
                + v_token * grad_v[:, 1]
                + grad_p[:, 1]
                - nu * (v_xx + v_yy)
                - force_v
            )
        elif case == "case2_mms_cavity":
            force_u, force_v = _mms_cavity_forcing(z[:, token, :], nu)
            residual_u = (
                u_token * grad_u[:, 0]
                + v_token * grad_u[:, 1]
                + grad_p[:, 0]
                - nu * (u_xx + u_yy)
                - force_u
            )
            residual_v = (
                u_token * grad_v[:, 0]
                + v_token * grad_v[:, 1]
                + grad_p[:, 1]
                - nu * (v_xx + v_yy)
                - force_v
            )
        elif case == "case3_rbc":
            theta = output[..., 3]
            grad_theta = token_diagonal_gradient(theta, z, token)
            theta_xx = _second_derivative(grad_theta[:, 0], z, token, 0)
            theta_yy = _second_derivative(grad_theta[:, 1], z, token, 1)
            kappa = float(physics["kappa"])
            beta = float(physics["beta"])
            force_u, force_v, force_theta = _rbc_forcing(
                z[:, token, :], nu, kappa, beta
            )
            residual_u = (
                grad_u[:, 2]
                + u_token * grad_u[:, 0]
                + v_token * grad_u[:, 1]
                + grad_p[:, 0]
                - nu * (u_xx + u_yy)
                - force_u
            )
            residual_v = (
                grad_v[:, 2]
                + u_token * grad_v[:, 0]
                + v_token * grad_v[:, 1]
                + grad_p[:, 1]
                - nu * (v_xx + v_yy)
                - beta * theta[:, token]
                - force_v
            )
            residual_theta = (
                grad_theta[:, 2]
                + u_token * grad_theta[:, 0]
                + v_token * grad_theta[:, 1]
                - kappa * (theta_xx + theta_yy)
                - force_theta
            )
            temperature_terms.append(residual_theta.square().mean())
        elif case == "case4_cavity_fem":
            residual_u = (
                u_token * grad_u[:, 0]
                + v_token * grad_u[:, 1]
                + grad_p[:, 0]
                - nu * (u_xx + u_yy)
            )
            residual_v = (
                u_token * grad_v[:, 0]
                + v_token * grad_v[:, 1]
                + grad_p[:, 1]
                - nu * (v_xx + v_yy)
            )
        else:
            raise ValueError(case)

        momentum_u_terms.append(residual_u.square().mean())
        momentum_v_terms.append(residual_v.square().mean())
        divergence_terms.append((grad_u[:, 0] + grad_v[:, 1]).square().mean())

    zero = output.sum() * 0.0
    return {
        "momentum_u": torch.stack(momentum_u_terms).mean(),
        "momentum_v": torch.stack(momentum_v_terms).mean(),
        "divergence": torch.stack(divergence_terms).mean(),
        "temperature": torch.stack(temperature_terms).mean() if temperature_terms else zero,
    }


def supervised_reference_loss(
    model: torch.nn.Module,
    coordinates: torch.Tensor,
    case: str,
) -> torch.Tensor:
    reference = analytical_reference(case, coordinates)
    return (model(coordinates) - reference).square().mean()


def cavity_boundary_loss(
    model: torch.nn.Module,
    coordinates: torch.Tensor,
    side: str,
) -> torch.Tensor:
    prediction = model(coordinates)[..., :2]
    target = torch.zeros_like(prediction)
    if side == "top":
        target[..., 0] = 1.0
    return (prediction - target).square().mean()


def periodic_value_loss(
    model: torch.nn.Module,
    first: torch.Tensor,
    second: torch.Tensor,
) -> torch.Tensor:
    return (model(first) - model(second)).square().mean()

