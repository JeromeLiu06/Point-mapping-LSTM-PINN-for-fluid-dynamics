from __future__ import annotations

import csv
import json
import os
import platform
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np

# CUDA >= 10.2 requires this before the first cuBLAS operation for reproducible GEMMs.
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import torch
from torch import nn

from .config import dataset_path, sha256_file, source_fingerprint, source_manifest
from .data import FixedSampler, load_locked_dataset, validate_dataset_shapes
from .metrics import evaluate_model
from .models import build_model, expected_parameter_count, parameter_count
from .physics import (
    cavity_boundary_loss,
    periodic_value_loss,
    supervised_reference_loss,
    pde_loss_components,
)


HISTORY_FIELDS = [
    "iteration",
    "loss_total",
    "raw_momentum_u",
    "raw_momentum_v",
    "raw_divergence",
    "raw_temperature",
    "raw_initial",
    "raw_periodic_x",
    "raw_periodic_y",
    "raw_boundary_bottom",
    "raw_boundary_top",
    "raw_boundary_left",
    "raw_boundary_right",
    "weighted_momentum",
    "weighted_divergence",
    "weighted_temperature",
    "weighted_initial",
    "weighted_boundary",
    "primary_relative_l2",
    "best_primary_relative_l2",
    "best_iteration",
    "last_block_train_wall_s_per_iteration",
    "cumulative_train_wall_s",
    "cumulative_evaluation_io_s",
    "cumulative_wall_s",
    "peak_gpu_allocated_mb",
    "peak_gpu_reserved_mb",
]


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _atomic_npz(path: Path, **arrays: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(temporary, path)


def _append_jsonl(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _cuda_sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _set_model_seed(seed: int, deterministic: dict[str, Any]) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.benchmark = bool(deterministic["cudnn_benchmark"])
        torch.backends.cudnn.deterministic = bool(deterministic["cudnn_deterministic"])
    torch.use_deterministic_algorithms(
        True,
        warn_only=bool(deterministic["deterministic_algorithms_warn_only"]),
    )


def _rng_state(sampler: FixedSampler) -> dict[str, Any]:
    return {
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
        "sampler": sampler.state_dict(),
    }


def _restore_rng_state(state: dict[str, Any], sampler: FixedSampler) -> None:
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch_cpu"])
    if torch.cuda.is_available() and state.get("torch_cuda") is not None:
        torch.cuda.set_rng_state_all(state["torch_cuda"])
    sampler.load_state_dict(state["sampler"])


def _build_environment(device: torch.device, parameters: int) -> dict[str, Any]:
    environment: dict[str, Any] = {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "torch": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "device": str(device),
        "parameter_count": parameters,
    }
    if device.type == "cuda":
        index = device.index if device.index is not None else torch.cuda.current_device()
        properties = torch.cuda.get_device_properties(index)
        environment["gpu"] = {
            "name": properties.name,
            "total_memory_mb": properties.total_memory / 2**20,
            "compute_capability": f"{properties.major}.{properties.minor}",
        }
    else:
        environment["gpu"] = None
    return environment


def _loss_components(
    model: nn.Module,
    arrays: dict[str, torch.Tensor],
    sampler: FixedSampler,
    case_config: dict[str, Any],
    protocol: dict[str, Any],
    device: torch.device,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    batches = protocol["batches"]
    case = case_config["case"]
    collocation = sampler.draw(
        arrays, "col_train", int(batches["collocation_tokens"]), device
    )
    raw = pde_loss_components(model, collocation, case, case_config["physics"])
    zero = raw["momentum_u"] * 0.0
    raw.update(
        {
            "initial": zero,
            "periodic_x": zero,
            "periodic_y": zero,
            "boundary_bottom": zero,
            "boundary_top": zero,
            "boundary_left": zero,
            "boundary_right": zero,
        }
    )

    if case == "case1_tgv":
        initial = sampler.draw(
            arrays, "ic_train", int(batches["initial_tokens"]), device
        )
        raw["initial"] = supervised_reference_loss(model, initial, case)
        x0, x1 = sampler.draw_pair(
            arrays,
            "bcx0_train",
            "bcx1_train",
            int(batches["boundary_tokens_per_term"]),
            device,
        )
        y0, y1 = sampler.draw_pair(
            arrays,
            "bcy0_train",
            "bcy1_train",
            int(batches["boundary_tokens_per_term"]),
            device,
        )
        raw["periodic_x"] = periodic_value_loss(model, x0, x1)
        raw["periodic_y"] = periodic_value_loss(model, y0, y1)
    elif case in {"case2_mms_cavity", "case3_rbc", "case4_cavity_fem"}:
        if case == "case3_rbc":
            initial = sampler.draw(
                arrays, "ic_train", int(batches["initial_tokens"]), device
            )
            raw["initial"] = supervised_reference_loss(model, initial, case)
        for side in ("bottom", "top", "left", "right"):
            coordinates = sampler.draw(
                arrays,
                f"{side}_train",
                int(batches["boundary_tokens_per_term"]),
                device,
            )
            if case == "case4_cavity_fem":
                value = cavity_boundary_loss(model, coordinates, side)
            else:
                value = supervised_reference_loss(model, coordinates, case)
            raw[f"boundary_{side}"] = value
    else:
        raise ValueError(case)

    weights = case_config["loss_weights"]
    boundary_raw = (
        raw["periodic_x"]
        + raw["periodic_y"]
        + raw["boundary_bottom"]
        + raw["boundary_top"]
        + raw["boundary_left"]
        + raw["boundary_right"]
    )
    weighted = {
        "momentum": float(weights["momentum"])
        * (raw["momentum_u"] + raw["momentum_v"]),
        "divergence": float(weights["divergence"]) * raw["divergence"],
        "temperature": float(weights["temperature"]) * raw["temperature"],
        "initial": float(weights["initial"]) * raw["initial"],
        "boundary": float(weights["boundary"]) * boundary_raw,
    }
    total = sum(weighted.values())
    components = {f"raw_{key}": value for key, value in raw.items()}
    components.update({f"weighted_{key}": value for key, value in weighted.items()})
    return total, components


def _checkpoint_payload(
    *,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    sampler: FixedSampler,
    iteration: int,
    best_metric: float,
    best_iteration: int,
    timing: dict[str, Any],
    run_config: dict[str, Any],
) -> dict[str, Any]:
    return {
        "iteration": iteration,
        "best_primary_relative_l2": best_metric,
        "best_iteration": best_iteration,
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "rng": _rng_state(sampler),
        "timing": timing,
        "run_config": run_config,
    }


def _atomic_torch_save(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def _percentile(values: list[float], percentile: float) -> float | None:
    return float(np.percentile(values, percentile)) if values else None


def run_training(
    *,
    case_config: dict[str, Any],
    protocol: dict[str, Any],
    model_name: str,
    model_seed: int,
    output_dir: Path,
    device_name: str,
    iterations: int | None = None,
    resume: bool = True,
    allow_cpu: bool = False,
) -> None:
    output_dir = output_dir.absolute()
    final_summary = output_dir / "metrics" / "summary.json"
    if final_summary.exists():
        summary = json.loads(final_summary.read_text(encoding="utf-8"))
        target_iterations = int(iterations or protocol["iterations"])
        if summary.get("state") == "complete" and int(summary["iteration"]) == target_iterations:
            print(f"SKIP complete run: {output_dir}")
            return

    for name in ("config", "checkpoints", "loss", "metrics", "predictions", "cost", "logs"):
        (output_dir / name).mkdir(parents=True, exist_ok=True)

    device = torch.device(device_name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(f"Requested {device_name}, but CUDA is not available")
    if device.type != "cuda" and not allow_cpu:
        raise RuntimeError("The 80k protocol requires CUDA. Pass --allow-cpu only for a smoke test.")

    target_iterations = int(iterations or protocol["iterations"])
    _set_model_seed(model_seed, protocol["determinism"])
    torch.set_default_dtype(torch.float32)

    frozen_path = dataset_path(case_config)
    arrays = load_locked_dataset(frozen_path, case_config["dataset_sha256"])
    validate_dataset_shapes(arrays, case_config["expected_arrays"])
    sampler = FixedSampler(int(protocol["sampler_seed"]), case_config["case"])
    model = build_model(model_name, int(case_config["output_dim"]), protocol).to(device)
    actual_parameters = parameter_count(model)
    expected_parameters = expected_parameter_count(
        model_name, int(case_config["output_dim"]), protocol
    )
    if actual_parameters != expected_parameters:
        raise RuntimeError(
            f"Parameter-count guard failed: expected {expected_parameters}, got {actual_parameters}"
        )

    optimizer_config = protocol["optimizer"]
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=float(optimizer_config["learning_rate"]),
        betas=tuple(float(x) for x in optimizer_config["betas"]),
        eps=float(optimizer_config["eps"]),
        weight_decay=float(optimizer_config["weight_decay"]),
    )
    manifest = source_manifest()
    fingerprint = source_fingerprint(manifest)
    run_config = {
        "protocol": protocol,
        "case": case_config,
        "model": model_name,
        "model_seed": model_seed,
        "target_iterations": target_iterations,
        "dataset_absolute_path": str(frozen_path.absolute()),
        "dataset_sha256": sha256_file(frozen_path),
        "source_fingerprint_sha256": fingerprint,
    }
    _atomic_json(output_dir / "config" / "run_config.json", run_config)
    _atomic_json(output_dir / "config" / "source_manifest.json", manifest)
    _atomic_json(
        output_dir / "config" / "environment.json",
        _build_environment(device, actual_parameters),
    )

    timing: dict[str, Any] = {
        "train_wall_s": 0.0,
        "evaluation_io_s": 0.0,
        "wall_s": 0.0,
        "gpu_update_samples_s": [],
        "cpu_update_samples_s": [],
    }
    start_iteration = 0
    best_metric = float("inf")
    best_iteration = 0
    latest_checkpoint = output_dir / "checkpoints" / "latest.pt"
    if latest_checkpoint.exists():
        if not resume:
            raise RuntimeError(
                f"Incomplete output already exists at {output_dir}. Enable resume or choose a new output root."
            )
        # Keep RNG byte tensors on CPU; model/optimizer states are transferred by
        # load_state_dict to their already-created parameter devices.
        checkpoint = torch.load(latest_checkpoint, map_location="cpu", weights_only=False)
        old = checkpoint["run_config"]
        identity_keys = ("model", "model_seed", "dataset_sha256", "source_fingerprint_sha256")
        mismatches = [key for key in identity_keys if old.get(key) != run_config.get(key)]
        if mismatches:
            raise RuntimeError(f"Refusing incompatible resume; changed keys: {mismatches}")
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        start_iteration = int(checkpoint["iteration"])
        best_metric = float(checkpoint["best_primary_relative_l2"])
        best_iteration = int(checkpoint["best_iteration"])
        timing = checkpoint["timing"]
        _restore_rng_state(checkpoint["rng"], sampler)
        if start_iteration >= target_iterations:
            raise RuntimeError(
                f"Checkpoint iteration {start_iteration} is not below target {target_iterations}"
            )
        print(f"RESUME {output_dir} from iteration {start_iteration}")

    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    history_path = output_dir / "loss" / "train_history.csv"
    append_history = start_iteration > 0 and history_path.exists()
    history_handle = history_path.open(
        "a" if append_history else "w", newline="", encoding="utf-8"
    )
    history_writer = csv.DictWriter(history_handle, fieldnames=HISTORY_FIELDS)
    if not append_history:
        history_writer.writeheader()

    evaluation_every = int(protocol["evaluation"]["every_iterations"])
    max_sequences = int(protocol["evaluation"]["max_sequences_per_chunk"])
    clip_norm = float(optimizer_config["gradient_clip_norm"])
    session_wall_start = time.perf_counter()
    block_train_start = time.perf_counter()
    block_iterations = 0
    cuda_events: list[tuple[torch.cuda.Event, torch.cuda.Event]] = []
    cpu_iteration_samples: list[float] = []
    thresholds = {"1e-2": None, "1e-3": None}
    metrics_history_path = output_dir / "metrics" / "metrics_history.jsonl"

    try:
        model.train()
        for iteration in range(start_iteration + 1, target_iterations + 1):
            if device.type == "cuda":
                event_start = torch.cuda.Event(enable_timing=True)
                event_end = torch.cuda.Event(enable_timing=True)
                event_start.record()
            else:
                cpu_start = time.perf_counter()

            optimizer.zero_grad(set_to_none=True)
            loss, components = _loss_components(
                model, arrays, sampler, case_config, protocol, device
            )
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), clip_norm)
            optimizer.step()

            if device.type == "cuda":
                event_end.record()
                cuda_events.append((event_start, event_end))
            else:
                cpu_iteration_samples.append(time.perf_counter() - cpu_start)
            block_iterations += 1

            should_evaluate = (
                (iteration == 1 and bool(protocol["evaluation"]["first_iteration"]))
                or iteration % evaluation_every == 0
                or iteration == target_iterations
            )
            if not should_evaluate:
                continue

            _cuda_sync(device)
            train_block_seconds = time.perf_counter() - block_train_start
            timing["train_wall_s"] = float(timing["train_wall_s"]) + train_block_seconds
            if device.type == "cuda":
                timing["gpu_update_samples_s"].extend(
                    start.elapsed_time(end) / 1000.0 for start, end in cuda_events
                )
                cuda_events.clear()
            else:
                timing["cpu_update_samples_s"].extend(cpu_iteration_samples)
                cpu_iteration_samples.clear()

            evaluation_start = time.perf_counter()
            metrics, prediction, reference = evaluate_model(
                model, arrays, case_config, device, max_sequences
            )
            primary = float(metrics["aggregate"]["primary"]["relative_l2"])
            improved = primary < best_metric
            if improved:
                best_metric = primary
                best_iteration = iteration
                best_record = {
                    "iteration": iteration,
                    "primary_relative_l2": primary,
                    "metrics": metrics,
                }
                _atomic_json(output_dir / "metrics" / "best_metrics.json", best_record)
                _atomic_npz(
                    output_dir / "predictions" / "best_predictions.npz",
                    prediction=prediction,
                    reference=reference,
                    error=prediction - reference,
                )

            for label, current in thresholds.items():
                if current is None and primary <= float(label):
                    thresholds[label] = {
                        "iteration": iteration,
                        "cumulative_train_wall_s": float(timing["train_wall_s"]),
                    }

            component_numbers = {
                key: float(value.detach().cpu()) for key, value in components.items()
            }
            loss_number = float(loss.detach().cpu())
            _append_jsonl(
                metrics_history_path,
                {
                    "iteration": iteration,
                    "primary_relative_l2": primary,
                    "metrics": metrics,
                },
            )
            _cuda_sync(device)
            evaluation_seconds = time.perf_counter() - evaluation_start
            timing["evaluation_io_s"] = (
                float(timing["evaluation_io_s"]) + evaluation_seconds
            )
            timing["wall_s"] = float(timing["train_wall_s"]) + float(
                timing["evaluation_io_s"]
            )

            peak_allocated = (
                torch.cuda.max_memory_allocated(device) / 2**20
                if device.type == "cuda"
                else 0.0
            )
            peak_reserved = (
                torch.cuda.max_memory_reserved(device) / 2**20
                if device.type == "cuda"
                else 0.0
            )
            row = {field: 0.0 for field in HISTORY_FIELDS}
            row.update(
                {
                    "iteration": iteration,
                    "loss_total": loss_number,
                    **component_numbers,
                    "primary_relative_l2": primary,
                    "best_primary_relative_l2": best_metric,
                    "best_iteration": best_iteration,
                    "last_block_train_wall_s_per_iteration": train_block_seconds
                    / max(block_iterations, 1),
                    "cumulative_train_wall_s": timing["train_wall_s"],
                    "cumulative_evaluation_io_s": timing["evaluation_io_s"],
                    "cumulative_wall_s": timing["wall_s"],
                    "peak_gpu_allocated_mb": peak_allocated,
                    "peak_gpu_reserved_mb": peak_reserved,
                }
            )
            history_writer.writerow(row)
            history_handle.flush()
            os.fsync(history_handle.fileno())

            payload = _checkpoint_payload(
                model=model,
                optimizer=optimizer,
                sampler=sampler,
                iteration=iteration,
                best_metric=best_metric,
                best_iteration=best_iteration,
                timing=timing,
                run_config=run_config,
            )
            _atomic_torch_save(latest_checkpoint, payload)
            if improved:
                _atomic_torch_save(output_dir / "checkpoints" / "best.pt", payload)
            _atomic_json(
                output_dir / "metrics" / "status.json",
                {
                    "state": "running",
                    "iteration": iteration,
                    "target_iterations": target_iterations,
                    "primary_relative_l2": primary,
                    "best_primary_relative_l2": best_metric,
                    "best_iteration": best_iteration,
                    "updated_unix": time.time(),
                },
            )
            print(
                f"{case_config['case']} {model_name} seed={model_seed} "
                f"iteration={iteration}/{target_iterations} loss={loss_number:.6e} "
                f"primary_rel_l2={primary:.6e} best={best_metric:.6e}"
            )
            block_iterations = 0
            block_train_start = time.perf_counter()

        final_metrics = {
            "iteration": target_iterations,
            "primary_relative_l2": primary,
            "metrics": metrics,
        }
        _atomic_json(output_dir / "metrics" / "final_metrics.json", final_metrics)
        _atomic_npz(
            output_dir / "predictions" / "final_predictions.npz",
            prediction=prediction,
            reference=reference,
            error=prediction - reference,
        )
        final_payload = _checkpoint_payload(
            model=model,
            optimizer=optimizer,
            sampler=sampler,
            iteration=target_iterations,
            best_metric=best_metric,
            best_iteration=best_iteration,
            timing=timing,
            run_config=run_config,
        )
        _atomic_torch_save(output_dir / "checkpoints" / "final.pt", final_payload)

        update_samples = (
            timing["gpu_update_samples_s"]
            if device.type == "cuda"
            else timing["cpu_update_samples_s"]
        )
        cost = {
            "iterations": target_iterations,
            "cumulative_train_wall_s": float(timing["train_wall_s"]),
            "cumulative_evaluation_io_s": float(timing["evaluation_io_s"]),
            "cumulative_measured_wall_s": float(timing["wall_s"]),
            "session_wall_s": time.perf_counter() - session_wall_start,
            "mean_train_wall_s_per_iteration": float(timing["train_wall_s"])
            / target_iterations,
            "update_timing_method": "CUDA events" if device.type == "cuda" else "perf_counter",
            "mean_update_s": float(np.mean(update_samples)),
            "median_update_s": float(np.median(update_samples)),
            "p95_update_s": _percentile(update_samples, 95.0),
            "peak_gpu_allocated_mb": (
                torch.cuda.max_memory_allocated(device) / 2**20
                if device.type == "cuda"
                else 0.0
            ),
            "peak_gpu_reserved_mb": (
                torch.cuda.max_memory_reserved(device) / 2**20
                if device.type == "cuda"
                else 0.0
            ),
            "parameter_count": actual_parameters,
            "final_primary_relative_l2": primary,
            "best_primary_relative_l2": best_metric,
            "best_iteration": best_iteration,
            "threshold_costs": thresholds,
        }
        _atomic_json(output_dir / "cost" / "cost.json", cost)
        summary = {
            "state": "complete",
            "case": case_config["case"],
            "model": model_name,
            "model_seed": model_seed,
            "iteration": target_iterations,
            "final_primary_relative_l2": primary,
            "best_primary_relative_l2": best_metric,
            "best_iteration": best_iteration,
            "dataset_sha256": run_config["dataset_sha256"],
            "source_fingerprint_sha256": fingerprint,
            "parameter_count": actual_parameters,
        }
        _atomic_json(final_summary, summary)
        _atomic_json(output_dir / "metrics" / "status.json", summary)
    except Exception as error:
        _atomic_json(
            output_dir / "metrics" / "status.json",
            {
                "state": "failed",
                "iteration": locals().get("iteration", start_iteration),
                "error_type": type(error).__name__,
                "error": str(error),
                "updated_unix": time.time(),
            },
        )
        raise
    finally:
        history_handle.close()

