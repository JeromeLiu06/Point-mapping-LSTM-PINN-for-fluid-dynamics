"""EPJPlus R2 Experiment-C repeated-seed training package."""

__version__ = "1.0.0"

