from __future__ import annotations

import torch
from torch import nn


class ParamPINN(nn.Module):
    def __init__(self, output_dim: int, width: int = 280, hidden_layers: int = 9):
        super().__init__()
        modules: list[nn.Module] = [nn.Linear(3, width), nn.Tanh()]
        for _ in range(hidden_layers - 1):
            modules.extend((nn.Linear(width, width), nn.Tanh()))
        modules.append(nn.Linear(width, output_dim))
        self.net = nn.Sequential(*modules)

    def forward(self, coordinates: torch.Tensor) -> torch.Tensor:
        return self.net(coordinates)


class LSTMPINN(nn.Module):
    def __init__(
        self,
        output_dim: int,
        state_policy: str,
        hidden_width: int = 192,
        recurrent_layers: int = 2,
    ):
        super().__init__()
        if state_policy not in {"reset_before_every_token", "propagate_within_four_token_window"}:
            raise ValueError(state_policy)
        self.state_policy = state_policy
        self.embedding = nn.Linear(3, hidden_width)
        self.core = nn.LSTM(
            hidden_width,
            hidden_width,
            num_layers=recurrent_layers,
            batch_first=True,
            dropout=0.0,
        )
        self.head = nn.Sequential(
            nn.Linear(hidden_width, hidden_width),
            nn.Tanh(),
            nn.Linear(hidden_width, output_dim),
        )

    def forward(self, coordinates: torch.Tensor) -> torch.Tensor:
        embedded = self.embedding(coordinates)
        if self.state_policy == "propagate_within_four_token_window":
            with torch.backends.cudnn.flags(enabled=False):
                hidden, _ = self.core(embedded)
            return self.head(hidden)

        token_outputs = []
        for token in range(embedded.shape[1]):
            # Omitting an initial state creates fresh zero (h, c) for each token.
            with torch.backends.cudnn.flags(enabled=False):
                hidden, _ = self.core(embedded[:, token : token + 1, :])
            token_outputs.append(hidden)
        return self.head(torch.cat(token_outputs, dim=1))


def build_model(model_name: str, output_dim: int, protocol: dict) -> nn.Module:
    model_config = protocol["models"][model_name]
    if model_name == "param":
        return ParamPINN(
            output_dim=output_dim,
            width=int(model_config["hidden_width"]),
            hidden_layers=int(model_config["hidden_layers"]),
        )
    return LSTMPINN(
        output_dim=output_dim,
        state_policy=str(model_config["state_policy"]),
        hidden_width=int(model_config["hidden_width"]),
        recurrent_layers=int(model_config["recurrent_layers"]),
    )


def parameter_count(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters())


def expected_parameter_count(model_name: str, output_dim: int, protocol: dict) -> int:
    return int(protocol["expected_parameter_counts"][f"output_dim_{output_dim}"][model_name])

