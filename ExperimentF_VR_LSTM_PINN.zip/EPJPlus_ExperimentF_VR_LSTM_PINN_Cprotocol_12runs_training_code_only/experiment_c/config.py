from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


PACKAGE_ROOT = Path(os.path.abspath(__file__)).parents[1]
CASE_FILES = {
    "case1_tgv": "case1_tgv.json",
    "case2_mms_cavity": "case2_mms_cavity.json",
    "case3_rbc": "case3_rbc.json",
    "case4_cavity_fem": "case4_cavity_fem.json",
}
MODEL_NAMES = ("lstm1",)


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_protocol() -> dict[str, Any]:
    return read_json(PACKAGE_ROOT / "configs" / "protocol.json")


def load_case(case: str) -> dict[str, Any]:
    if case not in CASE_FILES:
        raise ValueError(f"Unknown case {case!r}; choose from {tuple(CASE_FILES)}")
    return read_json(PACKAGE_ROOT / "configs" / "cases" / CASE_FILES[case])


def dataset_path(case_config: dict[str, Any]) -> Path:
    external_root = os.environ.get("VR_LSTM_DATA_ROOT")
    if external_root:
        return Path(external_root).expanduser().resolve() / Path(case_config["dataset"]).name
    return PACKAGE_ROOT / case_config["dataset"]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_manifest() -> dict[str, str]:
    roots = [PACKAGE_ROOT / "experiment_c", PACKAGE_ROOT / "configs"]
    files: list[Path] = []
    for root in roots:
        files.extend(p for p in root.rglob("*") if p.is_file() and p.suffix in {".py", ".json"})
    files.extend(PACKAGE_ROOT.glob("train_case*.py"))
    return {
        path.relative_to(PACKAGE_ROOT).as_posix(): sha256_file(path)
        for path in sorted(set(files))
    }


def source_fingerprint(manifest: dict[str, str]) -> str:
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()

