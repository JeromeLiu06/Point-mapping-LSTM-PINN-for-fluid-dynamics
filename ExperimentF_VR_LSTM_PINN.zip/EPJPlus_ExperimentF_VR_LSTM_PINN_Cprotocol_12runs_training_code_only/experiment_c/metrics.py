from __future__ import annotations

import math
from typing import Any

import numpy as np
import torch

from .physics import analytical_reference


def error_metrics(prediction: np.ndarray, reference: np.ndarray) -> dict[str, float]:
    p = np.asarray(prediction, dtype=np.float64).reshape(-1)
    r = np.asarray(reference, dtype=np.float64).reshape(-1)
    error = p - r
    mse = float(np.mean(error**2))
    denominator = float(np.linalg.norm(r))
    return {
        "mse": mse,
        "rmse": float(math.sqrt(mse)),
        "mae": float(np.mean(np.abs(error))),
        "relative_l2": float(np.linalg.norm(error) / max(denominator, 1.0e-12)),
        "max_abs": float(np.max(np.abs(error))),
    }


def _prepare_reference(
    case_config: dict[str, Any],
    arrays: dict[str, torch.Tensor],
    prediction: torch.Tensor,
) -> tuple[np.ndarray, np.ndarray]:
    case = case_config["case"]
    if case in {"case1_tgv", "case3_rbc"}:
        reference = analytical_reference(case, arrays["eval"])[:, -1, :]
        prepared_prediction = prediction[:, -1, :]
    elif case == "case2_mms_cavity":
        reference = analytical_reference(case, arrays["eval"]).reshape(-1, case_config["output_dim"])
        prepared_prediction = prediction.reshape(-1, case_config["output_dim"])
    elif case == "case4_cavity_fem":
        count = int(arrays["eval_count"].reshape(-1)[0])
        prepared_prediction = prediction.reshape(-1, case_config["output_dim"])[:count].clone()
        reference = arrays["eval_ref"]
        pressure_offset = (prepared_prediction[:, 2] - reference[:, 2]).mean()
        prepared_prediction[:, 2] -= pressure_offset
    else:
        raise ValueError(case)
    return prepared_prediction.cpu().numpy(), reference.cpu().numpy()


def complete_metrics(
    case_config: dict[str, Any],
    prediction: np.ndarray,
    reference: np.ndarray,
) -> dict[str, Any]:
    fields = list(case_config["fields"])
    primary_fields = list(case_config["primary_fields"])
    result: dict[str, Any] = {
        "primary_definition": "+".join(primary_fields),
        "field": {},
        "aggregate": {},
        "derived": {},
        "snapshots": {},
    }
    field_index = {name: index for index, name in enumerate(fields)}
    for name, index in field_index.items():
        result["field"][name] = error_metrics(prediction[:, index], reference[:, index])

    primary_indices = [field_index[name] for name in primary_fields]
    result["aggregate"]["primary"] = error_metrics(
        prediction[:, primary_indices], reference[:, primary_indices]
    )
    result["aggregate"]["all_primitive_fields"] = error_metrics(prediction, reference)

    speed_prediction = np.sqrt(prediction[:, 0] ** 2 + prediction[:, 1] ** 2)
    speed_reference = np.sqrt(reference[:, 0] ** 2 + reference[:, 1] ** 2)
    result["derived"]["speed"] = error_metrics(speed_prediction, speed_reference)

    times = list(case_config["evaluation"]["times"])
    if len(times) > 1:
        points_per_snapshot = int(np.prod(case_config["evaluation"]["grid"]))
        for position, time_value in enumerate(times):
            start = position * points_per_snapshot
            stop = start + points_per_snapshot
            snapshot_prediction = prediction[start:stop]
            snapshot_reference = reference[start:stop]
            key = f"t={time_value:g}"
            result["snapshots"][key] = {
                "aggregate_primary": error_metrics(
                    snapshot_prediction[:, primary_indices], snapshot_reference[:, primary_indices]
                ),
                "field": {
                    name: error_metrics(
                        snapshot_prediction[:, index], snapshot_reference[:, index]
                    )
                    for name, index in field_index.items()
                },
            }
    return result


@torch.no_grad()
def evaluate_model(
    model: torch.nn.Module,
    arrays: dict[str, torch.Tensor],
    case_config: dict[str, Any],
    device: torch.device,
    max_sequences_per_chunk: int,
) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    was_training = model.training
    model.eval()
    coordinates = arrays["eval"]
    parts = []
    for start in range(0, len(coordinates), max_sequences_per_chunk):
        block = coordinates[start : start + max_sequences_per_chunk].to(device)
        parts.append(model(block).cpu())
    raw_prediction = torch.cat(parts, dim=0)
    prediction, reference = _prepare_reference(case_config, arrays, raw_prediction)
    metrics = complete_metrics(case_config, prediction, reference)
    if was_training:
        model.train()
    return metrics, prediction, reference

