from __future__ import annotations

import argparse
from pathlib import Path

from .config import CASE_FILES, MODEL_NAMES, PACKAGE_ROOT, load_case, load_protocol
from .trainer import run_training


def main(default_case: str | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Train one EPJPlus R2 Experiment-C case/model/seed group."
    )
    if default_case is None:
        parser.add_argument("--case", choices=tuple(CASE_FILES), required=True)
    else:
        parser.set_defaults(case=default_case)
    parser.add_argument("--model", choices=MODEL_NAMES, required=True)
    parser.add_argument("--seed", type=int, required=True, help="Model-initialization seed")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-root", type=Path, default=PACKAGE_ROOT / "results")
    parser.add_argument("--iterations", type=int, default=None)
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--allow-cpu", action="store_true")
    parser.add_argument(
        "--allow-nonprotocol-seed",
        action="store_true",
        help="Permit a seed outside the frozen 0/1/2 campaign (never use for the paper table)",
    )
    arguments = parser.parse_args()

    protocol = load_protocol()
    allowed_seeds = [int(seed) for seed in protocol["model_seeds"]]
    if arguments.seed not in allowed_seeds and not arguments.allow_nonprotocol_seed:
        parser.error(
            f"Seed {arguments.seed} is outside the frozen campaign {allowed_seeds}; "
            "use --allow-nonprotocol-seed only for diagnostics"
        )
    case_config = load_case(arguments.case)
    output_dir = (
        arguments.output_root
        / arguments.case
        / arguments.model
        / f"seed_{arguments.seed}"
    )
    run_training(
        case_config=case_config,
        protocol=protocol,
        model_name=arguments.model,
        model_seed=arguments.seed,
        output_dir=output_dir,
        device_name=arguments.device,
        iterations=arguments.iterations,
        resume=not arguments.no_resume,
        allow_cpu=arguments.allow_cpu,
    )

