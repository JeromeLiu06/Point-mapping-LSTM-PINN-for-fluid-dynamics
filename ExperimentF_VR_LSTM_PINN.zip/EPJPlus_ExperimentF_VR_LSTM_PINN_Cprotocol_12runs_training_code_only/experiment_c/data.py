from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .config import sha256_file


def load_locked_dataset(path: Path, expected_sha256: str) -> dict[str, torch.Tensor]:
    actual = sha256_file(path)
    if actual.lower() != expected_sha256.lower():
        raise RuntimeError(
            f"Frozen dataset hash mismatch for {path}: expected {expected_sha256}, got {actual}"
        )
    with np.load(path, allow_pickle=False) as archive:
        return {
            key: torch.from_numpy(np.asarray(archive[key])).float()
            if archive[key].dtype.kind == "f"
            else torch.from_numpy(np.asarray(archive[key]))
            for key in archive.files
        }


def validate_dataset_shapes(arrays: dict[str, torch.Tensor], expected: dict[str, list[int]]) -> None:
    failures = []
    for key, shape in expected.items():
        if key not in arrays:
            failures.append(f"missing {key}")
        elif list(arrays[key].shape) != shape:
            failures.append(f"{key}: expected {shape}, got {list(arrays[key].shape)}")
    if failures:
        raise RuntimeError("Frozen dataset structure mismatch: " + "; ".join(failures))


def _stable_seed(base_seed: int, case: str, key: str) -> int:
    text = f"{base_seed}:{case}:{key}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(text).digest()[:8], "little") % (2**63 - 1)


class FixedSampler:
    """Independent CPU generators keep minibatch order fixed across model seeds."""

    def __init__(self, base_seed: int, case: str):
        self.base_seed = int(base_seed)
        self.case = case
        self.generators: dict[str, torch.Generator] = {}

    def _generator(self, key: str) -> torch.Generator:
        if key not in self.generators:
            generator = torch.Generator(device="cpu")
            generator.manual_seed(_stable_seed(self.base_seed, self.case, key))
            self.generators[key] = generator
        return self.generators[key]

    def draw(
        self,
        arrays: dict[str, torch.Tensor],
        key: str,
        token_batch: int,
        device: torch.device,
    ) -> torch.Tensor:
        source = arrays[key]
        windows = max(1, token_batch // int(source.shape[1]))
        index = torch.randint(
            0,
            len(source),
            (windows,),
            generator=self._generator(key),
            device="cpu",
        )
        return source[index].to(device, non_blocking=True)

    def draw_pair(
        self,
        arrays: dict[str, torch.Tensor],
        key_a: str,
        key_b: str,
        token_batch: int,
        device: torch.device,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        a, b = arrays[key_a], arrays[key_b]
        if len(a) != len(b):
            raise RuntimeError(f"Paired arrays {key_a}/{key_b} have different lengths")
        windows = max(1, token_batch // int(a.shape[1]))
        pair_key = f"{key_a}|{key_b}"
        index = torch.randint(
            0,
            len(a),
            (windows,),
            generator=self._generator(pair_key),
            device="cpu",
        )
        return a[index].to(device, non_blocking=True), b[index].to(device, non_blocking=True)

    def state_dict(self) -> dict[str, Any]:
        return {key: generator.get_state() for key, generator in self.generators.items()}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        for key, generator_state in state.items():
            self._generator(key).set_state(generator_state)

