# Experiment E — S-LSTM-PINN sequence length

Run lengths 1, 2, 4 and 8 in each of four cases (16 configurations).
S-LSTM-PINN uses two recurrent layers of width 192. Model and data seeds
are 0. Cases I and III use earlier times at the same spatial point, with
spacings 0.125 and 0.05. Cases II and IV use ordered spatial neighbors.
The residual is evaluated at the final token.

Lengths 1, 2 and 4 use 30,000 updates. Length 8 defaults to the archived
300-update cost pilot. Use `--length 8 --full-m8` to start a new 30,000-update
comparison. The published length-8 evidence is the pilot.

```sh
python train.py --case 1 --length 4
python train.py --case 4 --length 8 --smoke
python train.py --case 4 --length 8 --full-m8
```

Cases I–IV are the manufactured Taylor–Green vortex, manufactured steady cavity,
manufactured Rayleigh–Bénard convection and conventional lid-driven cavity at
Re = 100. Install Python 3.8+ with NumPy, PyTorch and Matplotlib. The
tested environment used Python 3.8.20, PyTorch 2.2.2 and CUDA 12.1.

Case IV includes the N=256 FEM v4 reference in `data/`. Evaluation samples
u, v and p by bilinear interpolation using the stored [y,x] layout. The grid
export includes raw and constant-aligned pressure. The reference enters
evaluation only. `metrics/case4_velocity.json` gives both the componentwise
mean relative L2 and the joint velocity-vector relative L2. Pressure RMSE is
reported separately. Field arrays, training history and the final checkpoint
are written under `runs/` or the directory supplied with `--output`.

Append `--smoke` for two optimizer updates, validation and field export with
reduced batches and a 16 × 16 evaluation grid. Model width and depth are
preserved. Add `--plots` to include figures during a smoke run.
