from .cavity_reference import REFERENCE, load_fem_reference, interpolate_fem, evaluate_grid, save_velocity_metrics
import os, csv, json, math, time, platform
from dataclasses import dataclass, asdict
from typing import Dict, Tuple, List, Any
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
MODEL_KIND = 'S-LSTM-PINN-m1'
MODEL_SEED = 0
DATA_SEED = 0

@dataclass
class Config:
    write_plots: bool = True
    case_name: str = 'Lid2'
    model_name: str = MODEL_KIND
    device: str = 'cuda' if torch.cuda.is_available() else 'cpu'
    dtype: torch.dtype = torch.float32
    Re: float = 100.0
    nu: float = 0.01
    x0: float = 0.0
    x1: float = 1.0
    y0: float = 0.0
    y1: float = 1.0
    n_col: int = 22000
    n_bc_bottom: int = 2200
    n_bc_top: int = 2200
    n_bc_left: int = 2200
    n_bc_right: int = 2200
    train_ratio: float = 0.7
    iters: int = 30000
    lr: float = 0.0001
    batch_col: int = 1024
    batch_bc: int = 256
    val_batch_col: int = 512
    val_batch_bc: int = 256
    val_metric_points: int = 4000
    eval_every: int = 500
    grad_clip: float = 1.0
    w_mom: float = 1.0
    w_div: float = 1.0
    w_bc: float = 10.0
    pinn_hidden: int = 128
    pinn_layers: int = 8
    param_hidden: int = 280
    param_layers: int = 9
    lstm_hidden: int = 192
    lstm_layers: int = 2
    sequence_length: int = 1
    eval_nx: int = 120
    eval_ny: int = 120
    rel_l2_thresholds: Tuple[float, float] = (0.01, 0.001)
    fem_reference_path: str = str(REFERENCE)
    data_seed: int = DATA_SEED
    model_seed: int = MODEL_SEED
    out_dir: str = './sequence_length_30k/case4_Lid2/m1'

def ensure_dir(p):
    if p:
        os.makedirs(p, exist_ok=True)

def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def count_trainable_parameters(m):
    return sum((p.numel() for p in m.parameters() if p.requires_grad))

def count_total_parameters(m):
    return sum((p.numel() for p in m.parameters()))

def parameter_size_mb(m):
    return sum((p.numel() * p.element_size() for p in m.parameters())) / 1024 ** 2

def hardware_info(device):
    d = {'device': device, 'python_version': platform.python_version(), 'platform': platform.platform(), 'cpu_name': platform.processor() or platform.machine(), 'torch_version': torch.__version__, 'cuda_available': torch.cuda.is_available(), 'cuda_version': torch.version.cuda or 'None', 'gpu_count': torch.cuda.device_count() if torch.cuda.is_available() else 0, 'gpu_name': 'None', 'gpu_total_memory_MB': 0.0}
    if torch.cuda.is_available() and device.startswith('cuda'):
        p = torch.cuda.get_device_properties(torch.cuda.current_device())
        d['gpu_name'] = p.name
        d['gpu_total_memory_MB'] = p.total_memory / 1024 ** 2
    return d

def peak_gpu(device):
    if torch.cuda.is_available() and device.startswith('cuda'):
        return (torch.cuda.max_memory_allocated() / 1024 ** 2, torch.cuda.max_memory_reserved() / 1024 ** 2)
    return (0.0, 0.0)

def write_csv(path, rows, fields=None):
    ensure_dir(os.path.dirname(path))
    fields = fields or (list(rows[0].keys()) if rows else [])
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def write_history(path, h):
    ensure_dir(os.path.dirname(path))
    keys = list(h.keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(keys)
        for i in range(len(h[keys[0]])):
            w.writerow([h[k][i] for k in keys])

def metrics_np(pred, ref):
    p = np.asarray(pred).reshape(-1)
    r = np.asarray(ref).reshape(-1)
    d = p - r
    mse = float(np.mean(d * d))
    l2 = float(np.linalg.norm(d))
    return {'MSE': mse, 'RMSE': float(np.sqrt(mse)), 'MAE': float(np.mean(np.abs(d))), 'L2': l2, 'RelL2': float(l2 / (np.linalg.norm(r) + 1e-12)), 'MaxAbsError': float(np.max(np.abs(d))), 'MeanAbsError': float(np.mean(np.abs(d)))}

def metrics_torch(pred, ref):
    d = pred.detach() - ref.detach()
    mse = torch.mean(d * d)
    l2 = torch.linalg.norm(d.reshape(-1))
    return {'MSE': float(mse.item()), 'RMSE': float(torch.sqrt(mse).item()), 'MAE': float(torch.mean(torch.abs(d)).item()), 'L2': float(l2.item()), 'RelL2': float((l2 / (torch.linalg.norm(ref.detach().reshape(-1)) + 1e-12)).item()), 'MaxAbsError': float(torch.max(torch.abs(d)).item()), 'MeanAbsError': float(torch.mean(torch.abs(d)).item())}

def rand_fixed(n, lo, hi, device, dtype, seed):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    return lo + (hi - lo) * torch.rand(n, 1, generator=g, device=device, dtype=dtype)

def split_fixed(n, ratio, seed, device):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    idx = torch.randperm(n, generator=g, device=device)
    ntr = max(1, min(int(ratio * n), n - 1))
    return (idx[:ntr], idx[ntr:])

def _part1by1(v):
    v = v.astype(np.uint32)
    v = (v | v << 8) & 16711935
    v = (v | v << 4) & 252645135
    v = (v | v << 2) & 858993459
    v = (v | v << 1) & 1431655765
    return v

def morton_order(x, y, bits=16):
    xn = np.clip(x.detach().cpu().numpy().reshape(-1), 0, 1)
    yn = np.clip(y.detach().cpu().numpy().reshape(-1), 0, 1)
    scale = float((1 << bits) - 1)
    xi = (xn * scale).astype(np.uint32)
    yi = (yn * scale).astype(np.uint32)
    key = _part1by1(xi) | _part1by1(yi) << 1
    return torch.as_tensor(np.argsort(key), device=x.device, dtype=torch.long)

def build_spatial_contexts(x, y, m, side=None):
    if side in ('bottom', 'top'):
        order = torch.argsort(x[:, 0])
    elif side in ('left', 'right'):
        order = torch.argsort(y[:, 0])
    else:
        order = morton_order(x, y)
    xs, ys = (x[order], y[order])
    n = xs.shape[0]
    ids = torch.arange(n, device=x.device)
    offs = torch.arange(m - 1, -1, -1, device=x.device)
    ctx = torch.clamp(ids[:, None] - offs[None, :], min=0)
    seq_sorted = torch.stack([xs[ctx, 0], ys[ctx, 0], torch.zeros_like(xs[ctx, 0])], dim=2)
    inv = torch.empty_like(order)
    inv[order] = torch.arange(n, device=x.device)
    return seq_sorted[inv]

def make_boundary(c, n, kind, seed):
    if kind == 'bottom':
        x = rand_fixed(n, 0, 1, c.device, c.dtype, seed)
        y = torch.zeros_like(x)
    elif kind == 'top':
        x = rand_fixed(n, 0, 1, c.device, c.dtype, seed)
        y = torch.ones_like(x)
    elif kind == 'left':
        y = rand_fixed(n, 0, 1, c.device, c.dtype, seed)
        x = torch.zeros_like(y)
    elif kind == 'right':
        y = rand_fixed(n, 0, 1, c.device, c.dtype, seed)
        x = torch.ones_like(y)
    ur = torch.ones_like(x) if kind == 'top' else torch.zeros_like(x)
    vr = torch.zeros_like(x)
    return (x, y, ur, vr)

def split_bundle(bundle, tr, va):
    return (tuple((a[tr] for a in bundle)), tuple((a[va] for a in bundle)))

def build_dataset(c):
    s = c.data_seed
    x = rand_fixed(c.n_col, c.x0, c.x1, c.device, c.dtype, s + 11)
    y = rand_fixed(c.n_col, c.y0, c.y1, c.device, c.dtype, s + 12)
    tr, va = split_fixed(c.n_col, c.train_ratio, s + 101, c.device)
    col_tr = (x[tr], y[tr])
    col_va = (x[va], y[va])
    bc = {}
    for kind, n, off in (('bottom', c.n_bc_bottom, 201), ('top', c.n_bc_top, 202), ('left', c.n_bc_left, 203), ('right', c.n_bc_right, 204)):
        full = make_boundary(c, n, kind, s + 1000 + off)
        tri, vai = split_fixed(n, c.train_ratio, s + off, c.device)
        bc[kind + '_tr'], bc[kind + '_va'] = split_bundle(full, tri, vai)
    col_seq_tr = build_spatial_contexts(col_tr[0], col_tr[1], c.sequence_length)
    col_seq_va = build_spatial_contexts(col_va[0], col_va[1], c.sequence_length)
    for kind in ('bottom', 'top', 'left', 'right'):
        bt = bc[kind + '_tr']
        bv = bc[kind + '_va']
        bc[kind + '_seq_tr'] = build_spatial_contexts(bt[0], bt[1], c.sequence_length, kind)
        bc[kind + '_seq_va'] = build_spatial_contexts(bv[0], bv[1], c.sequence_length, kind)
    g = torch.Generator(device=c.device)
    g.manual_seed(s + 505)
    vidx = torch.randperm(col_va[0].shape[0], generator=g, device=c.device)[:min(c.val_metric_points, col_va[0].shape[0])]
    return {'col_tr': col_tr, 'col_va': col_va, 'col_seq_tr': col_seq_tr, 'col_seq_va': col_seq_va, **bc, 'val_metric_idx': vidx}

def minibatch_indices(n, batch, seed, device):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    return torch.randperm(n, generator=g, device=device)[:min(batch, n)]

def select_bundle(bundle, idx):
    return tuple((a[idx] for a in bundle))

class FFPINN(nn.Module):

    def __init__(self, in_dim, width, depth):
        super().__init__()
        layers = [nn.Linear(in_dim, width), nn.Tanh()]
        for _ in range(depth - 1):
            layers += [nn.Linear(width, width), nn.Tanh()]
        layers += [nn.Linear(width, 3)]
        self.net = nn.Sequential(*layers)

    def forward(self, x, y):
        o = self.net(torch.cat([x, y], dim=1))
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3])

class SpatialLSTM(nn.Module):

    def __init__(self, c):
        super().__init__()
        self.embed = nn.Linear(3, c.lstm_hidden)
        self.lstm = nn.LSTM(c.lstm_hidden, c.lstm_hidden, num_layers=c.lstm_layers, batch_first=True)
        self.head = nn.Sequential(nn.Linear(c.lstm_hidden, c.lstm_hidden), nn.Tanh(), nn.Linear(c.lstm_hidden, 3))

    def target(self, seq):
        z = self.embed(seq)
        with torch.backends.cudnn.flags(enabled=False):
            z, _ = self.lstm(z)
        o = self.head(z[:, -1, :])
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3])

def build_model(c):
    if c.model_name == 'PINN':
        return FFPINN(2, c.pinn_hidden, c.pinn_layers)
    if c.model_name == 'Param-PINN':
        return FFPINN(2, c.param_hidden, c.param_layers)
    if c.model_name.startswith('S-LSTM-PINN-m'):
        return SpatialLSTM(c)
    raise ValueError(c.model_name)

def predict_targets(c, m, x, y, seq=None):
    return m.target(seq) if c.model_name.startswith('S-LSTM-PINN-m') else m(x, y)

def grad1(u, x):
    return torch.autograd.grad(u, x, torch.ones_like(u), create_graph=True, retain_graph=True)[0]

def lap2(u, x, y):
    ux = grad1(u, x)
    uy = grad1(u, y)
    return (ux, uy, grad1(ux, x) + grad1(uy, y))

def grad_last(u, seq, k):
    return torch.autograd.grad(u, seq, torch.ones_like(u), create_graph=True, retain_graph=True)[0][:, -1, k:k + 1]

def bc_loss_ff(m, b):
    x, y, ur, vr = b
    u, v, _ = m(x, y)
    return torch.mean((u - ur) ** 2) + torch.mean((v - vr) ** 2)

def bc_loss_lstm(m, b, seq):
    _, _, ur, vr = b
    u, v, _ = m.target(seq)
    return torch.mean((u - ur) ** 2) + torch.mean((v - vr) ** 2)

def pde_parts_ff(c, m, col):
    x0, y0 = col
    x = x0.detach().clone().requires_grad_(True)
    y = y0.detach().clone().requires_grad_(True)
    u, v, p = m(x, y)
    ux, uy, lu = lap2(u, x, y)
    vx, vy, lv = lap2(v, x, y)
    px, py = (grad1(p, x), grad1(p, y))
    ru = u * ux + v * uy + px - c.nu * lu
    rv = u * vx + v * vy + py - c.nu * lv
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    ld = torch.mean((ux + vy) ** 2)
    return (lm + ld, lm, ld)

def pde_parts_lstm(c, m, col_seq):
    seq = col_seq.detach().clone().requires_grad_(True)
    u, v, p = m.target(seq)
    ux, uy = (grad_last(u, seq, 0), grad_last(u, seq, 1))
    vx, vy = (grad_last(v, seq, 0), grad_last(v, seq, 1))
    px, py = (grad_last(p, seq, 0), grad_last(p, seq, 1))
    uxx, uyy = (grad_last(ux, seq, 0), grad_last(uy, seq, 1))
    vxx, vyy = (grad_last(vx, seq, 0), grad_last(vy, seq, 1))
    ru = u * ux + v * uy + px - c.nu * (uxx + uyy)
    rv = u * vx + v * vy + py - c.nu * (vxx + vyy)
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    ld = torch.mean((ux + vy) ** 2)
    return (lm + ld, lm, ld)

def total_loss(c, m, col, col_seq, bcs, seqs):
    if c.model_name.startswith('S-LSTM-PINN-m'):
        lpde, lmom, ldiv = pde_parts_lstm(c, m, col_seq)
        lbc = sum((bc_loss_lstm(m, b, s) for b, s in zip(bcs, seqs)))
    else:
        lpde, lmom, ldiv = pde_parts_ff(c, m, col)
        lbc = sum((bc_loss_ff(m, b) for b in bcs))
    total = c.w_mom * lmom + c.w_div * ldiv + c.w_bc * lbc
    z = torch.zeros((), device=col[0].device, dtype=col[0].dtype)
    return (total, {'pde': lpde, 'mom': lmom, 'div': ldiv, 'ic': z, 'bc': lbc})

def fem_targets(c, ref, x, y):
    q = interpolate_fem(ref, x.detach().cpu().numpy().reshape(-1), y.detach().cpu().numpy().reshape(-1))
    ur = torch.as_tensor(q['u'].reshape(-1, 1), device=c.device, dtype=c.dtype)
    vr = torch.as_tensor(q['v'].reshape(-1, 1), device=c.device, dtype=c.dtype)
    pr = torch.as_tensor(q['p'].reshape(-1, 1), device=c.device, dtype=c.dtype)
    return (ur, vr, pr)

@torch.no_grad()
def data_parts(c, m, x, y, ref, seq=None):
    ur, vr, pr = fem_targets(c, ref, x, y)
    u, v, p = predict_targets(c, m, x, y, seq)
    p = p - torch.mean(p)
    pr = pr - torch.mean(pr)
    sr = torch.sqrt(ur ** 2 + vr ** 2)
    sp = torch.sqrt(u ** 2 + v ** 2)
    d = {'data_u': torch.mean((u - ur) ** 2), 'data_v': torch.mean((v - vr) ** 2), 'data_p': torch.mean((p - pr) ** 2), 'data_speed': torch.mean((sp - sr) ** 2)}
    d['data_total'] = d['data_u'] + d['data_v'] + d['data_p'] + d['data_speed']
    return d

@torch.no_grad()
def evaluate_val(c, m, d, ref):
    idx = d['val_metric_idx']
    x, y = d['col_va']
    x, y = (x[idx], y[idx])
    seq = d['col_seq_va'][idx] if c.model_name.startswith('S-LSTM-PINN-m') else None
    ur, vr, pr = fem_targets(c, ref, x, y)
    u, v, p = predict_targets(c, m, x, y, seq)
    p = p - torch.mean(p)
    pr = pr - torch.mean(pr)
    sr = torch.sqrt(ur ** 2 + vr ** 2)
    sp = torch.sqrt(u ** 2 + v ** 2)
    return metrics_torch(torch.cat([u, v, p, sp], dim=1), torch.cat([ur, vr, pr, sr], dim=1))

def eval_grid(c, m, ref):
    g = evaluate_grid(c, m, ref, build_spatial_contexts, predict_targets)
    save_velocity_metrics(c.out_dir, g)
    return g

def make_dirs(c):
    for s in ('', 'field_data/steady', 'metrics', 'cost', 'loss', 'figures/reference', 'figures/prediction', 'figures/error', 'figures/loss', 'config'):
        ensure_dir(os.path.join(c.out_dir, s))

def save_model_info(c, m):
    with open(os.path.join(c.out_dir, 'model_info.txt'), 'w', encoding='utf-8') as f:
        pairs = [('Case', c.case_name), ('Model', c.model_name), ('Problem', 'standard lid-driven cavity'), ('Re', c.Re), ('nu', c.nu), ('Data seed', c.data_seed), ('Model seed', c.model_seed), ('Trainable parameters', count_trainable_parameters(m)), ('Total parameters', count_total_parameters(m)), ('Parameter size MB', f'{parameter_size_mb(m):.6f}'), ('Optimizer', 'Adam'), ('Learning rate', c.lr), ('Iterations', c.iters), ('Batch collocation', c.batch_col), ('Batch BC', c.batch_bc), ('Sequence length', c.sequence_length if c.model_name.startswith('S-LSTM-PINN-m') else 1), ('FEM reference', c.fem_reference_path), ('Pressure comparison', 'mean-free')]
        for k, v in pairs:
            f.write(f'{k}: {v}\n')

def save_field_data(c, g):
    xx, yy = np.meshgrid(g['x'], g['y'], indexing='xy')
    od = os.path.join(c.out_dir, 'field_data', 'steady')
    for f in ('u', 'v', 'p', 'speed'):
        pred, ref = (g[f + '_pred'], g[f + '_ref'])
        e = pred - ref
        arr = np.column_stack([xx.ravel(), yy.ravel(), pred.ravel(), ref.ravel(), e.ravel(), np.abs(e).ravel()])
        np.savetxt(os.path.join(od, f'{f}_field_data.txt'), arr, fmt='%.10e', delimiter='\t', header='x\ty\tPrediction\tReference\tError\tAbsError', comments='')

def save_metrics(c, g):
    rows = []
    ap = []
    ar = []
    for f in ('u', 'v', 'p', 'speed'):
        pred, ref = (g[f + '_pred'], g[f + '_ref'])
        mm = metrics_np(pred, ref)
        rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'time': 'steady', 'field': f, **mm})
        ap.append(pred.ravel())
        ar.append(ref.ravel())
    write_csv(os.path.join(c.out_dir, 'metrics', 'field_metrics.csv'), rows)
    mm = metrics_np(np.concatenate(ap), np.concatenate(ar))
    write_csv(os.path.join(c.out_dir, 'metrics', 'overall_metrics.csv'), [{'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, **mm}])
    return mm

def save_plots(c, g, h):
    if not c.write_plots:
        return
    extent = [0, 1, 0, 1]
    for f in ('u', 'v', 'p', 'speed'):
        for folder, key, title in (('reference', f + '_ref', 'Reference'), ('prediction', f + '_pred', 'Prediction'), ('error', f + '_err', 'Absolute error')):
            a = np.abs(g[key]) if folder == 'error' else g[key]
            plt.figure(figsize=(5.6, 4.6))
            plt.imshow(a, origin='lower', extent=extent, aspect='auto')
            plt.colorbar()
            plt.xlabel('x')
            plt.ylabel('y')
            plt.title(f'{title} {f}')
            plt.tight_layout()
            plt.savefig(os.path.join(c.out_dir, 'figures', folder, f'{f}_{folder}.png'), dpi=220)
            plt.close()
    ix = int(np.argmin(np.abs(g['x'] - 0.5)))
    iy = int(np.argmin(np.abs(g['y'] - 0.5)))
    plt.figure(figsize=(7, 4))
    plt.plot(g['y'], g['u_ref'][:, ix], label='FEM u @ x≈0.5')
    plt.plot(g['y'], g['u_pred'][:, ix], '--', label='PINN u @ x≈0.5')
    plt.legend()
    plt.xlabel('y')
    plt.ylabel('u')
    plt.tight_layout()
    plt.savefig(os.path.join(c.out_dir, 'figures', 'prediction', 'centerline_u.png'), dpi=220)
    plt.close()
    plt.figure(figsize=(7, 4))
    plt.plot(g['x'], g['v_ref'][iy, :], label='FEM v @ y≈0.5')
    plt.plot(g['x'], g['v_pred'][iy, :], '--', label='PINN v @ y≈0.5')
    plt.legend()
    plt.xlabel('x')
    plt.ylabel('v')
    plt.tight_layout()
    plt.savefig(os.path.join(c.out_dir, 'figures', 'prediction', 'centerline_v.png'), dpi=220)
    plt.close()
    pairs = [('loss_total_train', 'loss_total_val', 'total'), ('loss_pde_train', 'loss_pde_val', 'pde'), ('loss_mom_train', 'loss_mom_val', 'mom'), ('loss_div_train', 'loss_div_val', 'div'), ('loss_bc_train', 'loss_bc_val', 'bc'), ('loss_data_train', 'loss_data_val', 'data'), ('RelL2_val', None, 'rel_l2')]
    for tr, va, name in pairs:
        plt.figure(figsize=(7, 4))
        plt.plot(h['iter'], h[tr], label=tr)
        if va:
            plt.plot(h['iter'], h[va], label=va)
        plt.yscale('log')
        plt.xlabel('iteration')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(c.out_dir, 'figures', 'loss', f'{name}_curve.png'), dpi=220)
        plt.close()

def save_cost(c, m, h, itimes, total, best_it, best_rel, final_rel):
    hw = hardware_info(c.device)
    pa, pr = peak_gpu(c.device)
    row = {'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'trainable_parameters': count_trainable_parameters(m), 'total_parameters': count_total_parameters(m), 'parameter_size_MB': parameter_size_mb(m), 'total_iterations_configured': c.iters, 'total_iterations_completed': h['iter'][-1], 'total_wall_time_sec': total, 'total_wall_time_min': total / 60, 'mean_time_per_iter_sec': float(np.mean(itimes)), 'median_time_per_iter_sec': float(np.median(itimes)), 'peak_gpu_memory_allocated_MB': pa, 'peak_gpu_memory_reserved_MB': pr, 'best_iter': best_it, 'best_RelL2': best_rel, 'final_RelL2': final_rel, **hw}
    write_csv(os.path.join(c.out_dir, 'cost', 'model_cost_summary.csv'), [row])
    rows = []
    for th in c.rel_l2_thresholds:
        hit = next(((it, r, t) for it, r, t in zip(h['iter'], h['RelL2_val'], h['time_elapsed_sec']) if r <= th), None)
        rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'metric': 'RelL2', 'threshold': th, 'reached': hit is not None, 'iter_to_threshold': -1 if hit is None else hit[0], 'time_to_threshold_sec': -1 if hit is None else hit[2]})
    write_csv(os.path.join(c.out_dir, 'cost', 'threshold_cost.csv'), rows)

def init_history():
    keys = ['iter', 'loss_total_train', 'loss_total_val', 'loss_pde_train', 'loss_pde_val', 'loss_mom_train', 'loss_mom_val', 'loss_div_train', 'loss_div_val', 'loss_ic_train', 'loss_ic_val', 'loss_bc_train', 'loss_bc_val', 'loss_data_train', 'loss_data_val', 'loss_data_u_train', 'loss_data_u_val', 'loss_data_v_train', 'loss_data_v_val', 'loss_data_p_train', 'loss_data_p_val', 'loss_data_speed_train', 'loss_data_speed_val', 'MSE_val', 'RMSE_val', 'MAE_val', 'L2_val', 'RelL2_val', 'MaxAbsError_val', 'MeanAbsError_val', 'time_elapsed_sec']
    return {k: [] for k in keys}

def append_history(h, row):
    for k in h:
        h[k].append(row.get(k, 0.0))

def prepare_batch(c, d, split, it):
    s = c.data_seed
    col_key = 'col_' + split
    col_n = d[col_key][0].shape[0]
    col_batch = c.batch_col if split == 'tr' else c.val_batch_col
    ci = minibatch_indices(col_n, col_batch, s + (100000 if split == 'tr' else 500000) + it, c.device)
    col = select_bundle(d[col_key], ci)
    col_seq = d['col_seq_' + split][ci]
    bcs = []
    seqs = []
    base = 200000 if split == 'tr' else 600000
    for j, kind in enumerate(('bottom', 'top', 'left', 'right')):
        key = kind + '_' + split
        bn = d[key][0].shape[0]
        bb = c.batch_bc if split == 'tr' else c.val_batch_bc
        bi = minibatch_indices(bn, bb, s + base + j * 100000 + it, c.device)
        bcs.append(select_bundle(d[key], bi))
        seqs.append(d[kind + '_seq_' + split][bi])
    return (col, col_seq, bcs, seqs)

def train(c=Config()):
    make_dirs(c)
    fem_ref = load_fem_reference(c.fem_reference_path)
    d = build_dataset(c)
    set_seed(c.model_seed)
    m = build_model(c).to(c.device, c.dtype)
    opt = torch.optim.Adam(m.parameters(), lr=c.lr)
    if torch.cuda.is_available() and c.device.startswith('cuda'):
        torch.cuda.reset_peak_memory_stats()
    save_model_info(c, m)
    with open(os.path.join(c.out_dir, 'config', 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(asdict(c), f, indent=2, default=str)
    with open(os.path.join(c.out_dir, 'config', 'environment.json'), 'w', encoding='utf-8') as f:
        json.dump(hardware_info(c.device), f, indent=2, default=str)
    h = init_history()
    itimes = []
    best = float('inf')
    best_it = -1
    t_start = time.time()
    print(f'[INFO] {c.case_name} | {c.model_name}')
    print(f'[INFO] data_seed={c.data_seed} model_seed={c.model_seed}')
    print(f'[INFO] params={count_trainable_parameters(m):,}')
    print(f'[INFO] FEM reference={c.fem_reference_path}')
    print(f'[INFO] output={os.path.abspath(c.out_dir)}')
    for it in range(1, c.iters + 1):
        ts = time.time()
        m.train()
        opt.zero_grad(set_to_none=True)
        col, col_seq, bcs, seqs = prepare_batch(c, d, 'tr', it)
        loss, p = total_loss(c, m, col, col_seq, bcs, seqs)
        if not torch.isfinite(loss):
            raise RuntimeError(f'Non-finite loss at iteration {it}')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), c.grad_clip)
        opt.step()
        itimes.append(time.time() - ts)
        if it == 1 or it % c.eval_every == 0:
            m.eval()
            cv, csv, bv, sv = prepare_batch(c, d, 'va', it)
            lv, pv = total_loss(c, m, cv, csv, bv, sv)
            vm = evaluate_val(c, m, d, fem_ref)
            dtr = data_parts(c, m, col[0], col[1], fem_ref, col_seq if c.model_name.startswith('S-LSTM-PINN-m') else None)
            dva = data_parts(c, m, cv[0], cv[1], fem_ref, csv if c.model_name.startswith('S-LSTM-PINN-m') else None)
            elapsed = time.time() - t_start
            row = {'iter': it, 'loss_total_train': float(loss.item()), 'loss_total_val': float(lv.item()), 'loss_pde_train': float(p['pde'].item()), 'loss_pde_val': float(pv['pde'].item()), 'loss_mom_train': float(p['mom'].item()), 'loss_mom_val': float(pv['mom'].item()), 'loss_div_train': float(p['div'].item()), 'loss_div_val': float(pv['div'].item()), 'loss_ic_train': 0.0, 'loss_ic_val': 0.0, 'loss_bc_train': float(p['bc'].item()), 'loss_bc_val': float(pv['bc'].item()), 'loss_data_train': float(dtr['data_total'].item()), 'loss_data_val': float(dva['data_total'].item()), 'loss_data_u_train': float(dtr['data_u'].item()), 'loss_data_u_val': float(dva['data_u'].item()), 'loss_data_v_train': float(dtr['data_v'].item()), 'loss_data_v_val': float(dva['data_v'].item()), 'loss_data_p_train': float(dtr['data_p'].item()), 'loss_data_p_val': float(dva['data_p'].item()), 'loss_data_speed_train': float(dtr['data_speed'].item()), 'loss_data_speed_val': float(dva['data_speed'].item()), **{k + '_val': v for k, v in vm.items()}, 'time_elapsed_sec': elapsed}
            append_history(h, row)
            write_history(os.path.join(c.out_dir, 'loss', 'train_history.csv'), h)
            if vm['RelL2'] < best:
                best = vm['RelL2']
                best_it = it
                torch.save({'iter': it, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'best_rel_l2': best, 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'best_model.pt'))
            print(f"[{it:06d}] loss={loss.item():.3e} val={lv.item():.3e} FEM-RelL2={vm['RelL2']:.3e} elapsed={elapsed / 60:.1f} min")
    total = time.time() - t_start
    torch.save({'iter': c.iters, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'final_rel_l2_val': h['RelL2_val'][-1], 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'final_model.pt'))
    m.eval()
    g = eval_grid(c, m, fem_ref)
    np.savez(os.path.join(c.out_dir, 'grid.npz'), **g)
    save_field_data(c, g)
    overall = save_metrics(c, g)
    save_plots(c, g, h)
    save_cost(c, m, h, itimes, total, best_it, best, overall['RelL2'])
    print(f"[DONE] {c.model_name} seed={c.model_seed} best={best:.6e} final_grid={overall['RelL2']:.6e}")
    return (m, h)
