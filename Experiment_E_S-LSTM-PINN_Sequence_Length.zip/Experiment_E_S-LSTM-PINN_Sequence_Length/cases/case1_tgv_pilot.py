import os, csv, json, math, time, platform
from dataclasses import dataclass, asdict
from typing import Dict, Tuple, List, Any
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
MODEL_KIND = 'S-LSTM-PINN-m8'
MODEL_SEED = 0
DATA_SEED = 0
STOP_ITER = 300

@dataclass
class Config:
    write_plots: bool = True
    case_name: str = 'TGV'
    model_name: str = MODEL_KIND
    device: str = 'cuda' if torch.cuda.is_available() else 'cpu'
    dtype: torch.dtype = torch.float32
    nu: float = 0.1
    x0: float = 0.0
    x1: float = 2.0 * math.pi
    y0: float = 0.0
    y1: float = 2.0 * math.pi
    t0: float = 0.0
    t1: float = 5.0
    n_col: int = 20000
    n_ic: int = 2400
    n_bcx: int = 2400
    n_bcy: int = 2400
    train_ratio: float = 0.7
    iters: int = STOP_ITER
    lr: float = 0.0001
    batch_col: int = 1024
    batch_ic: int = 256
    batch_bcx: int = 256
    batch_bcy: int = 256
    val_batch_col: int = 512
    val_batch_ic: int = 256
    val_batch_bcx: int = 256
    val_batch_bcy: int = 256
    val_metric_points: int = 3000
    eval_every: int = 500
    grad_clip: float = 1.0
    w_mom: float = 1.0
    w_div: float = 1.0
    w_ic: float = 10.0
    w_bc: float = 1.0
    pinn_hidden: int = 128
    pinn_layers: int = 8
    param_hidden: int = 280
    param_layers: int = 9
    lstm_hidden: int = 192
    lstm_layers: int = 2
    sequence_length: int = 8
    temporal_dt: float = 0.125
    eval_nx: int = 80
    eval_ny: int = 80
    eval_times: Tuple[float, float, float] = (0.0, 2.5, 5.0)
    rel_l2_thresholds: Tuple[float, float] = (0.01, 0.001)
    data_seed: int = DATA_SEED
    model_seed: int = MODEL_SEED
    out_dir: str = './sequence_length_30k/case1_TGV/m8'

def ensure_dir(p):
    os.makedirs(p, exist_ok=True) if p else None

def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def count_trainable_parameters(m):
    return sum((p.numel() for p in m.parameters() if p.requires_grad))

def count_total_parameters(m):
    return sum((p.numel() for p in m.parameters()))

def parameter_size_mb(m):
    return sum((p.numel() * p.element_size() for p in m.parameters())) / 1024 ** 2

def hardware_info(device):
    d = {'device': device, 'python_version': platform.python_version(), 'platform': platform.platform(), 'cpu_name': platform.processor() or platform.machine(), 'torch_version': torch.__version__, 'cuda_available': torch.cuda.is_available(), 'cuda_version': torch.version.cuda or 'None', 'gpu_count': torch.cuda.device_count() if torch.cuda.is_available() else 0, 'gpu_name': 'None', 'gpu_total_memory_MB': 0.0}
    if torch.cuda.is_available() and device.startswith('cuda'):
        pr = torch.cuda.get_device_properties(torch.cuda.current_device())
        d['gpu_name'] = pr.name
        d['gpu_total_memory_MB'] = pr.total_memory / 1024 ** 2
    return d

def peak_gpu(device):
    if torch.cuda.is_available() and device.startswith('cuda'):
        return (torch.cuda.max_memory_allocated() / 1024 ** 2, torch.cuda.max_memory_reserved() / 1024 ** 2)
    return (0.0, 0.0)

def synchronize_device(device):
    if torch.cuda.is_available() and str(device).startswith('cuda'):
        torch.cuda.synchronize()

def time_tag(t):
    return f"t{str(round(float(t), 4)).replace('.', 'p')}"

def write_csv(path, rows, fields=None):
    ensure_dir(os.path.dirname(path))
    fields = fields or (list(rows[0].keys()) if rows else [])
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def write_history(path, h):
    ensure_dir(os.path.dirname(path))
    keys = list(h.keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(keys)
        for i in range(len(h[keys[0]])):
            w.writerow([h[k][i] for k in keys])

def metrics_np(pred, ref):
    p = np.asarray(pred).reshape(-1)
    r = np.asarray(ref).reshape(-1)
    d = p - r
    mse = float(np.mean(d * d))
    l2 = float(np.linalg.norm(d))
    return {'MSE': mse, 'RMSE': float(np.sqrt(mse)), 'MAE': float(np.mean(np.abs(d))), 'L2': l2, 'RelL2': float(l2 / (np.linalg.norm(r) + 1e-12)), 'MaxAbsError': float(np.max(np.abs(d))), 'MeanAbsError': float(np.mean(np.abs(d)))}

def metrics_torch(pred, ref):
    d = pred.detach() - ref.detach()
    mse = torch.mean(d * d)
    l2 = torch.linalg.norm(d.reshape(-1))
    return {'MSE': float(mse.item()), 'RMSE': float(torch.sqrt(mse).item()), 'MAE': float(torch.mean(torch.abs(d)).item()), 'L2': float(l2.item()), 'RelL2': float((l2 / (torch.linalg.norm(ref.detach().reshape(-1)) + 1e-12)).item()), 'MaxAbsError': float(torch.max(torch.abs(d)).item()), 'MeanAbsError': float(torch.mean(torch.abs(d)).item())}

def uvp_mms(x, y, t):
    e1 = torch.exp(-t)
    e2 = torch.exp(-2 * t)
    return (torch.sin(x) * torch.cos(y) * e1, -torch.cos(x) * torch.sin(y) * e1, 0.25 * (torch.cos(2 * x) + torch.cos(2 * y)) * e2)

def forcing_mms(x, y, t, nu):
    e1 = torch.exp(-t)
    return ((2 * nu - 1) * e1 * torch.sin(x) * torch.cos(y), (1 - 2 * nu) * e1 * torch.cos(x) * torch.sin(y))

def rand_fixed(n, lo, hi, device, dtype, seed):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    return lo + (hi - lo) * torch.rand(n, 1, generator=g, device=device, dtype=dtype)

def split_fixed(n, ratio, seed, device):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    idx = torch.randperm(n, generator=g, device=device)
    ntr = max(1, min(int(ratio * n), n - 1))
    return (idx[:ntr], idx[ntr:])

def build_dataset(c):
    s = c.data_seed
    xc = rand_fixed(c.n_col, c.x0, c.x1, c.device, c.dtype, s + 11)
    yc = rand_fixed(c.n_col, c.y0, c.y1, c.device, c.dtype, s + 12)
    tc = rand_fixed(c.n_col, c.t0, c.t1, c.device, c.dtype, s + 13)
    tr, va = split_fixed(c.n_col, c.train_ratio, s + 101, c.device)
    col_tr = (xc[tr], yc[tr], tc[tr])
    col_va = (xc[va], yc[va], tc[va])
    xi = rand_fixed(c.n_ic, c.x0, c.x1, c.device, c.dtype, s + 21)
    yi = rand_fixed(c.n_ic, c.y0, c.y1, c.device, c.dtype, s + 22)
    ti = torch.full_like(xi, c.t0)
    tr, va = split_fixed(c.n_ic, c.train_ratio, s + 202, c.device)
    ur, vr, pr = uvp_mms(xi[tr], yi[tr], ti[tr])
    uv, vv, pv = uvp_mms(xi[va], yi[va], ti[va])
    ic_tr = (xi[tr], yi[tr], ti[tr], ur.detach(), vr.detach(), pr.detach())
    ic_va = (xi[va], yi[va], ti[va], uv.detach(), vv.detach(), pv.detach())
    yx = rand_fixed(c.n_bcx, c.y0, c.y1, c.device, c.dtype, s + 31)
    tx = rand_fixed(c.n_bcx, c.t0, c.t1, c.device, c.dtype, s + 32)
    xl = torch.full_like(yx, c.x0)
    xr = torch.full_like(yx, c.x1)
    tr, va = split_fixed(c.n_bcx, c.train_ratio, s + 303, c.device)
    bcx_tr = (xl[tr], xr[tr], yx[tr], tx[tr])
    bcx_va = (xl[va], xr[va], yx[va], tx[va])
    xy = rand_fixed(c.n_bcy, c.x0, c.x1, c.device, c.dtype, s + 41)
    ty = rand_fixed(c.n_bcy, c.t0, c.t1, c.device, c.dtype, s + 42)
    yb = torch.full_like(xy, c.y0)
    yt = torch.full_like(xy, c.y1)
    tr, va = split_fixed(c.n_bcy, c.train_ratio, s + 404, c.device)
    bcy_tr = (xy[tr], yb[tr], yt[tr], ty[tr])
    bcy_va = (xy[va], yb[va], yt[va], ty[va])
    g = torch.Generator(device=c.device)
    g.manual_seed(s + 505)
    vidx = torch.randperm(col_va[0].shape[0], generator=g, device=c.device)[:min(c.val_metric_points, col_va[0].shape[0])]
    return {'col_tr': col_tr, 'col_va': col_va, 'ic_tr': ic_tr, 'ic_va': ic_va, 'bcx_tr': bcx_tr, 'bcx_va': bcx_va, 'bcy_tr': bcy_tr, 'bcy_va': bcy_va, 'val_metric_idx': vidx}

def minibatch(bundle, batch, seed):
    g = torch.Generator(device=bundle[0].device)
    g.manual_seed(seed)
    idx = torch.randperm(bundle[0].shape[0], generator=g, device=bundle[0].device)[:min(batch, bundle[0].shape[0])]
    return tuple((a[idx] for a in bundle))

class FFPINN(nn.Module):

    def __init__(self, width, depth):
        super().__init__()
        a = [nn.Linear(3, width), nn.Tanh()]
        for _ in range(depth - 1):
            a += [nn.Linear(width, width), nn.Tanh()]
        a += [nn.Linear(width, 3)]
        self.net = nn.Sequential(*a)

    def forward(self, x, y, t):
        o = self.net(torch.cat([x, y, t], 1))
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3])

class TemporalLSTM(nn.Module):

    def __init__(self, c):
        super().__init__()
        self.embed = nn.Linear(3, c.lstm_hidden)
        self.lstm = nn.LSTM(c.lstm_hidden, c.lstm_hidden, num_layers=c.lstm_layers, batch_first=True)
        self.head = nn.Sequential(nn.Linear(c.lstm_hidden, c.lstm_hidden), nn.Tanh(), nn.Linear(c.lstm_hidden, 3))

    def target(self, seq):
        z = self.embed(seq)
        with torch.backends.cudnn.flags(enabled=False):
            z, _ = self.lstm(z)
        o = self.head(z[:, -1, :])
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3])

def build_context(c, x, y, t):
    m = c.sequence_length
    offs = torch.arange(m - 1, -1, -1, device=x.device, dtype=x.dtype).view(1, m, 1) * c.temporal_dt
    th = torch.clamp(t[:, None, :] - offs, min=c.t0)
    return torch.cat([x[:, None, :].expand(-1, m, -1), y[:, None, :].expand(-1, m, -1), th], 2)

def build_model(c):
    if c.model_name == 'PINN':
        return FFPINN(c.pinn_hidden, c.pinn_layers)
    if c.model_name == 'Param-PINN':
        return FFPINN(c.param_hidden, c.param_layers)
    if c.model_name.startswith('S-LSTM-PINN-m'):
        return TemporalLSTM(c)
    raise ValueError(c.model_name)

def predict_points(c, m, x, y, t):
    return m.target(build_context(c, x, y, t)) if c.model_name.startswith('S-LSTM-PINN-m') else m(x, y, t)

def grad1(u, x):
    return torch.autograd.grad(u, x, torch.ones_like(u), create_graph=True, retain_graph=True)[0]

def lap2(u, x, y):
    ux = grad1(u, x)
    uy = grad1(u, y)
    return (ux, uy, grad1(ux, x) + grad1(uy, y))

def grad_last(u, seq, k):
    return torch.autograd.grad(u, seq, torch.ones_like(u), create_graph=True, retain_graph=True)[0][:, -1, k:k + 1]

def data_parts(c, m, x, y, t):
    ur, vr, pr = uvp_mms(x, y, t)
    u, v, p = predict_points(c, m, x, y, t)
    sr = torch.sqrt(ur ** 2 + vr ** 2)
    sp = torch.sqrt(u ** 2 + v ** 2)
    d = {'data_u': torch.mean((u - ur) ** 2), 'data_v': torch.mean((v - vr) ** 2), 'data_p': torch.mean((p - pr) ** 2), 'data_speed': torch.mean((sp - sr) ** 2)}
    d['data_total'] = d['data_u'] + d['data_v'] + d['data_p'] + d['data_speed']
    return d

def batch_losses_ff(c, m, col, ic, bcx, bcy):
    x0, y0, t0 = col
    x = x0.detach().clone().requires_grad_(True)
    y = y0.detach().clone().requires_grad_(True)
    t = t0.detach().clone().requires_grad_(True)
    u, v, p = m(x, y, t)
    ut, vt = (grad1(u, t), grad1(v, t))
    ux, uy, lu = lap2(u, x, y)
    vx, vy, lv = lap2(v, x, y)
    px, py = (grad1(p, x), grad1(p, y))
    fu, fv = forcing_mms(x0, y0, t0, c.nu)
    ru = ut + u * ux + v * uy + px - c.nu * lu - fu
    rv = vt + u * vx + v * vy + py - c.nu * lv - fv
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    ld = torch.mean((ux + vy) ** 2)
    xi, yi, ti, ui, vi, pi = ic
    up, vp, pp = m(xi, yi, ti)
    li = torch.mean((up - ui) ** 2) + torch.mean((vp - vi) ** 2) + torch.mean((pp - pi) ** 2)
    xL, xR, yb, tb = bcx
    xl = xL.detach().clone().requires_grad_(True)
    xr = xR.detach().clone().requires_grad_(True)
    yy = yb.detach().clone().requires_grad_(True)
    tt = tb.detach().clone().requires_grad_(True)
    uL, vL, pL = m(xl, yy, tt)
    uR, vR, pR = m(xr, yy, tt)
    lx = torch.mean((uL - uR) ** 2) + torch.mean((vL - vR) ** 2) + torch.mean((pL - pR) ** 2) + torch.mean((grad1(uL, xl) - grad1(uR, xr)) ** 2) + torch.mean((grad1(vL, xl) - grad1(vR, xr)) ** 2) + torch.mean((grad1(pL, xl) - grad1(pR, xr)) ** 2)
    xb, yB, yT, tb2 = bcy
    xx = xb.detach().clone().requires_grad_(True)
    yb2 = yB.detach().clone().requires_grad_(True)
    yt2 = yT.detach().clone().requires_grad_(True)
    tt2 = tb2.detach().clone().requires_grad_(True)
    uB, vB, pB = m(xx, yb2, tt2)
    uT, vT, pT = m(xx, yt2, tt2)
    ly = torch.mean((uB - uT) ** 2) + torch.mean((vB - vT) ** 2) + torch.mean((pB - pT) ** 2) + torch.mean((grad1(uB, yb2) - grad1(uT, yt2)) ** 2) + torch.mean((grad1(vB, yb2) - grad1(vT, yt2)) ** 2) + torch.mean((grad1(pB, yb2) - grad1(pT, yt2)) ** 2)
    lb = lx + ly
    dp = data_parts(c, m, x0, y0, t0)
    lp = lm + ld
    total = c.w_mom * lm + c.w_div * ld + c.w_ic * li + c.w_bc * lb
    return (total, {'pde': lp, 'mom': lm, 'div': ld, 'ic': li, 'bc': lb, 'data': dp['data_total'], 'data_u': dp['data_u'], 'data_v': dp['data_v'], 'data_p': dp['data_p'], 'data_speed': dp['data_speed']})

def batch_losses_lstm(c, m, col, ic, bcx, bcy):
    x0, y0, t0 = col
    seq = build_context(c, x0, y0, t0).detach().clone().requires_grad_(True)
    u, v, p = m.target(seq)
    ut, vt = (grad_last(u, seq, 2), grad_last(v, seq, 2))
    ux, uy = (grad_last(u, seq, 0), grad_last(u, seq, 1))
    vx, vy = (grad_last(v, seq, 0), grad_last(v, seq, 1))
    px, py = (grad_last(p, seq, 0), grad_last(p, seq, 1))
    uxx, uyy = (grad_last(ux, seq, 0), grad_last(uy, seq, 1))
    vxx, vyy = (grad_last(vx, seq, 0), grad_last(vy, seq, 1))
    fu, fv = forcing_mms(x0, y0, t0, c.nu)
    ru = ut + u * ux + v * uy + px - c.nu * (uxx + uyy) - fu
    rv = vt + u * vx + v * vy + py - c.nu * (vxx + vyy) - fv
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    ld = torch.mean((ux + vy) ** 2)
    xi, yi, ti, ui, vi, pi = ic
    up, vp, pp = predict_points(c, m, xi, yi, ti)
    li = torch.mean((up - ui) ** 2) + torch.mean((vp - vi) ** 2) + torch.mean((pp - pi) ** 2)
    xL, xR, yb, tb = bcx
    sL = build_context(c, xL, yb, tb).detach().clone().requires_grad_(True)
    sR = build_context(c, xR, yb, tb).detach().clone().requires_grad_(True)
    uL, vL, pL = m.target(sL)
    uR, vR, pR = m.target(sR)
    lx = torch.mean((uL - uR) ** 2) + torch.mean((vL - vR) ** 2) + torch.mean((pL - pR) ** 2) + torch.mean((grad_last(uL, sL, 0) - grad_last(uR, sR, 0)) ** 2) + torch.mean((grad_last(vL, sL, 0) - grad_last(vR, sR, 0)) ** 2) + torch.mean((grad_last(pL, sL, 0) - grad_last(pR, sR, 0)) ** 2)
    xb, yB, yT, tb2 = bcy
    sB = build_context(c, xb, yB, tb2).detach().clone().requires_grad_(True)
    sT = build_context(c, xb, yT, tb2).detach().clone().requires_grad_(True)
    uB, vB, pB = m.target(sB)
    uT, vT, pT = m.target(sT)
    ly = torch.mean((uB - uT) ** 2) + torch.mean((vB - vT) ** 2) + torch.mean((pB - pT) ** 2) + torch.mean((grad_last(uB, sB, 1) - grad_last(uT, sT, 1)) ** 2) + torch.mean((grad_last(vB, sB, 1) - grad_last(vT, sT, 1)) ** 2) + torch.mean((grad_last(pB, sB, 1) - grad_last(pT, sT, 1)) ** 2)
    lb = lx + ly
    dp = data_parts(c, m, x0, y0, t0)
    lp = lm + ld
    total = c.w_mom * lm + c.w_div * ld + c.w_ic * li + c.w_bc * lb
    return (total, {'pde': lp, 'mom': lm, 'div': ld, 'ic': li, 'bc': lb, 'data': dp['data_total'], 'data_u': dp['data_u'], 'data_v': dp['data_v'], 'data_p': dp['data_p'], 'data_speed': dp['data_speed']})

def batch_losses(c, m, col, ic, bcx, bcy):
    return batch_losses_lstm(c, m, col, ic, bcx, bcy) if c.model_name.startswith('S-LSTM-PINN-m') else batch_losses_ff(c, m, col, ic, bcx, bcy)

@torch.no_grad()
def evaluate_val(c, m, d):
    idx = d['val_metric_idx']
    x, y, t = d['col_va']
    x, y, t = (x[idx], y[idx], t[idx])
    ur, vr, pr = uvp_mms(x, y, t)
    u, v, p = predict_points(c, m, x, y, t)
    return metrics_torch(torch.cat([u, v, p, torch.sqrt(u ** 2 + v ** 2)], 1), torch.cat([ur, vr, pr, torch.sqrt(ur ** 2 + vr ** 2)], 1))

@torch.no_grad()
def eval_grid(c, m):
    xs = torch.linspace(c.x0, c.x1, c.eval_nx, device=c.device, dtype=c.dtype)
    ys = torch.linspace(c.y0, c.y1, c.eval_ny, device=c.device, dtype=c.dtype)
    X, Y = torch.meshgrid(xs, ys, indexing='ij')
    xf, yf = (X.reshape(-1, 1), Y.reshape(-1, 1))
    g = {'x': xs.cpu().numpy(), 'y': ys.cpu().numpy(), 'times': np.array(c.eval_times, dtype=np.float32)}
    for ti in c.eval_times:
        t = torch.full_like(xf, float(ti))
        ur, vr, pr = uvp_mms(xf, yf, t)
        u, v, p = predict_points(c, m, xf, yf, t)
        sr = torch.sqrt(ur ** 2 + vr ** 2)
        sp = torch.sqrt(u ** 2 + v ** 2)
        tag = time_tag(ti)
        for n, a in {'u_ref': ur, 'v_ref': vr, 'p_ref': pr, 'speed_ref': sr, 'u_pred': u, 'v_pred': v, 'p_pred': p, 'speed_pred': sp}.items():
            g[f'{n}_{tag}'] = a.view(c.eval_nx, c.eval_ny).cpu().numpy()
        for f in ('u', 'v', 'p', 'speed'):
            g[f'{f}_err_{tag}'] = g[f'{f}_pred_{tag}'] - g[f'{f}_ref_{tag}']
    return g

def make_dirs(c):
    for s in ('', 'field_data', 'metrics', 'cost', 'loss', 'figures/reference', 'figures/prediction', 'figures/error', 'figures/loss', 'config'):
        ensure_dir(os.path.join(c.out_dir, s))

def save_model_info(c, m):
    with open(os.path.join(c.out_dir, 'model_info.txt'), 'w', encoding='utf-8') as f:
        for k, v in [('Case', c.case_name), ('Model', c.model_name), ('Data seed', c.data_seed), ('Model seed', c.model_seed), ('Trainable parameters', count_trainable_parameters(m)), ('Total parameters', count_total_parameters(m)), ('Parameter size MB', f'{parameter_size_mb(m):.6f}'), ('Optimizer', 'Adam'), ('Learning rate', c.lr), ('Iterations', c.iters), ('Sequence length', c.sequence_length if c.model_name.startswith('S-LSTM-PINN-m') else 1)]:
            f.write(f'{k}: {v}\n')

def save_field_data(c, g):
    xx, yy = np.meshgrid(g['x'], g['y'], indexing='ij')
    for ti in g['times']:
        tag = time_tag(ti)
        od = os.path.join(c.out_dir, 'field_data', tag)
        ensure_dir(od)
        for f in ('u', 'v', 'p', 'speed'):
            pred, ref = (g[f'{f}_pred_{tag}'], g[f'{f}_ref_{tag}'])
            e = pred - ref
            arr = np.column_stack([xx.ravel(), yy.ravel(), pred.ravel(), ref.ravel(), e.ravel(), np.abs(e).ravel()])
            np.savetxt(os.path.join(od, f'{f}_field_data_{tag}.txt'), arr, fmt='%.10e', delimiter='\t', header='x\ty\tPrediction\tReference\tError\tAbsError', comments='')

def save_metrics(c, g):
    rows = []
    ap = []
    ar = []
    for ti in g['times']:
        tag = time_tag(ti)
        for f in ('u', 'v', 'p', 'speed'):
            pred, ref = (g[f'{f}_pred_{tag}'], g[f'{f}_ref_{tag}'])
            mm = metrics_np(pred, ref)
            rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'time': float(ti), 'field': f, **mm})
            ap.append(pred.ravel())
            ar.append(ref.ravel())
    write_csv(os.path.join(c.out_dir, 'metrics', 'field_metrics.csv'), rows)
    mm = metrics_np(np.concatenate(ap), np.concatenate(ar))
    write_csv(os.path.join(c.out_dir, 'metrics', 'overall_metrics.csv'), [{'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, **mm}])
    return mm

def save_plots(c, g, h):
    if not c.write_plots:
        return
    extent = [c.x0, c.x1, c.y0, c.y1]
    for ti in g['times']:
        tag = time_tag(ti)
        for f in ('u', 'v', 'p', 'speed'):
            for folder, key, title in (('reference', f'{f}_ref_{tag}', 'Reference'), ('prediction', f'{f}_pred_{tag}', 'Prediction'), ('error', f'{f}_err_{tag}', 'Absolute error')):
                a = np.abs(g[key]) if folder == 'error' else g[key]
                plt.figure(figsize=(5.5, 4.5))
                plt.imshow(a.T, origin='lower', extent=extent, aspect='auto')
                plt.colorbar()
                plt.xlabel('x')
                plt.ylabel('y')
                plt.title(f'{title} {f}, {tag}')
                plt.tight_layout()
                plt.savefig(os.path.join(c.out_dir, 'figures', folder, f'{f}_{folder}_{tag}.png'), dpi=220)
                plt.close()
    pairs = [('loss_total_train', 'loss_total_val', 'total'), ('loss_pde_train', 'loss_pde_val', 'pde'), ('loss_mom_train', 'loss_mom_val', 'mom'), ('loss_div_train', 'loss_div_val', 'div'), ('loss_ic_train', 'loss_ic_val', 'ic'), ('loss_bc_train', 'loss_bc_val', 'bc'), ('loss_data_train', 'loss_data_val', 'data'), ('RelL2_val', None, 'rel_l2')]
    for tr, va, n in pairs:
        plt.figure(figsize=(7, 4))
        plt.plot(h['iter'], h[tr], label=tr)
        if va:
            plt.plot(h['iter'], h[va], label=va)
        plt.yscale('log')
        plt.xlabel('iteration')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(c.out_dir, 'figures', 'loss', f'{n}_curve.png'), dpi=220)
        plt.close()

def save_cost(c, m, h, itimes, training_wall, total_wall, best_it, best_rel, final_rel):
    hw = hardware_info(c.device)
    pa, pr = peak_gpu(c.device)
    completed = len(itimes)
    timed_training = float(np.sum(itimes))
    row = {'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'trainable_parameters': count_trainable_parameters(m), 'total_parameters': count_total_parameters(m), 'parameter_size_MB': parameter_size_mb(m), 'total_iterations_configured': c.iters, 'total_iterations_completed': completed, 'completed_iterations': completed, 'training_wall_time_sec': training_wall, 'training_wall_time_min': training_wall / 60, 'total_wall_time_sec': total_wall, 'total_wall_time_min': total_wall / 60, 'first_iteration_time_sec': float(itimes[0]), 'mean_time_per_iter_sec': float(np.mean(itimes)), 'median_time_per_iter_sec': float(np.median(itimes)), 'p50_time_per_iter_sec': float(np.percentile(itimes, 50)), 'p95_time_per_iter_sec': float(np.percentile(itimes, 95)), 'training_throughput_iter_per_sec': completed / timed_training if timed_training > 0 else 0.0, 'end_to_end_throughput_iter_per_sec': completed / total_wall if total_wall > 0 else 0.0, 'peak_gpu_memory_allocated_MB': pa, 'peak_gpu_memory_reserved_MB': pr, 'best_iter': best_it, 'best_RelL2': best_rel, 'final_validation_RelL2': h['RelL2_val'][-1], 'final_grid_RelL2': final_rel, 'final_RelL2': final_rel, **hw}
    write_csv(os.path.join(c.out_dir, 'cost', 'model_cost_summary.csv'), [row])
    write_csv(os.path.join(c.out_dir, 'cost', 'iteration_times.csv'), [{'iteration': i, 'time_sec': v} for i, v in enumerate(itimes, 1)])
    rows = []
    for th in c.rel_l2_thresholds:
        hit = next(((it, r, t) for it, r, t in zip(h['iter'], h['RelL2_val'], h['time_elapsed_sec']) if r <= th), None)
        rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'metric': 'RelL2', 'threshold': th, 'reached': hit is not None, 'iter_to_threshold': -1 if hit is None else hit[0], 'time_to_threshold_sec': -1 if hit is None else hit[2]})
    write_csv(os.path.join(c.out_dir, 'cost', 'threshold_cost.csv'), rows)

def init_history():
    keys = ['iter', 'loss_total_train', 'loss_total_val', 'loss_pde_train', 'loss_pde_val', 'loss_mom_train', 'loss_mom_val', 'loss_div_train', 'loss_div_val', 'loss_ic_train', 'loss_ic_val', 'loss_bc_train', 'loss_bc_val', 'loss_data_train', 'loss_data_val', 'loss_data_u_train', 'loss_data_u_val', 'loss_data_v_train', 'loss_data_v_val', 'loss_data_p_train', 'loss_data_p_val', 'loss_data_speed_train', 'loss_data_speed_val', 'MSE_val', 'RMSE_val', 'MAE_val', 'L2_val', 'RelL2_val', 'MaxAbsError_val', 'MeanAbsError_val', 'time_elapsed_sec']
    return {k: [] for k in keys}

def append_history(h, row):
    for k in h:
        h[k].append(row.get(k, 0.0))

def train(c=Config()):
    run_start = time.time()
    make_dirs(c)
    d = build_dataset(c)
    set_seed(c.model_seed)
    m = build_model(c).to(c.device, c.dtype)
    opt = torch.optim.Adam(m.parameters(), lr=c.lr)
    if torch.cuda.is_available() and c.device.startswith('cuda'):
        torch.cuda.reset_peak_memory_stats()
    save_model_info(c, m)
    with open(os.path.join(c.out_dir, 'config', 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(asdict(c), f, indent=2, default=str)
    with open(os.path.join(c.out_dir, 'config', 'environment.json'), 'w', encoding='utf-8') as f:
        json.dump(hardware_info(c.device), f, indent=2, default=str)
    h = init_history()
    itimes = []
    best = float('inf')
    best_it = -1
    synchronize_device(c.device)
    t0 = time.time()
    print(f'[INFO] {c.case_name} | {c.model_name} | data_seed={c.data_seed} model_seed={c.model_seed}')
    print(f'[INFO] params={count_trainable_parameters(m):,} | output={os.path.abspath(c.out_dir)}')
    for it in range(1, c.iters + 1):
        synchronize_device(c.device)
        ts = time.time()
        m.train()
        opt.zero_grad(set_to_none=True)
        s = c.data_seed
        col = minibatch(d['col_tr'], c.batch_col, s + 100000 + it)
        ic = minibatch(d['ic_tr'], c.batch_ic, s + 200000 + it)
        bcx = minibatch(d['bcx_tr'], c.batch_bcx, s + 300000 + it)
        bcy = minibatch(d['bcy_tr'], c.batch_bcy, s + 400000 + it)
        loss, p = batch_losses(c, m, col, ic, bcx, bcy)
        if not torch.isfinite(loss):
            raise RuntimeError(f'Non-finite loss at {it}')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), c.grad_clip)
        opt.step()
        synchronize_device(c.device)
        itimes.append(time.time() - ts)
        should_eval = it == 1 or it % c.eval_every == 0 or it == c.iters
        if should_eval:
            m.eval()
            cv = minibatch(d['col_va'], c.val_batch_col, s + 500000 + it)
            iv = minibatch(d['ic_va'], c.val_batch_ic, s + 600000 + it)
            bxv = minibatch(d['bcx_va'], c.val_batch_bcx, s + 700000 + it)
            byv = minibatch(d['bcy_va'], c.val_batch_bcy, s + 800000 + it)
            lv, pv = batch_losses(c, m, cv, iv, bxv, byv)
            vm = evaluate_val(c, m, d)
            elapsed = time.time() - t0
            row = {'iter': it, 'loss_total_train': float(loss.item()), 'loss_total_val': float(lv.item()), 'loss_pde_train': float(p['pde'].item()), 'loss_pde_val': float(pv['pde'].item()), 'loss_mom_train': float(p['mom'].item()), 'loss_mom_val': float(pv['mom'].item()), 'loss_div_train': float(p['div'].item()), 'loss_div_val': float(pv['div'].item()), 'loss_ic_train': float(p['ic'].item()), 'loss_ic_val': float(pv['ic'].item()), 'loss_bc_train': float(p['bc'].item()), 'loss_bc_val': float(pv['bc'].item()), 'loss_data_train': float(p['data'].item()), 'loss_data_val': float(pv['data'].item()), 'loss_data_u_train': float(p['data_u'].item()), 'loss_data_u_val': float(pv['data_u'].item()), 'loss_data_v_train': float(p['data_v'].item()), 'loss_data_v_val': float(pv['data_v'].item()), 'loss_data_p_train': float(p['data_p'].item()), 'loss_data_p_val': float(pv['data_p'].item()), 'loss_data_speed_train': float(p['data_speed'].item()), 'loss_data_speed_val': float(pv['data_speed'].item()), **{k + '_val': v for k, v in vm.items()}, 'time_elapsed_sec': elapsed}
            append_history(h, row)
            write_history(os.path.join(c.out_dir, 'loss', 'train_history.csv'), h)
            if vm['RelL2'] < best:
                best = vm['RelL2']
                best_it = it
                torch.save({'iter': it, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'best_rel_l2': best, 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'best_model.pt'))
            print(f"[{it:06d}] loss={loss.item():.3e} val={lv.item():.3e} RelL2={vm['RelL2']:.3e} elapsed={elapsed / 60:.1f} min")
    synchronize_device(c.device)
    training_wall = time.time() - t0
    torch.save({'iter': c.iters, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'completed_iterations': c.iters, 'training_completed': True, 'final_rel_l2_val': h['RelL2_val'][-1], 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'final_model.pt'))
    m.eval()
    g = eval_grid(c, m)
    np.savez(os.path.join(c.out_dir, 'grid.npz'), **g)
    save_field_data(c, g)
    overall = save_metrics(c, g)
    save_plots(c, g, h)
    synchronize_device(c.device)
    total_wall = time.time() - run_start
    save_cost(c, m, h, itimes, training_wall, total_wall, best_it, best, overall['RelL2'])
    print(f"[DONE] normal completion at {c.iters} iterations | {c.model_name} seed={c.model_seed} best={best:.6e} final_grid={overall['RelL2']:.6e}")
    return (m, h)
