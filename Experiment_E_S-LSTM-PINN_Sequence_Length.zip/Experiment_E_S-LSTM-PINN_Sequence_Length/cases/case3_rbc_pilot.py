import os, csv, json, math, time, platform
from dataclasses import dataclass, asdict
from typing import Dict, Tuple, List, Any
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
MODEL_KIND = 'S-LSTM-PINN-m8'
MODEL_SEED = 0
DATA_SEED = 0
STOP_ITER = 300

@dataclass
class Config:
    write_plots: bool = True
    case_name: str = 'RBC'
    model_name: str = MODEL_KIND
    device: str = 'cuda' if torch.cuda.is_available() else 'cpu'
    dtype: torch.dtype = torch.float32
    nu: float = 0.01
    kappa: float = 0.01
    beta: float = 1.0
    x0: float = 0.0
    x1: float = 1.0
    y0: float = 0.0
    y1: float = 1.0
    t0: float = 0.0
    t1: float = 2.0
    n_col: int = 22000
    n_ic: int = 2400
    n_bc_left: int = 1800
    n_bc_right: int = 1800
    n_bc_bottom: int = 1800
    n_bc_top: int = 1800
    train_ratio: float = 0.7
    iters: int = STOP_ITER
    lr: float = 0.0001
    batch_col: int = 1024
    batch_ic: int = 256
    batch_bc: int = 256
    val_batch_col: int = 512
    val_batch_ic: int = 256
    val_batch_bc: int = 256
    val_metric_points: int = 3000
    eval_every: int = 500
    grad_clip: float = 1.0
    w_pde: float = 1.0
    w_div: float = 1.0
    w_ic: float = 10.0
    w_bc: float = 2.0
    pinn_hidden: int = 128
    pinn_layers: int = 8
    param_hidden: int = 280
    param_layers: int = 9
    lstm_hidden: int = 192
    lstm_layers: int = 2
    sequence_length: int = 8
    temporal_dt: float = 0.05
    nx_eval: int = 120
    ny_eval: int = 120
    eval_times: Tuple[float, ...] = (0.0, 1.0, 2.0)
    rel_l2_thresholds: Tuple[float, ...] = (0.01, 0.001)
    data_seed: int = DATA_SEED
    model_seed: int = MODEL_SEED
    out_dir: str = './sequence_length_30k/case3_RBC/m8'

def ensure_dir(p):
    if p:
        os.makedirs(p, exist_ok=True)

def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def count_trainable_parameters(m):
    return sum((p.numel() for p in m.parameters() if p.requires_grad))

def count_total_parameters(m):
    return sum((p.numel() for p in m.parameters()))

def parameter_size_mb(m):
    return sum((p.numel() * p.element_size() for p in m.parameters())) / 1024 ** 2

def hardware_info(device):
    d = {'device': device, 'python_version': platform.python_version(), 'platform': platform.platform(), 'cpu_name': platform.processor() or platform.machine(), 'torch_version': torch.__version__, 'cuda_available': torch.cuda.is_available(), 'cuda_version': torch.version.cuda or 'None', 'gpu_count': torch.cuda.device_count() if torch.cuda.is_available() else 0, 'gpu_name': 'None', 'gpu_total_memory_MB': 0.0}
    if torch.cuda.is_available() and device.startswith('cuda'):
        p = torch.cuda.get_device_properties(torch.cuda.current_device())
        d['gpu_name'] = p.name
        d['gpu_total_memory_MB'] = p.total_memory / 1024 ** 2
    return d

def peak_gpu(device):
    if torch.cuda.is_available() and device.startswith('cuda'):
        return (torch.cuda.max_memory_allocated() / 1024 ** 2, torch.cuda.max_memory_reserved() / 1024 ** 2)
    return (0.0, 0.0)

def synchronize_device(device):
    if torch.cuda.is_available() and str(device).startswith('cuda'):
        torch.cuda.synchronize()

def time_tag(t):
    return f"t{str(round(float(t), 4)).replace('.', 'p')}"

def write_csv(path, rows, fields=None):
    ensure_dir(os.path.dirname(path))
    fields = fields or (list(rows[0].keys()) if rows else [])
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def write_history(path, h):
    ensure_dir(os.path.dirname(path))
    keys = list(h.keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(keys)
        for i in range(len(h[keys[0]])):
            w.writerow([h[k][i] for k in keys])

def metrics_np(pred, ref):
    p = np.asarray(pred).reshape(-1)
    r = np.asarray(ref).reshape(-1)
    d = p - r
    mse = float(np.mean(d * d))
    l2 = float(np.linalg.norm(d))
    return {'MSE': mse, 'RMSE': float(np.sqrt(mse)), 'MAE': float(np.mean(np.abs(d))), 'L2': l2, 'RelL2': float(l2 / (np.linalg.norm(r) + 1e-12)), 'MaxAbsError': float(np.max(np.abs(d))), 'MeanAbsError': float(np.mean(np.abs(d)))}

def metrics_torch(pred, ref):
    d = pred.detach() - ref.detach()
    mse = torch.mean(d * d)
    l2 = torch.linalg.norm(d.reshape(-1))
    return {'MSE': float(mse.item()), 'RMSE': float(torch.sqrt(mse).item()), 'MAE': float(torch.mean(torch.abs(d)).item()), 'L2': float(l2.item()), 'RelL2': float((l2 / (torch.linalg.norm(ref.detach().reshape(-1)) + 1e-12)).item()), 'MaxAbsError': float(torch.max(torch.abs(d)).item()), 'MeanAbsError': float(torch.mean(torch.abs(d)).item())}

def uvpt_mms(x, y, t):
    sx = torch.sin(math.pi * x)
    sy = torch.sin(math.pi * y)
    cx = torch.cos(math.pi * x)
    cy = torch.cos(math.pi * y)
    st = torch.sin(math.pi * t)
    ct = torch.cos(math.pi * t)
    u = 2.0 * math.pi * sx ** 2 * sy * cy * st
    v = -2.0 * math.pi * sx * cx * sy ** 2 * st
    p = 0.1 * cx * cy * ct
    th = sx * sy * ct
    return (u, v, p, th)

def forcing_mms_detached(x, y, t, c):
    xg = x.detach().clone().requires_grad_(True)
    yg = y.detach().clone().requires_grad_(True)
    tg = t.detach().clone().requires_grad_(True)

    def g1(a, z):
        return torch.autograd.grad(a, z, torch.ones_like(a), create_graph=True, retain_graph=True)[0]
    u, v, p, th = uvpt_mms(xg, yg, tg)
    ut, vt, tt = (g1(u, tg), g1(v, tg), g1(th, tg))
    ux, uy = (g1(u, xg), g1(u, yg))
    vx, vy = (g1(v, xg), g1(v, yg))
    tx, ty = (g1(th, xg), g1(th, yg))
    uxx, uyy = (g1(ux, xg), g1(uy, yg))
    vxx, vyy = (g1(vx, xg), g1(vy, yg))
    txx, tyy = (g1(tx, xg), g1(ty, yg))
    px, py = (g1(p, xg), g1(p, yg))
    fu = ut + u * ux + v * uy + px - c.nu * (uxx + uyy)
    fv = vt + u * vx + v * vy + py - c.nu * (vxx + vyy) - c.beta * th
    fth = tt + u * tx + v * ty - c.kappa * (txx + tyy)
    return (fu.detach(), fv.detach(), fth.detach())

def rand_fixed(n, lo, hi, device, dtype, seed):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    return lo + (hi - lo) * torch.rand(n, 1, generator=g, device=device, dtype=dtype)

def split_fixed(n, ratio, seed, device):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    idx = torch.randperm(n, generator=g, device=device)
    ntr = max(1, min(int(ratio * n), n - 1))
    return (idx[:ntr], idx[ntr:])

def make_side(c, n, kind, base_seed):
    if kind == 'left':
        y = rand_fixed(n, c.y0, c.y1, c.device, c.dtype, base_seed + 1)
        x = torch.full_like(y, c.x0)
    elif kind == 'right':
        y = rand_fixed(n, c.y0, c.y1, c.device, c.dtype, base_seed + 1)
        x = torch.full_like(y, c.x1)
    elif kind == 'bottom':
        x = rand_fixed(n, c.x0, c.x1, c.device, c.dtype, base_seed + 1)
        y = torch.full_like(x, c.y0)
    elif kind == 'top':
        x = rand_fixed(n, c.x0, c.x1, c.device, c.dtype, base_seed + 1)
        y = torch.full_like(x, c.y1)
    t = rand_fixed(n, c.t0, c.t1, c.device, c.dtype, base_seed + 2)
    u, v, p, th = uvpt_mms(x, y, t)
    return (x, y, t, u.detach(), v.detach(), p.detach(), th.detach())

def split_bundle(bundle, tr, va):
    return (tuple((a[tr] for a in bundle)), tuple((a[va] for a in bundle)))

def build_dataset(c):
    s = c.data_seed
    x = rand_fixed(c.n_col, c.x0, c.x1, c.device, c.dtype, s + 11)
    y = rand_fixed(c.n_col, c.y0, c.y1, c.device, c.dtype, s + 12)
    t = rand_fixed(c.n_col, c.t0, c.t1, c.device, c.dtype, s + 13)
    tr, va = split_fixed(c.n_col, c.train_ratio, s + 101, c.device)
    col_tr = (x[tr], y[tr], t[tr])
    col_va = (x[va], y[va], t[va])
    xi = rand_fixed(c.n_ic, c.x0, c.x1, c.device, c.dtype, s + 21)
    yi = rand_fixed(c.n_ic, c.y0, c.y1, c.device, c.dtype, s + 22)
    ti = torch.full_like(xi, c.t0)
    ur, vr, pr, trf = uvpt_mms(xi, yi, ti)
    full = (xi, yi, ti, ur.detach(), vr.detach(), pr.detach(), trf.detach())
    tri, vai = split_fixed(c.n_ic, c.train_ratio, s + 202, c.device)
    ic_tr, ic_va = split_bundle(full, tri, vai)
    bc = {}
    specs = [('left', c.n_bc_left, 301), ('right', c.n_bc_right, 302), ('bottom', c.n_bc_bottom, 303), ('top', c.n_bc_top, 304)]
    for kind, n, off in specs:
        full = make_side(c, n, kind, s + 1000 + off)
        tri, vai = split_fixed(n, c.train_ratio, s + off, c.device)
        bc[kind + '_tr'], bc[kind + '_va'] = split_bundle(full, tri, vai)
    g = torch.Generator(device=c.device)
    g.manual_seed(s + 505)
    vidx = torch.randperm(col_va[0].shape[0], generator=g, device=c.device)[:min(c.val_metric_points, col_va[0].shape[0])]
    return {'col_tr': col_tr, 'col_va': col_va, 'ic_tr': ic_tr, 'ic_va': ic_va, **bc, 'val_metric_idx': vidx}

def minibatch(bundle, batch, seed):
    g = torch.Generator(device=bundle[0].device)
    g.manual_seed(seed)
    idx = torch.randperm(bundle[0].shape[0], generator=g, device=bundle[0].device)[:min(batch, bundle[0].shape[0])]
    return tuple((a[idx] for a in bundle))

class FFPINN(nn.Module):

    def __init__(self, width, depth):
        super().__init__()
        layers = [nn.Linear(3, width), nn.Tanh()]
        for _ in range(depth - 1):
            layers += [nn.Linear(width, width), nn.Tanh()]
        layers += [nn.Linear(width, 4)]
        self.net = nn.Sequential(*layers)

    def forward(self, x, y, t):
        o = self.net(torch.cat([x, y, t], 1))
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3], o[:, 3:4])

class TemporalLSTM(nn.Module):

    def __init__(self, c):
        super().__init__()
        self.embed = nn.Linear(3, c.lstm_hidden)
        self.lstm = nn.LSTM(c.lstm_hidden, c.lstm_hidden, num_layers=c.lstm_layers, batch_first=True)
        self.head = nn.Sequential(nn.Linear(c.lstm_hidden, c.lstm_hidden), nn.Tanh(), nn.Linear(c.lstm_hidden, 4))

    def target(self, seq):
        z = self.embed(seq)
        with torch.backends.cudnn.flags(enabled=False):
            z, _ = self.lstm(z)
        o = self.head(z[:, -1, :])
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3], o[:, 3:4])

def build_context(c, x, y, t):
    offs = torch.arange(c.sequence_length - 1, -1, -1, device=x.device, dtype=x.dtype).view(1, c.sequence_length, 1) * c.temporal_dt
    th = torch.clamp(t[:, None, :] - offs, min=c.t0)
    return torch.cat([x[:, None, :].expand(-1, c.sequence_length, -1), y[:, None, :].expand(-1, c.sequence_length, -1), th], 2)

def build_model(c):
    if c.model_name == 'PINN':
        return FFPINN(c.pinn_hidden, c.pinn_layers)
    if c.model_name == 'Param-PINN':
        return FFPINN(c.param_hidden, c.param_layers)
    if c.model_name.startswith('S-LSTM-PINN-m'):
        return TemporalLSTM(c)
    raise ValueError(c.model_name)

def predict_points(c, m, x, y, t):
    return m.target(build_context(c, x, y, t)) if c.model_name.startswith('S-LSTM-PINN-m') else m(x, y, t)

def grad1(u, x):
    return torch.autograd.grad(u, x, torch.ones_like(u), create_graph=True, retain_graph=True)[0]

def lap2(u, x, y):
    ux = grad1(u, x)
    uy = grad1(u, y)
    return (ux, uy, grad1(ux, x) + grad1(uy, y))

def grad_last(u, seq, k):
    return torch.autograd.grad(u, seq, torch.ones_like(u), create_graph=True, retain_graph=True)[0][:, -1, k:k + 1]

def data_parts(c, m, x, y, t):
    ur, vr, pr, tr = uvpt_mms(x, y, t)
    u, v, p, th = predict_points(c, m, x, y, t)
    sr = torch.sqrt(ur ** 2 + vr ** 2)
    sp = torch.sqrt(u ** 2 + v ** 2)
    d = {'data_u': torch.mean((u - ur) ** 2), 'data_v': torch.mean((v - vr) ** 2), 'data_p': torch.mean((p - pr) ** 2), 'data_theta': torch.mean((th - tr) ** 2), 'data_speed': torch.mean((sp - sr) ** 2)}
    d['data_total'] = d['data_u'] + d['data_v'] + d['data_p'] + d['data_theta']
    return d

def bc_loss(c, m, b):
    x, y, t, ur, vr, pr, tr = b
    u, v, p, th = predict_points(c, m, x, y, t)
    return torch.mean((u - ur) ** 2) + torch.mean((v - vr) ** 2) + torch.mean((p - pr) ** 2) + torch.mean((th - tr) ** 2)

def batch_losses_ff(c, m, col, ic, left, right, bottom, top):
    x0, y0, t0 = col
    x = x0.detach().clone().requires_grad_(True)
    y = y0.detach().clone().requires_grad_(True)
    t = t0.detach().clone().requires_grad_(True)
    u, v, p, th = m(x, y, t)
    ut, vt, tt = (grad1(u, t), grad1(v, t), grad1(th, t))
    ux, uy, lu = lap2(u, x, y)
    vx, vy, lv = lap2(v, x, y)
    tx, ty, lt = lap2(th, x, y)
    px, py = (grad1(p, x), grad1(p, y))
    fu, fv, fth = forcing_mms_detached(x0, y0, t0, c)
    ru = ut + u * ux + v * uy + px - c.nu * lu - fu
    rv = vt + u * vx + v * vy + py - c.nu * lv - c.beta * th - fv
    rt = tt + u * tx + v * ty - c.kappa * lt - fth
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    lth = torch.mean(rt ** 2)
    lpde = lm + lth
    ld = torch.mean((ux + vy) ** 2)
    xi, yi, ti, ui, vi, pi, thi = ic
    up, vp, pp, tp = m(xi, yi, ti)
    li = torch.mean((up - ui) ** 2) + torch.mean((vp - vi) ** 2) + torch.mean((pp - pi) ** 2) + torch.mean((tp - thi) ** 2)
    lb = bc_loss(c, m, left) + bc_loss(c, m, right) + bc_loss(c, m, bottom) + bc_loss(c, m, top)
    dp = data_parts(c, m, x0, y0, t0)
    total = c.w_pde * lpde + c.w_div * ld + c.w_ic * li + c.w_bc * lb
    return (total, {'pde': lpde, 'mom': lm, 'theta_pde': lth, 'div': ld, 'ic': li, 'bc': lb, 'data': dp['data_total'], 'data_u': dp['data_u'], 'data_v': dp['data_v'], 'data_p': dp['data_p'], 'data_theta': dp['data_theta'], 'data_speed': dp['data_speed']})

def batch_losses_lstm(c, m, col, ic, left, right, bottom, top):
    x0, y0, t0 = col
    seq = build_context(c, x0, y0, t0).detach().clone().requires_grad_(True)
    u, v, p, th = m.target(seq)
    ut, vt, tt = (grad_last(u, seq, 2), grad_last(v, seq, 2), grad_last(th, seq, 2))
    ux, uy = (grad_last(u, seq, 0), grad_last(u, seq, 1))
    vx, vy = (grad_last(v, seq, 0), grad_last(v, seq, 1))
    tx, ty = (grad_last(th, seq, 0), grad_last(th, seq, 1))
    px, py = (grad_last(p, seq, 0), grad_last(p, seq, 1))
    uxx, uyy = (grad_last(ux, seq, 0), grad_last(uy, seq, 1))
    vxx, vyy = (grad_last(vx, seq, 0), grad_last(vy, seq, 1))
    txx, tyy = (grad_last(tx, seq, 0), grad_last(ty, seq, 1))
    fu, fv, fth = forcing_mms_detached(x0, y0, t0, c)
    ru = ut + u * ux + v * uy + px - c.nu * (uxx + uyy) - fu
    rv = vt + u * vx + v * vy + py - c.nu * (vxx + vyy) - c.beta * th - fv
    rt = tt + u * tx + v * ty - c.kappa * (txx + tyy) - fth
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    lth = torch.mean(rt ** 2)
    lpde = lm + lth
    ld = torch.mean((ux + vy) ** 2)
    xi, yi, ti, ui, vi, pi, thi = ic
    up, vp, pp, tp = predict_points(c, m, xi, yi, ti)
    li = torch.mean((up - ui) ** 2) + torch.mean((vp - vi) ** 2) + torch.mean((pp - pi) ** 2) + torch.mean((tp - thi) ** 2)
    lb = bc_loss(c, m, left) + bc_loss(c, m, right) + bc_loss(c, m, bottom) + bc_loss(c, m, top)
    dp = data_parts(c, m, x0, y0, t0)
    total = c.w_pde * lpde + c.w_div * ld + c.w_ic * li + c.w_bc * lb
    return (total, {'pde': lpde, 'mom': lm, 'theta_pde': lth, 'div': ld, 'ic': li, 'bc': lb, 'data': dp['data_total'], 'data_u': dp['data_u'], 'data_v': dp['data_v'], 'data_p': dp['data_p'], 'data_theta': dp['data_theta'], 'data_speed': dp['data_speed']})

def batch_losses(c, m, col, ic, left, right, bottom, top):
    return batch_losses_lstm(c, m, col, ic, left, right, bottom, top) if c.model_name.startswith('S-LSTM-PINN-m') else batch_losses_ff(c, m, col, ic, left, right, bottom, top)

@torch.no_grad()
def evaluate_val(c, m, d):
    idx = d['val_metric_idx']
    x, y, t = d['col_va']
    x, y, t = (x[idx], y[idx], t[idx])
    ur, vr, pr, tr = uvpt_mms(x, y, t)
    u, v, p, th = predict_points(c, m, x, y, t)
    return metrics_torch(torch.cat([u, v, p, th], 1), torch.cat([ur, vr, pr, tr], 1))

@torch.no_grad()
def eval_grid(c, m):
    xs = torch.linspace(c.x0, c.x1, c.nx_eval, device=c.device, dtype=c.dtype)
    ys = torch.linspace(c.y0, c.y1, c.ny_eval, device=c.device, dtype=c.dtype)
    X, Y = torch.meshgrid(xs, ys, indexing='ij')
    xf, yf = (X.reshape(-1, 1), Y.reshape(-1, 1))
    g = {'x': xs.cpu().numpy(), 'y': ys.cpu().numpy(), 'times': np.array(c.eval_times, dtype=np.float32)}
    for ti in c.eval_times:
        t = torch.full_like(xf, float(ti))
        ur, vr, pr, tr = uvpt_mms(xf, yf, t)
        u, v, p, th = predict_points(c, m, xf, yf, t)
        sr = torch.sqrt(ur ** 2 + vr ** 2)
        sp = torch.sqrt(u ** 2 + v ** 2)
        tag = time_tag(ti)
        for n, a in {'u_ref': ur, 'v_ref': vr, 'p_ref': pr, 'theta_ref': tr, 'speed_ref': sr, 'u_pred': u, 'v_pred': v, 'p_pred': p, 'theta_pred': th, 'speed_pred': sp}.items():
            g[f'{n}_{tag}'] = a.view(c.nx_eval, c.ny_eval).cpu().numpy()
        for f in ('u', 'v', 'p', 'theta', 'speed'):
            g[f'{f}_err_{tag}'] = g[f'{f}_pred_{tag}'] - g[f'{f}_ref_{tag}']
    return g

def make_dirs(c):
    for s in ('', 'field_data', 'metrics', 'cost', 'loss', 'figures/reference', 'figures/prediction', 'figures/error', 'figures/loss', 'config'):
        ensure_dir(os.path.join(c.out_dir, s))
    for ti in c.eval_times:
        ensure_dir(os.path.join(c.out_dir, 'field_data', time_tag(ti)))

def save_model_info(c, m):
    with open(os.path.join(c.out_dir, 'model_info.txt'), 'w', encoding='utf-8') as f:
        for k, v in [('Case', c.case_name), ('Model', c.model_name), ('Data seed', c.data_seed), ('Model seed', c.model_seed), ('Trainable parameters', count_trainable_parameters(m)), ('Total parameters', count_total_parameters(m)), ('Parameter size MB', f'{parameter_size_mb(m):.6f}'), ('Optimizer', 'Adam'), ('Learning rate', c.lr), ('Iterations', c.iters), ('Batch collocation', c.batch_col), ('Batch IC', c.batch_ic), ('Batch BC', c.batch_bc), ('Sequence length', c.sequence_length if c.model_name.startswith('S-LSTM-PINN-m') else 1)]:
            f.write(f'{k}: {v}\n')

def save_field_data(c, g):
    xx, yy = np.meshgrid(g['x'], g['y'], indexing='ij')
    for ti in g['times']:
        tag = time_tag(ti)
        od = os.path.join(c.out_dir, 'field_data', tag)
        for f in ('u', 'v', 'p', 'theta', 'speed'):
            pred, ref = (g[f'{f}_pred_{tag}'], g[f'{f}_ref_{tag}'])
            e = pred - ref
            arr = np.column_stack([xx.ravel(), yy.ravel(), pred.ravel(), ref.ravel(), e.ravel(), np.abs(e).ravel()])
            np.savetxt(os.path.join(od, f'{f}_field_data_{tag}.txt'), arr, fmt='%.10e', delimiter='\t', header='x\ty\tPrediction\tReference\tError\tAbsError', comments='')

def save_metrics(c, g):
    rows = []
    ap = []
    ar = []
    for ti in g['times']:
        tag = time_tag(ti)
        for f in ('u', 'v', 'p', 'theta', 'speed'):
            pred, ref = (g[f'{f}_pred_{tag}'], g[f'{f}_ref_{tag}'])
            mm = metrics_np(pred, ref)
            rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'time': float(ti), 'field': f, **mm})
            ap.append(pred.ravel())
            ar.append(ref.ravel())
    write_csv(os.path.join(c.out_dir, 'metrics', 'field_metrics.csv'), rows)
    mm = metrics_np(np.concatenate(ap), np.concatenate(ar))
    write_csv(os.path.join(c.out_dir, 'metrics', 'overall_metrics.csv'), [{'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, **mm}])
    return mm

def save_plots(c, g, h):
    if not c.write_plots:
        return
    extent = [0, 1, 0, 1]
    for ti in g['times']:
        tag = time_tag(ti)
        for f in ('u', 'v', 'p', 'theta', 'speed'):
            for folder, key, title in (('reference', f'{f}_ref_{tag}', 'Reference'), ('prediction', f'{f}_pred_{tag}', 'Prediction'), ('error', f'{f}_err_{tag}', 'Absolute error')):
                a = np.abs(g[key]) if folder == 'error' else g[key]
                plt.figure(figsize=(5.6, 4.6))
                plt.imshow(a.T, origin='lower', extent=extent, aspect='auto')
                plt.colorbar()
                plt.xlabel('x')
                plt.ylabel('y')
                plt.title(f'{title} {f}, {tag}')
                plt.tight_layout()
                plt.savefig(os.path.join(c.out_dir, 'figures', folder, f'{f}_{folder}_{tag}.png'), dpi=220)
                plt.close()
    pairs = [('loss_total_train', 'loss_total_val', 'total'), ('loss_pde_train', 'loss_pde_val', 'pde'), ('loss_mom_train', 'loss_mom_val', 'mom'), ('loss_theta_pde_train', 'loss_theta_pde_val', 'theta_pde'), ('loss_div_train', 'loss_div_val', 'div'), ('loss_ic_train', 'loss_ic_val', 'ic'), ('loss_bc_train', 'loss_bc_val', 'bc'), ('loss_data_train', 'loss_data_val', 'data'), ('RelL2_val', None, 'rel_l2')]
    for tr, va, n in pairs:
        plt.figure(figsize=(7, 4))
        plt.plot(h['iter'], h[tr], label=tr)
        if va:
            plt.plot(h['iter'], h[va], label=va)
        plt.yscale('log')
        plt.xlabel('iteration')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(c.out_dir, 'figures', 'loss', f'{n}_curve.png'), dpi=220)
        plt.close()

def save_cost(c, m, h, itimes, training_wall, total_wall, best_it, best_rel, final_rel):
    hw = hardware_info(c.device)
    pa, pr = peak_gpu(c.device)
    completed = len(itimes)
    timed_training = float(np.sum(itimes))
    row = {'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'trainable_parameters': count_trainable_parameters(m), 'total_parameters': count_total_parameters(m), 'parameter_size_MB': parameter_size_mb(m), 'total_iterations_configured': c.iters, 'total_iterations_completed': completed, 'completed_iterations': completed, 'training_wall_time_sec': training_wall, 'training_wall_time_min': training_wall / 60, 'total_wall_time_sec': total_wall, 'total_wall_time_min': total_wall / 60, 'first_iteration_time_sec': float(itimes[0]), 'mean_time_per_iter_sec': float(np.mean(itimes)), 'median_time_per_iter_sec': float(np.median(itimes)), 'p50_time_per_iter_sec': float(np.percentile(itimes, 50)), 'p95_time_per_iter_sec': float(np.percentile(itimes, 95)), 'training_throughput_iter_per_sec': completed / timed_training if timed_training > 0 else 0.0, 'end_to_end_throughput_iter_per_sec': completed / total_wall if total_wall > 0 else 0.0, 'peak_gpu_memory_allocated_MB': pa, 'peak_gpu_memory_reserved_MB': pr, 'best_iter': best_it, 'best_RelL2': best_rel, 'final_validation_RelL2': h['RelL2_val'][-1], 'final_grid_RelL2': final_rel, 'final_RelL2': final_rel, **hw}
    write_csv(os.path.join(c.out_dir, 'cost', 'model_cost_summary.csv'), [row])
    write_csv(os.path.join(c.out_dir, 'cost', 'iteration_times.csv'), [{'iteration': i, 'time_sec': v} for i, v in enumerate(itimes, 1)])
    rows = []
    for th in c.rel_l2_thresholds:
        hit = next(((it, r, t) for it, r, t in zip(h['iter'], h['RelL2_val'], h['time_elapsed_sec']) if r <= th), None)
        rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'metric': 'RelL2', 'threshold': th, 'reached': hit is not None, 'iter_to_threshold': -1 if hit is None else hit[0], 'time_to_threshold_sec': -1 if hit is None else hit[2]})
    write_csv(os.path.join(c.out_dir, 'cost', 'threshold_cost.csv'), rows)

def init_history():
    keys = ['iter', 'loss_total_train', 'loss_total_val', 'loss_pde_train', 'loss_pde_val', 'loss_mom_train', 'loss_mom_val', 'loss_theta_pde_train', 'loss_theta_pde_val', 'loss_div_train', 'loss_div_val', 'loss_ic_train', 'loss_ic_val', 'loss_bc_train', 'loss_bc_val', 'loss_data_train', 'loss_data_val', 'loss_data_u_train', 'loss_data_u_val', 'loss_data_v_train', 'loss_data_v_val', 'loss_data_p_train', 'loss_data_p_val', 'loss_data_theta_train', 'loss_data_theta_val', 'loss_data_speed_train', 'loss_data_speed_val', 'MSE_val', 'RMSE_val', 'MAE_val', 'L2_val', 'RelL2_val', 'MaxAbsError_val', 'MeanAbsError_val', 'time_elapsed_sec']
    return {k: [] for k in keys}

def append_history(h, row):
    for k in h:
        h[k].append(row.get(k, 0.0))

def train(c=Config()):
    run_start = time.time()
    make_dirs(c)
    d = build_dataset(c)
    set_seed(c.model_seed)
    m = build_model(c).to(c.device, c.dtype)
    opt = torch.optim.Adam(m.parameters(), lr=c.lr)
    if torch.cuda.is_available() and c.device.startswith('cuda'):
        torch.cuda.reset_peak_memory_stats()
    save_model_info(c, m)
    with open(os.path.join(c.out_dir, 'config', 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(asdict(c), f, indent=2, default=str)
    with open(os.path.join(c.out_dir, 'config', 'environment.json'), 'w', encoding='utf-8') as f:
        json.dump(hardware_info(c.device), f, indent=2, default=str)
    h = init_history()
    itimes = []
    best = float('inf')
    best_it = -1
    synchronize_device(c.device)
    t_start = time.time()
    print(f'[INFO] {c.case_name} | {c.model_name} | data_seed={c.data_seed} model_seed={c.model_seed}')
    print(f'[INFO] params={count_trainable_parameters(m):,} | output={os.path.abspath(c.out_dir)}')
    for it in range(1, c.iters + 1):
        synchronize_device(c.device)
        ti = time.time()
        m.train()
        opt.zero_grad(set_to_none=True)
        s = c.data_seed
        col = minibatch(d['col_tr'], c.batch_col, s + 100000 + it)
        ic = minibatch(d['ic_tr'], c.batch_ic, s + 200000 + it)
        left = minibatch(d['left_tr'], c.batch_bc, s + 300000 + it)
        right = minibatch(d['right_tr'], c.batch_bc, s + 400000 + it)
        bottom = minibatch(d['bottom_tr'], c.batch_bc, s + 500000 + it)
        top = minibatch(d['top_tr'], c.batch_bc, s + 600000 + it)
        loss, p = batch_losses(c, m, col, ic, left, right, bottom, top)
        if not torch.isfinite(loss):
            raise RuntimeError(f'Non-finite loss at iteration {it}')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), c.grad_clip)
        opt.step()
        synchronize_device(c.device)
        itimes.append(time.time() - ti)
        should_eval = it == 1 or it % c.eval_every == 0 or it == c.iters
        if should_eval:
            m.eval()
            cv = minibatch(d['col_va'], c.val_batch_col, s + 700000 + it)
            iv = minibatch(d['ic_va'], c.val_batch_ic, s + 800000 + it)
            lvb = minibatch(d['left_va'], c.val_batch_bc, s + 900000 + it)
            rvb = minibatch(d['right_va'], c.val_batch_bc, s + 1000000 + it)
            bvb = minibatch(d['bottom_va'], c.val_batch_bc, s + 1100000 + it)
            tvb = minibatch(d['top_va'], c.val_batch_bc, s + 1200000 + it)
            loss_v, pv = batch_losses(c, m, cv, iv, lvb, rvb, bvb, tvb)
            vm = evaluate_val(c, m, d)
            elapsed = time.time() - t_start
            row = {'iter': it, 'loss_total_train': float(loss.item()), 'loss_total_val': float(loss_v.item()), 'loss_pde_train': float(p['pde'].item()), 'loss_pde_val': float(pv['pde'].item()), 'loss_mom_train': float(p['mom'].item()), 'loss_mom_val': float(pv['mom'].item()), 'loss_theta_pde_train': float(p['theta_pde'].item()), 'loss_theta_pde_val': float(pv['theta_pde'].item()), 'loss_div_train': float(p['div'].item()), 'loss_div_val': float(pv['div'].item()), 'loss_ic_train': float(p['ic'].item()), 'loss_ic_val': float(pv['ic'].item()), 'loss_bc_train': float(p['bc'].item()), 'loss_bc_val': float(pv['bc'].item()), 'loss_data_train': float(p['data'].item()), 'loss_data_val': float(pv['data'].item()), 'loss_data_u_train': float(p['data_u'].item()), 'loss_data_u_val': float(pv['data_u'].item()), 'loss_data_v_train': float(p['data_v'].item()), 'loss_data_v_val': float(pv['data_v'].item()), 'loss_data_p_train': float(p['data_p'].item()), 'loss_data_p_val': float(pv['data_p'].item()), 'loss_data_theta_train': float(p['data_theta'].item()), 'loss_data_theta_val': float(pv['data_theta'].item()), 'loss_data_speed_train': float(p['data_speed'].item()), 'loss_data_speed_val': float(pv['data_speed'].item()), **{k + '_val': v for k, v in vm.items()}, 'time_elapsed_sec': elapsed}
            append_history(h, row)
            write_history(os.path.join(c.out_dir, 'loss', 'train_history.csv'), h)
            if vm['RelL2'] < best:
                best = vm['RelL2']
                best_it = it
                torch.save({'iter': it, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'best_rel_l2': best, 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'best_model.pt'))
            print(f"[{it:06d}] loss={loss.item():.3e} val={loss_v.item():.3e} RelL2={vm['RelL2']:.3e} elapsed={elapsed / 60:.1f} min")
    synchronize_device(c.device)
    training_wall = time.time() - t_start
    torch.save({'iter': c.iters, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'completed_iterations': c.iters, 'training_completed': True, 'final_rel_l2_val': h['RelL2_val'][-1], 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'final_model.pt'))
    m.eval()
    g = eval_grid(c, m)
    np.savez(os.path.join(c.out_dir, 'grid.npz'), **g)
    save_field_data(c, g)
    overall = save_metrics(c, g)
    save_plots(c, g, h)
    synchronize_device(c.device)
    total_wall = time.time() - run_start
    save_cost(c, m, h, itimes, training_wall, total_wall, best_it, best, overall['RelL2'])
    print(f"[DONE] normal completion at {c.iters} iterations | {c.model_name} seed={c.model_seed} best={best:.6e} final_grid={overall['RelL2']:.6e}")
    return (m, h)
