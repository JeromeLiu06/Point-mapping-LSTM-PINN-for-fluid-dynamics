import csv
import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = json.loads((ROOT / "reference_manifest.json").read_text(encoding="utf-8"))
    assert sha(ROOT / "solver/fem_lid_taylor_hood_audited_v4.py") == manifest["solver_sha256"]
    data = {}
    centers = {}
    for n in (64, 128, 256):
        item = manifest["levels"][str(n)]
        path = ROOT / item["path"]
        assert sha(path) == item["sha256"]
        with np.load(path, allow_pickle=False) as grid:
            assert grid["N"].item() == n and grid["Re"].item() == 100
            assert grid["axis_order"].item() == "yx" and "p" not in grid.files
            assert grid["code_sha256"].item() == manifest["solver_sha256"]
            for key in ("x", "y"):
                np.testing.assert_array_equal(grid[key], np.linspace(0, 1, 2*n+1))
            u, v = grid["u"], grid["v"]
            for field in (u, v):
                assert list(field.shape) == item["shape_yx"] and field.dtype == np.float64
                assert np.isfinite(field).all()
                assert np.all(field[:, [0, -1]] == 0) and np.all(field[0] == 0)
            assert np.all(u[-1, 1:-1] == 1) and np.all(v[-1] == 0)
            stride = n // 64
            data[n] = dict(u=u[::stride, ::stride], v=v[::stride, ::stride])
            with np.load(path.with_name("centerlines.npz"), allow_pickle=False) as center:
                centers[n] = {key: center[key] for key in ("u", "v")}
                np.testing.assert_allclose(centers[n]["u"], u[::stride, n], atol=2e-14, rtol=0)
                np.testing.assert_allclose(centers[n]["v"], v[n, ::stride], atol=2e-14, rtol=0)
        metrics = json.loads(path.with_name("solve_metrics.json").read_text(encoding="utf-8"))
        cfg = json.loads(path.with_name("solver_config.json").read_text(encoding="utf-8"))
        assert metrics["state"] == "complete"
        for metric, limit in (("relative_update", "picard_tol"),
                              ("momentum_relative_residual", "momentum_relative_residual_tol"),
                              ("divergence_rms_residual", "divergence_rms_tol"),
                              ("linear_true_relative_residual", "linear_true_residual_max")):
            assert metrics[f"final_{metric}"] < cfg[limit]
    with (ROOT / "mesh_convergence/velocity_convergence.csv").open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    assert {r["quantity"] for r in rows} == {"u", "v", "velocity", "u_centerline", "v_centerline"}
    for row in rows:
        quantity = row["quantity"]
        if quantity == "velocity":
            values = [np.stack((x["u"], x["v"])) for x in data.values()]
        elif quantity.endswith("_centerline"):
            values = [x[quantity[0]] for x in centers.values()]
        else:
            values = [x[quantity] for x in data.values()]
        a, b, c = values
        d1, d2 = np.linalg.norm(a-b), np.linalg.norm(b-c)
        r1, r2 = d1 / np.linalg.norm(b), d2 / np.linalg.norm(c)
        order = np.log2(d1 / d2)
        gci = 125*r2 / (2**order - 1)
        keys = ("abs_L2_N64_N128", "abs_L2_N128_N256", "rel_L2_N64_N128",
                "rel_L2_N128_N256", "observed_order_p", "GCI_fine_percent")
        np.testing.assert_allclose((d1, d2, r1, r2, order, gci),
                                   [float(row[k]) for k in keys], rtol=1e-10)
    print("PASS: 3 velocity grids, wall/centerline checks, 4 convergence gates per mesh, 5 refinement rows")


if __name__ == "__main__":
    main()
