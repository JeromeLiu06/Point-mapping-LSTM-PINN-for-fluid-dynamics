# FEM Case 4 solver audit — audited v4

**Assessment: APPROVED_FOR_PRODUCTION**

Frozen source SHA256: `E7EFF6C78CD28DCD5E7934FE8733FA49321AEE4F4D6C966ABB7165D2B971299F`

## Governing problem and weak form

The solver targets the steady incompressible Navier–Stokes equations on the unit square at Re=100 (nu=0.01), with top-lid velocity (1,0), stationary remaining walls, zero body force, and stationary top-corner convention.

The assembled reduced system is `[A(u_prev), -B^T; B, 0]`, with both Dirichlet contributions retained: momentum `-A_free,D u_D` and continuity `-B_free,D u_D`. Velocity is continuous P2, pressure continuous P1, and one pressure degree of freedom is pinned only to remove the constant nullspace.

## Independent checks

- PASS — `source_hash_frozen`: value=e7eff6c78cd28dcd5e7934fe8733fa49321aee4f4d6c966abb7165d2b971299f
- PASS — `correct_advective_contraction`: value=[19.0, 43.0]
- PASS — `continuity_boundary_rhs_included`: rhs_p_l2_N64=0.003682847818679926
- PASS — `pressure_gauge`: p0=0.0
- PASS — `N64_discrete_mass_conservation`: value=6.33604999368103e-13
- PASS — `N64_nonlinear_momentum`: value=4.0996972012553415e-09
- PASS — `N64_linear_true_residual`: value=4.897295140996287e-10
- PASS — `boundary_values`: values={'bottom_no_slip_max_abs': 0.0, 'left_no_slip_max_abs': 0.0, 'right_no_slip_max_abs': 0.0, 'top_v_max_abs': 0.0, 'top_u_interior_max_error': 0.0, 'top_corner_u_max_abs': 0.0}
- PASS — `finite_fields`: 
- PASS — `direct_vs_GMRES_velocity`: relative_difference=5.139966699132829e-10
- PASS — `direct_vs_GMRES_pressure`: relative_difference=7.842566717294837e-10
- PASS — `prolongation_vs_full_continuation_u`: relative_difference=6.471504098432899e-10
- PASS — `prolongation_vs_full_continuation_v`: relative_difference=5.474853928308372e-10
- PASS — `Botella_u_min`: absolute_error=2.202190432781803e-05
- PASS — `Botella_v_max`: absolute_error=1.2398236528682327e-05
- PASS — `Botella_v_min`: absolute_error=2.6591703728928717e-05

## N64 physical-term norms

- viscous: `5.795505846006e-02`
- convective: `5.942480667364e-03`
- pressure_gradient: `5.752671670186e-02`
- momentum_residual: `2.358421194600e-10`
- continuity_boundary_rhs: `3.682847818680e-03`

## High-accuracy benchmark comparison

Botella–Peyret Re=100 extrema versus audited N64:

- u_min: computed `-0.2140203781`, benchmark `-0.2140424000`, absolute error `2.202e-05`
- v_max: computed `0.1795604018`, benchmark `0.1795728000`, absolute error `1.240e-05`
- v_min: computed `-0.2537764083`, benchmark `-0.2538030000`, absolute error `2.659e-05`

## Production gate

Production is permitted only with the exact frozen hash above. Completion requires all four numerical gates: Picard relative update <1e-8, nonlinear momentum relative residual <1e-7, divergence RMS <1e-10, and true unpreconditioned GMRES residual <5e-8. Exported fields must also pass finite-value and exact wall-boundary checks.

No numerical method can provide a literal proof of absolute correctness, but this audit combines equation-level review, independent direct-solver agreement, initialisation-path invariance, physical residuals, boundary checks, and an external high-accuracy benchmark.