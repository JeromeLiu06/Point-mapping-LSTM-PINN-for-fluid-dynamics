"""Independent small-grid reference for auditing the production FEM solver."""
import json
import sys
from pathlib import Path

import numpy as np
from scipy.sparse import bmat
from scipy.sparse.linalg import spsolve
from skfem import Basis, BilinearForm, MeshTri, asm
from skfem.element import ElementTriP1, ElementTriP2, ElementVector
from skfem.helpers import ddot, div, dot, grad, mul


@BilinearForm
def diffusion(u, v, w):
    return w.nu * ddot(grad(u), grad(v))


@BilinearForm
def advection(u, v, w):
    return dot(mul(grad(u), w.advecting_velocity), v)


@BilinearForm
def incompressibility(u, q, w):
    return q * div(u)


def solve(n):
    axis = np.linspace(0.0, 1.0, n + 1)
    mesh = MeshTri.init_tensor(axis, axis)
    velocity = Basis(mesh, ElementVector(ElementTriP2()), intorder=5)
    pressure = Basis(mesh, ElementTriP1(), intorder=5)
    boundary = mesh.facets_satisfying(lambda z: np.isclose(z[0], 0) | np.isclose(z[0], 1) | np.isclose(z[1], 0) | np.isclose(z[1], 1))
    lid = mesh.facets_satisfying(lambda z: np.isclose(z[1], 1))
    fixed = velocity.get_dofs(boundary).all()
    lid_u = velocity.get_dofs(lid).all("u^1")
    lid_x = velocity.doflocs[0, lid_u]
    lid_u = lid_u[(lid_x > 1e-12) & (lid_x < 1 - 1e-12)]
    bc = np.zeros(velocity.N); bc[lid_u] = 1.0
    free_u = np.setdiff1d(np.arange(velocity.N), fixed)
    free_p = np.arange(1, pressure.N)
    divergence = asm(incompressibility, velocity, pressure)
    solution = np.r_[bc, np.zeros(pressure.N)]
    history = []
    for reynolds in (1, 5, 10, 15, 20, 25, 27.5, 30, 32.5, 35, 40, 50, 60, 70, 85, 100):
        for iteration in range(1, 101):
            old = solution.copy()
            matrix_u = asm(diffusion, velocity, nu=1.0/reynolds) + asm(advection, velocity, advecting_velocity=velocity.interpolate(old[:velocity.N]))
            block = bmat([[matrix_u[free_u][:, free_u], -divergence[free_p][:, free_u].T],
                          [divergence[free_p][:, free_u], None]], format="csc")
            rhs = np.r_[-matrix_u[free_u][:, fixed] @ bc[fixed],
                        -divergence[free_p][:, fixed] @ bc[fixed]]
            reduced = spsolve(block, rhs)
            candidate = np.r_[bc, np.zeros(pressure.N)]
            candidate[np.r_[free_u, velocity.N + free_p]] = reduced
            omega = 0.8 if reynolds >= 25 else 1.0
            solution = omega * candidate + (1.0 - omega) * old
            solution[fixed] = bc[fixed]; solution[velocity.N] = 0.0
            update = np.linalg.norm(solution-old) / np.linalg.norm(solution)
            history.append([reynolds, iteration, float(update)])
            if update < 1e-11:
                break
        else:
            raise RuntimeError(f"Direct Picard did not converge at Re={reynolds}")
    u = solution[:velocity.N]; p = solution[velocity.N:]
    sample = np.linspace(0.0, 1.0, 129)
    raw_u = velocity.probes(np.vstack((np.full_like(sample, 0.5), sample))) @ u
    raw_v = velocity.probes(np.vstack((sample, np.full_like(sample, 0.5)))) @ u
    result = {
        "N": n,
        "velocity_coefficients": u.tolist(),
        "pressure_coefficients": p.tolist(),
        "centerline_axis": sample.tolist(),
        "u_centerline": raw_u[:len(sample)].tolist(),
        "v_centerline": raw_v[len(sample):].tolist(),
        "divergence_rms": float(np.linalg.norm(divergence @ u) / np.sqrt(pressure.N)),
        "history": history,
    }
    return result


if __name__ == "__main__":
    Path(sys.argv[2]).write_text(json.dumps(solve(int(sys.argv[1]))), encoding="utf-8")
