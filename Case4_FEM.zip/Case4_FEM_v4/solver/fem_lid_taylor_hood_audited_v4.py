"""Standard Re=100 lid cavity using Taylor--Hood P2-P1 and Picard continuation.

Sparse Oseen saddle systems are solved by restarted GMRES with an ILU
preconditioner.  The top-corner velocity is set to zero (stationary side-wall
corner convention) because the ideal lid boundary condition is discontinuous.
"""
import argparse, csv, hashlib, json, platform, sys, time
from pathlib import Path
import numpy as np
from scipy.sparse import bmat, csc_matrix, diags
from scipy.sparse.linalg import LinearOperator, gmres, spilu, splu
from skfem import MeshTri, Basis, BilinearForm, asm
from skfem.element import ElementTriP1, ElementTriP2, ElementVector
from skfem.helpers import ddot, dot, grad, div, mul

@BilinearForm
def visc(u,v,w): return w.nu*ddot(grad(u),grad(v))
@BilinearForm
def convection(u,v,w): return dot(mul(grad(u),w.uprev),v)
@BilinearForm
def divergence(u,q,w): return q*div(u)
@BilinearForm
def pressure_mass(p,q,w): return p*q
@BilinearForm
def pressure_laplace(p,q,w): return dot(grad(p),grad(q))
@BilinearForm
def pressure_oseen(p,q,w): return w.nu*dot(grad(p),grad(q))+dot(w.uprev,grad(p))*q

def js(path,obj): path.write_text(json.dumps(obj,indent=2,default=str),encoding='utf-8')
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--N',type=int,required=True); ap.add_argument('--output',required=True); ap.add_argument('--tol',type=float,default=1e-8); ap.add_argument('--max-picard',type=int,default=100); ap.add_argument('--initial-from',default=None,help='Converged coarser-grid taylor_hood_solution.npz at Re=100'); ap.add_argument('--gmres-rtol',type=float,default=1e-9); ap.add_argument('--momentum-rtol',type=float,default=1e-7); ap.add_argument('--divergence-tol',type=float,default=1e-10); a=ap.parse_args()
    if a.N < 2: ap.error('--N must be at least 2')
    if not (0.0 < a.tol < 1.0): ap.error('--tol must lie in (0, 1)')
    if a.max_picard < 1: ap.error('--max-picard must be positive')
    if not (0.0 < a.gmres_rtol < 1.0): ap.error('--gmres-rtol must lie in (0, 1)')
    out=Path(a.output); [(out/x).mkdir(parents=True,exist_ok=True) for x in ('mesh','config','logs','fields','metrics','figures')]
    code=Path(__file__); code_sha256=hashlib.sha256(code.read_bytes()).hexdigest()
    continuation=(1,5,10,15,20,25,27.5,30,32.5,35,40,50,60,70,85,100)
    initial_sha256=hashlib.sha256(Path(a.initial_from).read_bytes()).hexdigest() if a.initial_from else None
    cfg={'benchmark':'standard_lid_driven_cavity','formulation_version':'case4_re100_audited_v4','governing_equations':'steady incompressible Navier-Stokes in advective form','Re':100,'nu':.01,'domain':[0,1,0,1],'lid':[1,0],'other_walls':[0,0],'forcing':[0,0],'element_velocity':'P2','element_pressure':'P1','quadrature_order':5,'N':a.N,'nonlinear':'Anderson-accelerated Picard continuation','continuation_Re':list(continuation) if not a.initial_from else [100],'initial_from':a.initial_from,'initial_solution_sha256':initial_sha256,'linear_solver':'GMRES(100)+ILU-LSC','gmres_rtol':a.gmres_rtol,'linear_true_residual_max':5e-8,'picard_tol':a.tol,'momentum_relative_residual_tol':a.momentum_rtol,'divergence_rms_tol':a.divergence_tol,'max_picard':a.max_picard,'corner_convention':'top corners stationary','pressure_gauge':'P1 dof 0 pinned to zero','code_sha256':code_sha256}; js(out/'config'/'config.json',cfg)
    t0=time.perf_counter(); x=np.linspace(0,1,a.N+1); mesh=MeshTri.init_tensor(x,x); ub=Basis(mesh,ElementVector(ElementTriP2()),intorder=5); pb=Basis(mesh,ElementTriP1(),intorder=5)
    np.savez_compressed(out/'mesh'/'mesh.npz',points=mesh.p,triangles=mesh.t)
    boundary=mesh.facets_satisfying(lambda z: np.isclose(z[0],0)|np.isclose(z[0],1)|np.isclose(z[1],0)|np.isclose(z[1],1)); top=mesh.facets_satisfying(lambda z:np.isclose(z[1],1))
    D=ub.get_dofs(boundary).all(); topx=ub.get_dofs(top).all('u^1'); loc=ub.doflocs[:,topx]; topx=topx[(loc[0]>1e-12)&(loc[0]<1-1e-12)]
    bc=np.zeros(ub.N); bc[topx]=1.; free_u=np.setdiff1d(np.arange(ub.N),D); pressure_pin=0; free_p=np.arange(1,pb.N); free=np.r_[free_u,ub.N+free_p]
    B=asm(divergence,ub,pb); sol=np.r_[bc,np.zeros(pb.N)]; rows=[]
    if a.initial_from:
        initial_path=Path(a.initial_from); q=np.load(initial_path); us=q['velocity_coefficients']; ps=q['pressure_coefficients']
        source_n=int(round(np.sqrt(len(ps))))-1; source_axis=np.linspace(0,1,source_n+1); source_mesh=MeshTri.init_tensor(source_axis,source_axis)
        source_ub=Basis(source_mesh,ElementVector(ElementTriP2()),intorder=5); source_pb=Basis(source_mesh,ElementTriP1(),intorder=5)
        if len(us)!=source_ub.N or len(ps)!=source_pb.N or source_n>=a.N: raise RuntimeError('Initial solution must be a consistent, coarser Taylor-Hood solution')
        if not (np.isfinite(us).all() and np.isfinite(ps).all()): raise RuntimeError('Initial solution contains non-finite coefficients')
        target_parts=ub.split_indices(); target_points=ub.doflocs[:,target_parts[0]]; m=target_points.shape[1]; init_u=np.empty(m); init_v=np.empty(m); init_p=np.empty(pb.N); probe_batch=4096
        for lo in range(0,m,probe_batch):
            hi=min(lo+probe_batch,m); raw=source_ub.probes(target_points[:,lo:hi])@us; count=hi-lo; init_u[lo:hi]=raw[:count]; init_v[lo:hi]=raw[count:]
        for lo in range(0,pb.N,probe_batch):
            hi=min(lo+probe_batch,pb.N); init_p[lo:hi]=source_pb.probes(pb.doflocs[:,lo:hi])@ps
        sol[target_parts[0]]=init_u; sol[target_parts[1]]=init_v; sol[ub.N:]=init_p; sol[D]=bc[D]; sol[ub.N+pressure_pin]=0
        continuation=(100,)
    restart_file=out/'fields'/'continuation_restart.npz'
    start_index=0
    if restart_file.exists():
        q=np.load(restart_file); restart_hash=str(q['code_sha256']);
        if restart_hash!=code_sha256: raise RuntimeError(f'Restart source hash mismatch: {restart_hash} != {code_sha256}')
        sol=q['solution']; last=float(q['Re']); start_index=continuation.index(last)+1
    for Re in continuation[start_index:]:
        nu=1/Re
        xhist=[]; fhist=[]
        for k in range(1,a.max_picard+1):
            old=sol.copy(); field=ub.interpolate(old[:ub.N]); A=asm(visc,ub,nu=nu)+asm(convection,ub,uprev=field)
            Au=A[free_u][:,free_u].tocsc(); Br=B[free_p][:,free_u].tocsc(); Kr=bmat([[Au,-Br.T],[Br,None]],format='csc')
            rhs_u=-(A[free_u][:,D]@bc[D]); rhs_p=-(B[free_p][:,D]@bc[D]); rr=np.r_[rhs_u,rhs_p]
            # Physics-aware block preconditioner: approximate inverse of the
            # Oseen velocity block and pressure Schur complement.
            Ailu=spilu(Au+csc_matrix((np.full(Au.shape[0],1e-10),(np.arange(Au.shape[0]),np.arange(Au.shape[0]))),shape=Au.shape),drop_tol=1e-3,fill_factor=8)
            # Algebraic least-squares commutator (LSC/BFBt) Schur inverse.
            # It avoids pressure boundary-condition sensitivity of a basic PCD.
            da=np.maximum(np.abs(Au.diagonal()),1e-12); Di=diags(1.0/da,format='csc')
            G=(Br@Di@Br.T).tocsc(); H=(Br@Di@Au@Di@Br.T).tocsc(); Glu=splu(G); nuv=len(free_u)
            def prec(r):
                zp=Glu.solve(H@Glu.solve(r[nuv:]))
                return np.r_[Ailu.solve(r[:nuv]),zp]
            its=[0]; M=LinearOperator(Kr.shape,matvec=prec)
            xr,info=gmres(Kr,rr,M=M,restart=100,rtol=a.gmres_rtol,atol=0,maxiter=50,callback=lambda _:its.__setitem__(0,its[0]+1),callback_type='pr_norm')
            linear_true_residual=np.linalg.norm(Kr@xr-rr)/max(np.linalg.norm(rr),1e-30)
            candidate=np.r_[bc,np.zeros(pb.N)]; candidate[free]=xr
            # Anderson-accelerated Picard (depth 5), with conservative damping.
            f=candidate-old; xhist.append(old.copy()); fhist.append(f.copy()); mk=min(5,len(fhist)-1)
            accelerated=candidate
            if mk>0:
                X=xhist[-mk-1:]; F=fhist[-mk-1:]; dX=np.column_stack([X[j+1]-X[j] for j in range(mk)]); dF=np.column_stack([F[j+1]-F[j] for j in range(mk)])
                gamma=np.linalg.lstsq(dF,f,rcond=1e-10)[0]; accelerated=candidate-(dX+dF)@gamma
            omega=.8 if Re>=25 else 1.; sol=omega*accelerated+(1-omega)*old; sol[D]=bc[D]; sol[ub.N+pressure_pin]=0
            rel=np.linalg.norm(sol-old)/max(np.linalg.norm(sol),1e-30); divres=np.linalg.norm(B@sol[:ub.N])/max(np.sqrt(pb.N),1)
            Acheck=asm(visc,ub,nu=nu)+asm(convection,ub,uprev=ub.interpolate(sol[:ub.N])); momentum=(Acheck@sol[:ub.N]-B.T@sol[ub.N:])[free_u]; momentum_scale=max(np.linalg.norm((Acheck@sol[:ub.N])[free_u]),np.linalg.norm((B.T@sol[ub.N:])[free_u]),1e-30); momentum_relative_residual=np.linalg.norm(momentum)/momentum_scale
            rows.append([Re,k,rel,momentum_relative_residual,divres,linear_true_residual,info,its[0],time.perf_counter()-t0]);
            with (out/'logs'/'nonlinear_residuals.csv').open('w',newline='') as f: w=csv.writer(f);w.writerow(['Re','iteration','relative_update','momentum_relative_residual','divergence_rms_residual','linear_true_relative_residual','gmres_info','gmres_iterations','elapsed_s']);w.writerows(rows)
            js(out/'metrics'/'status.json',{'state':'running','formulation_version':'case4_re100_audited_v4','code_sha256':code_sha256,'N':a.N,'Re':Re,'nonlinear_iteration':k,'relative_update':rel,'momentum_relative_residual':momentum_relative_residual,'divergence_rms_residual':divres,'linear_true_relative_residual':linear_true_residual,'gmres_info':info,'gmres_iterations':its[0],'elapsed_s':time.perf_counter()-t0})
            if info!=0: raise RuntimeError(f'GMRES failed info={info} at Re={Re}, Picard={k}, inner={its[0]}')
            if linear_true_residual>5e-8: raise RuntimeError(f'GMRES reported success but true residual is {linear_true_residual}')
            if rel<a.tol and momentum_relative_residual<a.momentum_rtol and divres<a.divergence_tol: break
        else: raise RuntimeError(f'Picard did not converge at Re={Re}')
        np.savez_compressed(restart_file,solution=sol,Re=Re,N=a.N,formulation_version='case4_re100_audited_v4',code_sha256=code_sha256)
    u,p=sol[:ub.N],sol[ub.N:]; np.savez_compressed(out/'fields'/'taylor_hood_solution.npz',velocity_coefficients=u,pressure_coefficients=p,velocity_dof_coordinates=ub.doflocs,pressure_dof_coordinates=pb.doflocs,N=a.N,Re=100,formulation_version='case4_re100_audited_v4',code_sha256=code_sha256)
    # Centerline values prepared for Ghia comparison and mesh convergence.
    ys=np.linspace(0,1,129); xs=np.linspace(0,1,129)
    try:
        Pu=ub.probes(np.vstack((np.full_like(ys,.5),ys))); Pv=ub.probes(np.vstack((xs,np.full_like(xs,.5)))); uc=Pu@u; vc=Pv@u
        # Vector probe result is component-blocked: all u values, then all v values.
        np.savez_compressed(out/'fields'/'centerlines.npz',y=ys,u=uc[:len(ys)],x=xs,v=vc[len(xs):],formulation_version='case4_re100_audited_v4')
    except Exception as e: (out/'logs'/'centerline_error.txt').write_text(repr(e),encoding='utf-8')
    # Export the same 2N+1 uniform reference grid used by the corrected N64/N128
    # results.  Probe in batches to keep the N256 post-processing memory bounded.
    rg=np.linspace(0,1,2*a.N+1); xx,yy=np.meshgrid(rg,rg,indexing='xy'); pts=np.vstack((xx.ravel(),yy.ravel()))
    ug=np.empty(pts.shape[1]); vg=np.empty(pts.shape[1]); pg=np.empty(pts.shape[1]); batch=4096
    for lo in range(0,pts.shape[1],batch):
        hi=min(lo+batch,pts.shape[1]); uv=ub.probes(pts[:,lo:hi])@u
        m=hi-lo; ug[lo:hi]=uv[:m]; vg[lo:hi]=uv[m:]; pg[lo:hi]=pb.probes(pts[:,lo:hi])@p
    shape=xx.shape; ug=ug.reshape(shape); vg=vg.reshape(shape); pg=pg.reshape(shape)
    boundary_checks={'bottom_no_slip_max_abs':float(max(np.abs(ug[0]).max(),np.abs(vg[0]).max())),'left_no_slip_max_abs':float(max(np.abs(ug[:,0]).max(),np.abs(vg[:,0]).max())),'right_no_slip_max_abs':float(max(np.abs(ug[:,-1]).max(),np.abs(vg[:,-1]).max())),'top_v_max_abs':float(np.abs(vg[-1]).max()),'top_u_interior_max_error':float(np.abs(ug[-1,1:-1]-1).max()),'top_corner_u_max_abs':float(max(abs(ug[-1,0]),abs(ug[-1,-1])))}
    if not np.isfinite(np.r_[ug.ravel(),vg.ravel(),pg.ravel()]).all() or max(boundary_checks.values())>2e-10: raise RuntimeError(f'Export QA failed: {boundary_checks}')
    np.savez_compressed(out/'fields'/'reference_grid.npz',x=rg,y=rg,u=ug,v=vg,p=pg,Re=100,N=a.N,formulation_version='case4_re100_audited_v4',code_sha256=code_sha256)
    total=time.perf_counter()-t0; js(out/'metrics'/'solve_metrics.json',{'state':'complete','formulation_version':'case4_re100_audited_v4','code_sha256':code_sha256,'N':a.N,'Re':100,'solve_time_s':total,'velocity_dofs':int(ub.N),'pressure_dofs':int(pb.N),'total_dofs':int(ub.N+pb.N),'final_relative_update':rows[-1][2],'final_momentum_relative_residual':rows[-1][3],'final_divergence_rms_residual':rows[-1][4],'final_linear_true_relative_residual':rows[-1][5],'boundary_checks':boundary_checks,'centerline_points':129,'reference_grid_shape':[int(shape[0]),int(shape[1])]}); js(out/'metrics'/'status.json',{'state':'complete','formulation_version':'case4_re100_audited_v4','code_sha256':code_sha256,'N':a.N,'Re':100,'elapsed_s':total,'reference_file':str((out/'fields'/'reference_grid.npz').resolve())})
if __name__=='__main__': main()
