# Case IV · Audited v4 FEM velocity reference

`levels/N256/velocity_reference_grid.npz` is the reference used by the companion Experiment B/C package. It contains the original float64 `x,y,u,v` values, with fields indexed as `[y,x]`. The domain is the unit square, Re=100, kinematic viscosity 0.01, and the top lid has unit horizontal velocity away from its two stationary corners. Pressure remains part of the Taylor–Hood P2/P1 solve. The archived mesh study did not establish spatial convergence for pressure.

| FEM subdivisions per direction | Exported velocity grid | Role |
|---:|---:|---|
| 64 | 129×129 | Coarse refinement evidence |
| 128 | 257×257 | Intermediate refinement evidence |
| 256 | 513×513 | Evaluation reference |

All three grids are nested. `mesh_convergence/` contains the convergence table, residual and solver summaries, and 129-point centerline comparisons. Velocity-vector differences use both velocity components together. Each level includes its own centerlines, configuration with relative paths, residual history and final solver metrics. `reference_manifest.json` records the new hashes and the hashes of the corresponding source grids. `MANIFEST.sha256` covers the shipped payload files.

Use the dependency versions listed in `requirements.txt`, then run `python verify_fem.py` in this directory. This recomputes five velocity and centerline convergence rows on the common 129×129 grid and checks each mesh's saved convergence gates and boundary values.

The solver source is byte-identical to the audited v4 solver. To regenerate the FEM solutions, run this chain in a fresh directory tree.

```text
python solver/fem_lid_taylor_hood_audited_v4.py --N 32 --output runs/N32
python solver/fem_lid_taylor_hood_audited_v4.py --N 64 --initial-from runs/N32/fields/taylor_hood_solution.npz --output runs/N64
python solver/fem_lid_taylor_hood_audited_v4.py --N 128 --initial-from runs/N64/fields/taylor_hood_solution.npz --output runs/N128
python solver/fem_lid_taylor_hood_audited_v4.py --N 256 --initial-from runs/N128/fields/taylor_hood_solution.npz --output runs/N256
```

For B/C evaluation, use the frozen velocity file supplied here. A newly solved file is a separate numerical reproduction and has its own checksum. The local solver check ran N8 from scratch and N16 by prolongation. The N64–N256 production solves are the original audited results. See `audit/AUDIT_REPORT.md` and `audit/release_solver_check.json`.
