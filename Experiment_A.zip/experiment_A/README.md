# Experiment A · 基线与扩展基线

- **论文位置** 正文表 3、§5.1、表 4、图 3–4，SI §S3、表 S3、表 S11。
- **算例** `case1_tgv/` 为 TGV，`case2_mms_cavity/` 为制造解方腔，`case3_rbc/` 为制造解热流体耦合 RBC。
- **覆盖** 每个算例各 7 个脚本。正文核心比较含 PINN、LSTM1-PINN、ResAtten-PINN、DP-PINN。SI 扩展比较另含 Param-ANN-PINN、Causal-PINN、PirateNet。仓库名 `reatten` 对应 ResAtten-PINN，`param_ann` 对应 Param-ANN-PINN。
- **LSTM1 实现** 每个物理点的坐标分量依次作为标量 token。Cases I 和 III 输入 `x,y,t`，Case II 输入 `x,y`。三份源码使用 `Linear(1,192)` 和两层 LSTM。这一实现归 A。Case II 的制造压力为 `sin(pi*x)*sin(pi*y)`。
- **执行入口** 各 Python 文件可从其 `__main__` 启动训练。第三方导入依赖为 NumPy、PyTorch、Matplotlib。源码会自行生成训练数据，并向脚本默认的输出目录写入训练结果。
- **历史结构版本** 仓库 ResAtten 的特征与门控层数符合 SI 表 S3。正文表 2 还记载原坐标 token 注意力实现，例如本地 `算例三NS_顶盖驱动/ns2d_cavity_resattn_pinn_case3_final.py` 先把 `x,y` 堆为两个 token。复现正文历史结果时，需核对原运行使用的具体实现。
- **检查点核对** 正文表 4 分开列出历史 final validation 与按训练损失选出的记录。仓库中例如 Case II PINN 的 `best_model.pt` 按验证集相对 L2 保存。需要逐一对照历史记录的选点规则、归一化和评估网格才能复现原表。
