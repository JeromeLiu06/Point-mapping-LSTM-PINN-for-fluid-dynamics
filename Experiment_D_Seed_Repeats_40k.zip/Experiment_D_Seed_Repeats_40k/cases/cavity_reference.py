import hashlib
import json
from pathlib import Path
import numpy as np
import torch
REFERENCE = Path(__file__).resolve().parents[1] / 'data' / 'case4_fem_N256.npz'
REFERENCE_SHA256 = 'bd201f003aa66ddc5ae3a53a934595367a105337f771a45a26409c7ea816521a'

def load_fem_reference(path):
    path = Path(path)
    if hashlib.sha256(path.read_bytes()).hexdigest() != REFERENCE_SHA256:
        raise ValueError('Case IV requires the bundled N=256 FEM v4 reference.')
    with np.load(path, allow_pickle=False) as a:
        return {key: np.asarray(a[key], dtype=np.float64) for key in ('x', 'y', 'u', 'v', 'p')}

def interpolate_fem(reference, x, y):
    x, y = (np.asarray(x, dtype=np.float64), np.asarray(y, dtype=np.float64))
    gx, gy = (reference['x'], reference['y'])
    if x.shape != y.shape or not (np.all((gx[0] <= x) & (x <= gx[-1])) and np.all((gy[0] <= y) & (y <= gy[-1]))):
        raise ValueError('FEM query coordinates must be paired and inside the reference grid.')
    ix = np.clip(np.searchsorted(gx, x, side='right') - 1, 0, len(gx) - 2)
    iy = np.clip(np.searchsorted(gy, y, side='right') - 1, 0, len(gy) - 2)
    fx = (x - gx[ix]) / (gx[ix + 1] - gx[ix])
    fy = (y - gy[iy]) / (gy[iy + 1] - gy[iy])
    result = {}
    for name in ('u', 'v', 'p'):
        field = reference[name]
        lower = field[iy, ix] * (1 - fx) + field[iy, ix + 1] * fx
        upper = field[iy + 1, ix] * (1 - fx) + field[iy + 1, ix + 1] * fx
        result[name] = lower * (1 - fy) + upper * fy
    result['speed'] = np.hypot(result['u'], result['v'])
    return result

@torch.no_grad()
def evaluate_grid(cfg, model, reference, make_contexts, predict):
    xs = np.linspace(cfg.x0, cfg.x1, cfg.eval_nx)
    ys = np.linspace(cfg.y0, cfg.y1, cfg.eval_ny)
    xx, yy = np.meshgrid(xs, ys, indexing='xy')
    x, y = [torch.as_tensor(a.reshape(-1, 1), dtype=cfg.dtype, device=cfg.device) for a in (xx, yy)]
    seq = make_contexts(x, y, cfg.sequence_length) if cfg.model_name.startswith('S-LSTM-PINN') else None
    batches = []
    for start in range(0, len(x), 256):
        part = slice(start, start + 256)
        values = predict(cfg, model, x[part], y[part], None if seq is None else seq[part])
        batches.append(torch.cat(values, dim=1).cpu().numpy())
    uvp = np.concatenate(batches).reshape(*xx.shape, 3).astype(np.float64)
    ref = interpolate_fem(reference, xx, yy)
    pressure_shift = np.mean(uvp[:, :, 2] - ref['p'])
    g = dict(x=xs, y=ys, axis_order=np.array('yx'), p_pred_raw=uvp[:, :, 2], pressure_prediction_shift_subtracted=pressure_shift)
    pred = dict(u=uvp[:, :, 0], v=uvp[:, :, 1], p=uvp[:, :, 2] - pressure_shift, speed=np.hypot(uvp[:, :, 0], uvp[:, :, 1]))
    for name in pred:
        g[name + '_pred'] = pred[name]
        g[name + '_ref'] = ref[name]
        g[name + '_err'] = pred[name] - ref[name]
    return g

def save_velocity_metrics(directory, grid):
    fields = ('u', 'v')
    err = np.stack([grid[f + '_err'] for f in fields])
    ref = np.stack([grid[f + '_ref'] for f in fields])
    relative = np.linalg.norm(err.reshape(2, -1), axis=1) / np.linalg.norm(ref.reshape(2, -1), axis=1)
    metrics = dict(component_relative_l2=dict(zip(fields, relative)), mean_component_relative_l2=float(relative.mean()), velocity_vector_relative_l2=float(np.linalg.norm(err) / np.linalg.norm(ref)), aligned_pressure_rmse=float(np.sqrt(np.mean(grid['p_err'] ** 2))), fem_sha256=REFERENCE_SHA256)
    path = Path(directory) / 'metrics' / 'case4_velocity.json'
    path.write_text(json.dumps(metrics, indent=2, allow_nan=False), encoding='utf-8')
