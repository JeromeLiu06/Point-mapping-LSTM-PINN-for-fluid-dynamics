import os
import csv
import json
import math
import time
import platform
from dataclasses import dataclass, asdict
from typing import Dict, Tuple, List, Any
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
MODEL_KIND = 'S-LSTM-PINN'
MODEL_SEED = 0
DATA_SEED = 0

@dataclass
class Config:
    write_plots: bool = True
    case_name: str = 'Lid'
    model_name: str = MODEL_KIND
    device: str = 'cuda' if torch.cuda.is_available() else 'cpu'
    dtype: torch.dtype = torch.float32
    nu: float = 0.01
    x0: float = 0.0
    x1: float = 1.0
    y0: float = 0.0
    y1: float = 1.0
    n_col: int = 22000
    n_bc_bottom: int = 2200
    n_bc_top: int = 2200
    n_bc_left: int = 2200
    n_bc_right: int = 2200
    train_ratio: float = 0.7
    iters: int = 40000
    lr: float = 0.0001
    batch_col: int = 1024
    batch_bc: int = 256
    val_batch_col: int = 512
    val_batch_bc: int = 256
    val_metric_points: int = 4000
    eval_every: int = 500
    grad_clip: float = 1.0
    w_mom: float = 1.0
    w_div: float = 1.0
    w_bc: float = 10.0
    pinn_hidden: int = 128
    pinn_layers: int = 8
    param_hidden: int = 280
    param_layers: int = 9
    lstm_hidden: int = 192
    lstm_layers: int = 2
    sequence_length: int = 4
    eval_nx: int = 120
    eval_ny: int = 120
    rel_l2_thresholds: Tuple[float, float] = (0.01, 0.001)
    data_seed: int = DATA_SEED
    model_seed: int = MODEL_SEED
    out_dir: str = './R5_random_seed/case2_Lid/S-LSTM-PINN/seed0'

def ensure_dir(p):
    if p:
        os.makedirs(p, exist_ok=True)

def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def count_trainable_parameters(m):
    return sum((p.numel() for p in m.parameters() if p.requires_grad))

def count_total_parameters(m):
    return sum((p.numel() for p in m.parameters()))

def parameter_size_mb(m):
    return sum((p.numel() * p.element_size() for p in m.parameters())) / 1024 ** 2

def hardware_info(device):
    d = {'device': device, 'python_version': platform.python_version(), 'platform': platform.platform(), 'cpu_name': platform.processor() or platform.machine(), 'torch_version': torch.__version__, 'cuda_available': torch.cuda.is_available(), 'cuda_version': torch.version.cuda or 'None', 'gpu_count': torch.cuda.device_count() if torch.cuda.is_available() else 0, 'gpu_name': 'None', 'gpu_total_memory_MB': 0.0}
    if torch.cuda.is_available() and device.startswith('cuda'):
        p = torch.cuda.get_device_properties(torch.cuda.current_device())
        d['gpu_name'] = p.name
        d['gpu_total_memory_MB'] = p.total_memory / 1024 ** 2
    return d

def peak_gpu(device):
    if torch.cuda.is_available() and device.startswith('cuda'):
        return (torch.cuda.max_memory_allocated() / 1024 ** 2, torch.cuda.max_memory_reserved() / 1024 ** 2)
    return (0.0, 0.0)

def write_csv(path, rows, fields=None):
    ensure_dir(os.path.dirname(path))
    fields = fields or (list(rows[0].keys()) if rows else [])
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def write_history(path, h):
    ensure_dir(os.path.dirname(path))
    keys = list(h.keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(keys)
        for i in range(len(h[keys[0]])):
            w.writerow([h[k][i] for k in keys])

def metrics_np(pred, ref):
    p = np.asarray(pred).reshape(-1)
    r = np.asarray(ref).reshape(-1)
    d = p - r
    mse = float(np.mean(d * d))
    l2 = float(np.linalg.norm(d))
    return {'MSE': mse, 'RMSE': float(np.sqrt(mse)), 'MAE': float(np.mean(np.abs(d))), 'L2': l2, 'RelL2': float(l2 / (np.linalg.norm(r) + 1e-12)), 'MaxAbsError': float(np.max(np.abs(d))), 'MeanAbsError': float(np.mean(np.abs(d)))}

def metrics_torch(pred, ref):
    d = pred.detach() - ref.detach()
    mse = torch.mean(d * d)
    l2 = torch.linalg.norm(d.reshape(-1))
    return {'MSE': float(mse.item()), 'RMSE': float(torch.sqrt(mse).item()), 'MAE': float(torch.mean(torch.abs(d)).item()), 'L2': float(l2.item()), 'RelL2': float((l2 / (torch.linalg.norm(ref.detach().reshape(-1)) + 1e-12)).item()), 'MaxAbsError': float(torch.max(torch.abs(d)).item()), 'MeanAbsError': float(torch.mean(torch.abs(d)).item())}

def fpoly(x):
    return x ** 2 - 2.0 * x ** 3 + x ** 4

def fpoly_p(x):
    return 2.0 * x - 6.0 * x ** 2 + 4.0 * x ** 3

def fpoly_pp(x):
    return 2.0 - 12.0 * x + 12.0 * x ** 2

def fpoly_ppp(x):
    return -12.0 + 24.0 * x

def gpoly(y):
    return y ** 3 - y ** 2

def gpoly_p(y):
    return 3.0 * y ** 2 - 2.0 * y

def gpoly_pp(y):
    return 6.0 * y - 2.0

def uvp_mms(x, y):
    fx = fpoly(x)
    fpx = fpoly_p(x)
    gy = gpoly(y)
    gpy = gpoly_p(y)
    u = fx * gpy
    v = -fpx * gy
    p = torch.sin(math.pi * x) * torch.sin(math.pi * y)
    return (u, v, p)

def forcing_mms(x, y, nu):
    fx = fpoly(x)
    fpx = fpoly_p(x)
    fppx = fpoly_pp(x)
    fpppx = fpoly_ppp(x)
    gy = gpoly(y)
    gpy = gpoly_p(y)
    gppy = gpoly_pp(y)
    u = fx * gpy
    v = -fpx * gy
    ux = fpx * gpy
    uy = fx * gppy
    uxx = fppx * gpy
    uyy = 6.0 * fx
    vx = -fppx * gy
    vy = -fpx * gpy
    vxx = -fpppx * gy
    vyy = -fpx * gppy
    px = math.pi * torch.cos(math.pi * x) * torch.sin(math.pi * y)
    py = math.pi * torch.sin(math.pi * x) * torch.cos(math.pi * y)
    fu = u * ux + v * uy + px - nu * (uxx + uyy)
    fv = u * vx + v * vy + py - nu * (vxx + vyy)
    return (fu, fv)

def rand_fixed(n, lo, hi, device, dtype, seed):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    return lo + (hi - lo) * torch.rand(n, 1, generator=g, device=device, dtype=dtype)

def split_fixed(n, ratio, seed, device):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    idx = torch.randperm(n, generator=g, device=device)
    ntr = max(1, min(int(ratio * n), n - 1))
    return (idx[:ntr], idx[ntr:])

def _part1by1(v):
    v = v.astype(np.uint32)
    v = (v | v << 8) & 16711935
    v = (v | v << 4) & 252645135
    v = (v | v << 2) & 858993459
    v = (v | v << 1) & 1431655765
    return v

def morton_order(x, y, bits=16):
    xn = np.clip(x.detach().cpu().numpy().reshape(-1), 0, 1)
    yn = np.clip(y.detach().cpu().numpy().reshape(-1), 0, 1)
    scale = float((1 << bits) - 1)
    xi = (xn * scale).astype(np.uint32)
    yi = (yn * scale).astype(np.uint32)
    key = _part1by1(xi) | _part1by1(yi) << 1
    return torch.as_tensor(np.argsort(key), device=x.device, dtype=torch.long)

def build_spatial_contexts(x, y, m, side=None):
    if side in ('bottom', 'top'):
        order = torch.argsort(x[:, 0])
    elif side in ('left', 'right'):
        order = torch.argsort(y[:, 0])
    else:
        order = morton_order(x, y)
    xs, ys = (x[order], y[order])
    n = xs.shape[0]
    ids = torch.arange(n, device=x.device)
    offs = torch.arange(m - 1, -1, -1, device=x.device)
    ctx = torch.clamp(ids[:, None] - offs[None, :], min=0)
    seq_sorted = torch.stack([xs[ctx, 0], ys[ctx, 0], torch.zeros_like(xs[ctx, 0])], dim=2)
    inv = torch.empty_like(order)
    inv[order] = torch.arange(n, device=x.device)
    return seq_sorted[inv]

def make_bc(c, n, seed, kind):
    if kind == 'bottom':
        x = rand_fixed(n, c.x0, c.x1, c.device, c.dtype, seed)
        y = torch.full_like(x, c.y0)
    elif kind == 'top':
        x = rand_fixed(n, c.x0, c.x1, c.device, c.dtype, seed)
        y = torch.full_like(x, c.y1)
    elif kind == 'left':
        y = rand_fixed(n, c.y0, c.y1, c.device, c.dtype, seed)
        x = torch.full_like(y, c.x0)
    elif kind == 'right':
        y = rand_fixed(n, c.y0, c.y1, c.device, c.dtype, seed)
        x = torch.full_like(y, c.x1)
    u, v, p = uvp_mms(x, y)
    return (x, y, u.detach(), v.detach(), p.detach())

def split_bundle(bundle, tr, va):
    return (tuple((a[tr] for a in bundle)), tuple((a[va] for a in bundle)))

def build_dataset(c):
    s = c.data_seed
    x = rand_fixed(c.n_col, c.x0, c.x1, c.device, c.dtype, s + 11)
    y = rand_fixed(c.n_col, c.y0, c.y1, c.device, c.dtype, s + 12)
    tr, va = split_fixed(c.n_col, c.train_ratio, s + 101, c.device)
    col_tr = (x[tr], y[tr])
    col_va = (x[va], y[va])
    bc = {}
    specs = [('bottom', c.n_bc_bottom, 201), ('top', c.n_bc_top, 202), ('left', c.n_bc_left, 203), ('right', c.n_bc_right, 204)]
    for kind, n, off in specs:
        full = make_bc(c, n, s + off, kind)
        tri, vai = split_fixed(n, c.train_ratio, s + off + 1000, c.device)
        bc[kind + '_tr'], bc[kind + '_va'] = split_bundle(full, tri, vai)
    col_seq_tr = build_spatial_contexts(col_tr[0], col_tr[1], c.sequence_length)
    col_seq_va = build_spatial_contexts(col_va[0], col_va[1], c.sequence_length)
    bc_seq = {}
    for kind in ('bottom', 'top', 'left', 'right'):
        bt = bc[kind + '_tr']
        bv = bc[kind + '_va']
        bc_seq[kind + '_seq_tr'] = build_spatial_contexts(bt[0], bt[1], c.sequence_length, kind)
        bc_seq[kind + '_seq_va'] = build_spatial_contexts(bv[0], bv[1], c.sequence_length, kind)
    g = torch.Generator(device=c.device)
    g.manual_seed(s + 505)
    vidx = torch.randperm(col_va[0].shape[0], generator=g, device=c.device)[:min(c.val_metric_points, col_va[0].shape[0])]
    return {'col_tr': col_tr, 'col_va': col_va, 'col_seq_tr': col_seq_tr, 'col_seq_va': col_seq_va, **bc, **bc_seq, 'val_metric_idx': vidx}

def minibatch_indices(n, batch, seed, device):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    return torch.randperm(n, generator=g, device=device)[:min(batch, n)]

def select_bundle(bundle, idx):
    return tuple((a[idx] for a in bundle))

class FFPINN(nn.Module):

    def __init__(self, in_dim, width, depth):
        super().__init__()
        a = [nn.Linear(in_dim, width), nn.Tanh()]
        for _ in range(depth - 1):
            a += [nn.Linear(width, width), nn.Tanh()]
        a += [nn.Linear(width, 3)]
        self.net = nn.Sequential(*a)

    def forward(self, x, y):
        o = self.net(torch.cat([x, y], 1))
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3])

class SpatialLSTM(nn.Module):

    def __init__(self, c):
        super().__init__()
        self.embed = nn.Linear(3, c.lstm_hidden)
        self.lstm = nn.LSTM(c.lstm_hidden, c.lstm_hidden, num_layers=c.lstm_layers, batch_first=True)
        self.head = nn.Sequential(nn.Linear(c.lstm_hidden, c.lstm_hidden), nn.Tanh(), nn.Linear(c.lstm_hidden, 3))

    def target(self, seq):
        z = self.embed(seq)
        with torch.backends.cudnn.flags(enabled=False):
            z, _ = self.lstm(z)
        o = self.head(z[:, -1, :])
        return (o[:, 0:1], o[:, 1:2], o[:, 2:3])

def build_model(c):
    if c.model_name == 'PINN':
        return FFPINN(2, c.pinn_hidden, c.pinn_layers)
    if c.model_name == 'Param-PINN':
        return FFPINN(2, c.param_hidden, c.param_layers)
    if c.model_name == 'S-LSTM-PINN':
        return SpatialLSTM(c)
    raise ValueError(c.model_name)

def predict_targets(c, m, x, y, seq=None):
    return m.target(seq) if c.model_name == 'S-LSTM-PINN' else m(x, y)

def grad1(u, x):
    return torch.autograd.grad(u, x, torch.ones_like(u), create_graph=True, retain_graph=True)[0]

def lap2(u, x, y):
    ux = grad1(u, x)
    uy = grad1(u, y)
    return (ux, uy, grad1(ux, x) + grad1(uy, y))

def grad_last(u, seq, k):
    return torch.autograd.grad(u, seq, torch.ones_like(u), create_graph=True, retain_graph=True)[0][:, -1, k:k + 1]

def data_parts(c, m, x, y, seq=None):
    ur, vr, pr = uvp_mms(x, y)
    u, v, p = predict_targets(c, m, x, y, seq)
    sr = torch.sqrt(ur ** 2 + vr ** 2)
    sp = torch.sqrt(u ** 2 + v ** 2)
    d = {'data_u': torch.mean((u - ur) ** 2), 'data_v': torch.mean((v - vr) ** 2), 'data_p': torch.mean((p - pr) ** 2), 'data_speed': torch.mean((sp - sr) ** 2)}
    d['data_total'] = d['data_u'] + d['data_v'] + d['data_p'] + d['data_speed']
    return d

def bc_loss_ff(m, b):
    x, y, ur, vr, pr = b
    u, v, p = m(x, y)
    return torch.mean((u - ur) ** 2) + torch.mean((v - vr) ** 2) + torch.mean((p - pr) ** 2)

def bc_loss_lstm(m, b, seq):
    _, _, ur, vr, pr = b
    u, v, p = m.target(seq)
    return torch.mean((u - ur) ** 2) + torch.mean((v - vr) ** 2) + torch.mean((p - pr) ** 2)

def batch_losses_ff(c, m, col, bc_bottom, bc_top, bc_left, bc_right):
    x0, y0 = col
    x = x0.detach().clone().requires_grad_(True)
    y = y0.detach().clone().requires_grad_(True)
    u, v, p = m(x, y)
    ux, uy, lu = lap2(u, x, y)
    vx, vy, lv = lap2(v, x, y)
    px, py = (grad1(p, x), grad1(p, y))
    fu, fv = forcing_mms(x0, y0, c.nu)
    ru = u * ux + v * uy + px - c.nu * lu - fu
    rv = u * vx + v * vy + py - c.nu * lv - fv
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    ld = torch.mean((ux + vy) ** 2)
    lb = bc_loss_ff(m, bc_bottom) + bc_loss_ff(m, bc_top) + bc_loss_ff(m, bc_left) + bc_loss_ff(m, bc_right)
    dp = data_parts(c, m, x0, y0)
    total = c.w_mom * lm + c.w_div * ld + c.w_bc * lb
    z = torch.zeros((), device=x0.device, dtype=x0.dtype)
    return (total, {'pde': lm + ld, 'mom': lm, 'div': ld, 'ic': z, 'bc': lb, 'data': dp['data_total'], 'data_u': dp['data_u'], 'data_v': dp['data_v'], 'data_p': dp['data_p'], 'data_speed': dp['data_speed']})

def batch_losses_lstm(c, m, col, col_seq, bc_bottom, seq_bottom, bc_top, seq_top, bc_left, seq_left, bc_right, seq_right):
    x0, y0 = col
    seq = col_seq.detach().clone().requires_grad_(True)
    u, v, p = m.target(seq)
    ux, uy = (grad_last(u, seq, 0), grad_last(u, seq, 1))
    vx, vy = (grad_last(v, seq, 0), grad_last(v, seq, 1))
    px, py = (grad_last(p, seq, 0), grad_last(p, seq, 1))
    uxx, uyy = (grad_last(ux, seq, 0), grad_last(uy, seq, 1))
    vxx, vyy = (grad_last(vx, seq, 0), grad_last(vy, seq, 1))
    fu, fv = forcing_mms(x0, y0, c.nu)
    ru = u * ux + v * uy + px - c.nu * (uxx + uyy) - fu
    rv = u * vx + v * vy + py - c.nu * (vxx + vyy) - fv
    lm = torch.mean(ru ** 2) + torch.mean(rv ** 2)
    ld = torch.mean((ux + vy) ** 2)
    lb = bc_loss_lstm(m, bc_bottom, seq_bottom) + bc_loss_lstm(m, bc_top, seq_top) + bc_loss_lstm(m, bc_left, seq_left) + bc_loss_lstm(m, bc_right, seq_right)
    dp = data_parts(c, m, x0, y0, col_seq)
    total = c.w_mom * lm + c.w_div * ld + c.w_bc * lb
    z = torch.zeros((), device=x0.device, dtype=x0.dtype)
    return (total, {'pde': lm + ld, 'mom': lm, 'div': ld, 'ic': z, 'bc': lb, 'data': dp['data_total'], 'data_u': dp['data_u'], 'data_v': dp['data_v'], 'data_p': dp['data_p'], 'data_speed': dp['data_speed']})

@torch.no_grad()
def evaluate_val(c, m, d):
    idx = d['val_metric_idx']
    x, y = d['col_va']
    x, y = (x[idx], y[idx])
    seq = d['col_seq_va'][idx] if c.model_name == 'S-LSTM-PINN' else None
    ur, vr, pr = uvp_mms(x, y)
    u, v, p = predict_targets(c, m, x, y, seq)
    return metrics_torch(torch.cat([u, v, p, torch.sqrt(u ** 2 + v ** 2)], 1), torch.cat([ur, vr, pr, torch.sqrt(ur ** 2 + vr ** 2)], 1))

@torch.no_grad()
def eval_grid(c, m):
    xs = torch.linspace(c.x0, c.x1, c.eval_nx, device=c.device, dtype=c.dtype)
    ys = torch.linspace(c.y0, c.y1, c.eval_ny, device=c.device, dtype=c.dtype)
    X, Y = torch.meshgrid(xs, ys, indexing='ij')
    x = X.reshape(-1, 1)
    y = Y.reshape(-1, 1)
    seq = build_spatial_contexts(x, y, c.sequence_length) if c.model_name == 'S-LSTM-PINN' else None
    ur, vr, pr = uvp_mms(x, y)
    u, v, p = predict_targets(c, m, x, y, seq)
    sr = torch.sqrt(ur ** 2 + vr ** 2)
    sp = torch.sqrt(u ** 2 + v ** 2)
    g = {'x': xs.cpu().numpy(), 'y': ys.cpu().numpy(), 'u_ref': ur.view(c.eval_nx, c.eval_ny).cpu().numpy(), 'v_ref': vr.view(c.eval_nx, c.eval_ny).cpu().numpy(), 'p_ref': pr.view(c.eval_nx, c.eval_ny).cpu().numpy(), 'speed_ref': sr.view(c.eval_nx, c.eval_ny).cpu().numpy(), 'u_pred': u.view(c.eval_nx, c.eval_ny).cpu().numpy(), 'v_pred': v.view(c.eval_nx, c.eval_ny).cpu().numpy(), 'p_pred': p.view(c.eval_nx, c.eval_ny).cpu().numpy(), 'speed_pred': sp.view(c.eval_nx, c.eval_ny).cpu().numpy()}
    for f in ('u', 'v', 'p', 'speed'):
        g[f + '_err'] = g[f + '_pred'] - g[f + '_ref']
    return g

def make_dirs(c):
    for s in ('', 'field_data/steady', 'metrics', 'cost', 'loss', 'figures/reference', 'figures/prediction', 'figures/error', 'figures/loss', 'config'):
        ensure_dir(os.path.join(c.out_dir, s))

def save_model_info(c, m):
    with open(os.path.join(c.out_dir, 'model_info.txt'), 'w', encoding='utf-8') as f:
        for k, v in [('Case', c.case_name), ('Model', c.model_name), ('Data seed', c.data_seed), ('Model seed', c.model_seed), ('Trainable parameters', count_trainable_parameters(m)), ('Total parameters', count_total_parameters(m)), ('Parameter size MB', f'{parameter_size_mb(m):.6f}'), ('Optimizer', 'Adam'), ('Learning rate', c.lr), ('Iterations', c.iters), ('Batch collocation', c.batch_col), ('Batch BC', c.batch_bc), ('Sequence length', c.sequence_length if c.model_name == 'S-LSTM-PINN' else 1)]:
            f.write(f'{k}: {v}\n')

def save_field_data(c, g):
    xx, yy = np.meshgrid(g['x'], g['y'], indexing='ij')
    od = os.path.join(c.out_dir, 'field_data', 'steady')
    for f in ('u', 'v', 'p', 'speed'):
        pred, ref = (g[f + '_pred'], g[f + '_ref'])
        e = pred - ref
        arr = np.column_stack([xx.ravel(), yy.ravel(), pred.ravel(), ref.ravel(), e.ravel(), np.abs(e).ravel()])
        np.savetxt(os.path.join(od, f'{f}_field_data.txt'), arr, fmt='%.10e', delimiter='\t', header='x\ty\tPrediction\tReference\tError\tAbsError', comments='')

def save_metrics(c, g):
    rows = []
    ap = []
    ar = []
    for f in ('u', 'v', 'p', 'speed'):
        pred, ref = (g[f + '_pred'], g[f + '_ref'])
        mm = metrics_np(pred, ref)
        rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'time': 'steady', 'field': f, **mm})
        ap.append(pred.ravel())
        ar.append(ref.ravel())
    write_csv(os.path.join(c.out_dir, 'metrics', 'field_metrics.csv'), rows)
    mm = metrics_np(np.concatenate(ap), np.concatenate(ar))
    write_csv(os.path.join(c.out_dir, 'metrics', 'overall_metrics.csv'), [{'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, **mm}])
    return mm

def save_plots(c, g, h):
    if not c.write_plots:
        return
    extent = [0, 1, 0, 1]
    for f in ('u', 'v', 'p', 'speed'):
        for folder, key, title in (('reference', f + '_ref', 'Reference'), ('prediction', f + '_pred', 'Prediction'), ('error', f + '_err', 'Absolute error')):
            a = np.abs(g[key]) if folder == 'error' else g[key]
            plt.figure(figsize=(5.6, 4.6))
            plt.imshow(a.T, origin='lower', extent=extent, aspect='auto')
            plt.colorbar()
            plt.xlabel('x')
            plt.ylabel('y')
            plt.title(f'{title} {f}')
            plt.tight_layout()
            plt.savefig(os.path.join(c.out_dir, 'figures', folder, f'{f}_{folder}.png'), dpi=220)
            plt.close()
    midx = c.eval_nx // 2
    midy = c.eval_ny // 2
    plt.figure(figsize=(7, 4))
    plt.plot(g['y'], g['u_ref'][midx, :], label='u reference @ x=0.5')
    plt.plot(g['y'], g['u_pred'][midx, :], '--', label='u prediction @ x=0.5')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(c.out_dir, 'figures', 'prediction', 'centerline_u.png'), dpi=220)
    plt.close()
    plt.figure(figsize=(7, 4))
    plt.plot(g['x'], g['v_ref'][:, midy], label='v reference @ y=0.5')
    plt.plot(g['x'], g['v_pred'][:, midy], '--', label='v prediction @ y=0.5')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(c.out_dir, 'figures', 'prediction', 'centerline_v.png'), dpi=220)
    plt.close()
    pairs = [('loss_total_train', 'loss_total_val', 'total'), ('loss_pde_train', 'loss_pde_val', 'pde'), ('loss_mom_train', 'loss_mom_val', 'mom'), ('loss_div_train', 'loss_div_val', 'div'), ('loss_bc_train', 'loss_bc_val', 'bc'), ('loss_data_train', 'loss_data_val', 'data'), ('RelL2_val', None, 'rel_l2')]
    for tr, va, n in pairs:
        plt.figure(figsize=(7, 4))
        plt.plot(h['iter'], h[tr], label=tr)
        if va:
            plt.plot(h['iter'], h[va], label=va)
        plt.yscale('log')
        plt.xlabel('iteration')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(c.out_dir, 'figures', 'loss', f'{n}_curve.png'), dpi=220)
        plt.close()

def save_cost(c, m, h, itimes, total, best_it, best_rel, final_rel):
    hw = hardware_info(c.device)
    pa, pr = peak_gpu(c.device)
    row = {'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'trainable_parameters': count_trainable_parameters(m), 'total_parameters': count_total_parameters(m), 'parameter_size_MB': parameter_size_mb(m), 'total_iterations_configured': c.iters, 'total_iterations_completed': h['iter'][-1], 'total_wall_time_sec': total, 'total_wall_time_min': total / 60, 'mean_time_per_iter_sec': float(np.mean(itimes)), 'median_time_per_iter_sec': float(np.median(itimes)), 'peak_gpu_memory_allocated_MB': pa, 'peak_gpu_memory_reserved_MB': pr, 'best_iter': best_it, 'best_RelL2': best_rel, 'final_RelL2': final_rel, **hw}
    write_csv(os.path.join(c.out_dir, 'cost', 'model_cost_summary.csv'), [row])
    rows = []
    for th in c.rel_l2_thresholds:
        hit = next(((it, r, t) for it, r, t in zip(h['iter'], h['RelL2_val'], h['time_elapsed_sec']) if r <= th), None)
        rows.append({'case': c.case_name, 'model': c.model_name, 'data_seed': c.data_seed, 'model_seed': c.model_seed, 'metric': 'RelL2', 'threshold': th, 'reached': hit is not None, 'iter_to_threshold': -1 if hit is None else hit[0], 'time_to_threshold_sec': -1 if hit is None else hit[2]})
    write_csv(os.path.join(c.out_dir, 'cost', 'threshold_cost.csv'), rows)

def init_history():
    keys = ['iter', 'loss_total_train', 'loss_total_val', 'loss_pde_train', 'loss_pde_val', 'loss_mom_train', 'loss_mom_val', 'loss_div_train', 'loss_div_val', 'loss_ic_train', 'loss_ic_val', 'loss_bc_train', 'loss_bc_val', 'loss_data_train', 'loss_data_val', 'loss_data_u_train', 'loss_data_u_val', 'loss_data_v_train', 'loss_data_v_val', 'loss_data_p_train', 'loss_data_p_val', 'loss_data_speed_train', 'loss_data_speed_val', 'MSE_val', 'RMSE_val', 'MAE_val', 'L2_val', 'RelL2_val', 'MaxAbsError_val', 'MeanAbsError_val', 'time_elapsed_sec']
    return {k: [] for k in keys}

def append_history(h, row):
    for k in h:
        h[k].append(row.get(k, 0.0))

def prepare_batch(c, d, split, it):
    s = c.data_seed
    col_key = 'col_' + split
    ci = minibatch_indices(d[col_key][0].shape[0], c.batch_col if split == 'tr' else c.val_batch_col, s + (100000 if split == 'tr' else 500000) + it, c.device)
    col = select_bundle(d[col_key], ci)
    colseq = d['col_seq_' + split][ci]
    bcs = []
    seqs = []
    base = 200000 if split == 'tr' else 600000
    for j, kind in enumerate(('bottom', 'top', 'left', 'right')):
        key = kind + '_' + split
        bi = minibatch_indices(d[key][0].shape[0], c.batch_bc if split == 'tr' else c.val_batch_bc, s + base + j * 100000 + it, c.device)
        bcs.append(select_bundle(d[key], bi))
        seqs.append(d[kind + '_seq_' + split][bi])
    return (col, colseq, bcs, seqs)

def compute_batch(c, m, col, colseq, bcs, seqs):
    if c.model_name == 'S-LSTM-PINN':
        return batch_losses_lstm(c, m, col, colseq, bcs[0], seqs[0], bcs[1], seqs[1], bcs[2], seqs[2], bcs[3], seqs[3])
    return batch_losses_ff(c, m, col, bcs[0], bcs[1], bcs[2], bcs[3])

def train(c=Config()):
    make_dirs(c)
    d = build_dataset(c)
    set_seed(c.model_seed)
    m = build_model(c).to(c.device, c.dtype)
    opt = torch.optim.Adam(m.parameters(), lr=c.lr)
    if torch.cuda.is_available() and c.device.startswith('cuda'):
        torch.cuda.reset_peak_memory_stats()
    save_model_info(c, m)
    with open(os.path.join(c.out_dir, 'config', 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(asdict(c), f, indent=2, default=str)
    with open(os.path.join(c.out_dir, 'config', 'environment.json'), 'w', encoding='utf-8') as f:
        json.dump(hardware_info(c.device), f, indent=2, default=str)
    h = init_history()
    itimes = []
    best = float('inf')
    best_it = -1
    t0 = time.time()
    print(f'[INFO] {c.case_name} | {c.model_name} | data_seed={c.data_seed} model_seed={c.model_seed}')
    print(f'[INFO] params={count_trainable_parameters(m):,} | output={os.path.abspath(c.out_dir)}')
    for it in range(1, c.iters + 1):
        ts = time.time()
        m.train()
        opt.zero_grad(set_to_none=True)
        col, colseq, bcs, seqs = prepare_batch(c, d, 'tr', it)
        loss, p = compute_batch(c, m, col, colseq, bcs, seqs)
        if not torch.isfinite(loss):
            raise RuntimeError(f'Non-finite loss at {it}')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), c.grad_clip)
        opt.step()
        itimes.append(time.time() - ts)
        if it == 1 or it % c.eval_every == 0:
            m.eval()
            cv, csv, bv, sv = prepare_batch(c, d, 'va', it)
            lv, pv = compute_batch(c, m, cv, csv, bv, sv)
            vm = evaluate_val(c, m, d)
            elapsed = time.time() - t0
            z = 0.0
            row = {'iter': it, 'loss_total_train': float(loss.item()), 'loss_total_val': float(lv.item()), 'loss_pde_train': float(p['pde'].item()), 'loss_pde_val': float(pv['pde'].item()), 'loss_mom_train': float(p['mom'].item()), 'loss_mom_val': float(pv['mom'].item()), 'loss_div_train': float(p['div'].item()), 'loss_div_val': float(pv['div'].item()), 'loss_ic_train': z, 'loss_ic_val': z, 'loss_bc_train': float(p['bc'].item()), 'loss_bc_val': float(pv['bc'].item()), 'loss_data_train': float(p['data'].item()), 'loss_data_val': float(pv['data'].item()), 'loss_data_u_train': float(p['data_u'].item()), 'loss_data_u_val': float(pv['data_u'].item()), 'loss_data_v_train': float(p['data_v'].item()), 'loss_data_v_val': float(pv['data_v'].item()), 'loss_data_p_train': float(p['data_p'].item()), 'loss_data_p_val': float(pv['data_p'].item()), 'loss_data_speed_train': float(p['data_speed'].item()), 'loss_data_speed_val': float(pv['data_speed'].item()), **{k + '_val': v for k, v in vm.items()}, 'time_elapsed_sec': elapsed}
            append_history(h, row)
            write_history(os.path.join(c.out_dir, 'loss', 'train_history.csv'), h)
            if vm['RelL2'] < best:
                best = vm['RelL2']
                best_it = it
                torch.save({'iter': it, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'best_rel_l2': best, 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'best_model.pt'))
            print(f"[{it:06d}] loss={loss.item():.3e} val={lv.item():.3e} RelL2={vm['RelL2']:.3e} elapsed={elapsed / 60:.1f} min")
    total = time.time() - t0
    torch.save({'iter': c.iters, 'model_state_dict': m.state_dict(), 'optimizer_state_dict': opt.state_dict(), 'final_rel_l2_val': h['RelL2_val'][-1], 'config': asdict(c), 'data_seed': c.data_seed, 'model_seed': c.model_seed}, os.path.join(c.out_dir, 'final_model.pt'))
    m.eval()
    g = eval_grid(c, m)
    np.savez(os.path.join(c.out_dir, 'grid.npz'), **g)
    save_field_data(c, g)
    overall = save_metrics(c, g)
    save_plots(c, g, h)
    save_cost(c, m, h, itimes, total, best_it, best, overall['RelL2'])
    print(f"[DONE] {c.model_name} seed={c.model_seed} best={best:.6e} final_grid={overall['RelL2']:.6e}")
    return (m, h)
