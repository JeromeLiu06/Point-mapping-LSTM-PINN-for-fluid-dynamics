import argparse
import importlib
import os
from dataclasses import fields
from pathlib import Path
import torch
EXPERIMENT = 'D'
CASES = ('case1_tgv', 'case2_cavity', 'case3_rbc', 'case4_cavity')

def main(argv=None):
    parser = argparse.ArgumentParser(description=f'Experiment {EXPERIMENT} training')
    parser.add_argument('--case', type=int, choices=range(1, 5), required=True)
    parser.add_argument('--model', choices=('S-LSTM-PINN', 'Param-PINN', 'PINN'), required=True)
    parser.add_argument('--seed', type=int, choices=(0, 1, 2), required=True)
    parser.add_argument('--device', choices=('cpu', 'cuda'), default='cuda' if torch.cuda.is_available() else 'cpu')
    parser.add_argument('--output', type=Path, help='Destination for this run')
    parser.add_argument('--smoke', action='store_true', help='Run two updates with reduced batches and grid.')
    parser.add_argument('--plots', action='store_true', help='Also render figures during a smoke test.')
    args = parser.parse_args(argv)
    case = CASES[args.case - 1]
    module_name = case
    model, seed, length = (args.model, args.seed, 4)
    group = Path(model) / f'seed_{seed}'
    os.environ.setdefault('MPLBACKEND', 'Agg')
    engine = importlib.import_module('cases.' + module_name)
    cfg = engine.Config()
    cfg.model_name, cfg.model_seed, cfg.sequence_length = (model, seed, length)
    cfg.device = args.device
    cfg.write_plots = args.plots or not args.smoke
    if args.smoke:
        cfg.iters, cfg.eval_every, cfg.val_metric_points = (2, 1, 32)
        for f in fields(cfg):
            if f.name.startswith(('batch_', 'val_batch_')):
                setattr(cfg, f.name, min(getattr(cfg, f.name), 16))
            elif f.name in ('eval_nx', 'eval_ny', 'nx_eval', 'ny_eval'):
                setattr(cfg, f.name, 16)
    out = args.output or Path('runs') / ('smoke' if args.smoke else 'training') / case / group
    if out.is_dir() and any(out.iterdir()):
        parser.error(f'Choose a new or empty output directory: {out}')
    out.mkdir(parents=True, exist_ok=True)
    cfg.out_dir = str(out)
    if cfg.device == 'cpu':
        torch.set_num_threads(min(4, torch.get_num_threads()))
        torch.backends.mkldnn.enabled = False
    return engine.train(cfg)
if __name__ == '__main__':
    main()
