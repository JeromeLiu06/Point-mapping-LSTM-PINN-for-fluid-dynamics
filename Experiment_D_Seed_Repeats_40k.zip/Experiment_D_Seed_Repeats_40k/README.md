# Experiment D — model initialization

Train S-LSTM-PINN, Param-PINN and PINN on each of four cases for 40,000
updates with model seeds 0, 1 and 2 (36 configurations). Data and batch
sampling use base seed 0. S-LSTM-PINN uses a four-point window and two
recurrent layers of width 192. The two feedforward controls have widths
280 and 128 and nine and eight hidden layers, respectively. All runs use Adam
with a learning rate of 0.0001.

```sh
python train.py --case 1 --model S-LSTM-PINN --seed 0
python train.py --case 4 --model Param-PINN --seed 2 --smoke
```

Cases I–IV are the manufactured Taylor–Green vortex, manufactured steady cavity,
manufactured Rayleigh–Bénard convection and conventional lid-driven cavity at
Re = 100. Install Python 3.8+ with NumPy, PyTorch and Matplotlib. The
tested environment used Python 3.8.20, PyTorch 2.2.2 and CUDA 12.1.

Case IV includes the N=256 FEM v4 reference in `data/`. Evaluation samples
u, v and p by bilinear interpolation using the stored [y,x] layout. The grid
export includes raw and constant-aligned pressure. The reference enters
evaluation only. `metrics/case4_velocity.json` gives both the componentwise
mean relative L2 and the joint velocity-vector relative L2. Pressure RMSE is
reported separately. Field arrays, training history and the final checkpoint
are written under `runs/` or the directory supplied with `--output`.

Append `--smoke` for two optimizer updates, validation and field export with
reduced batches and a 16 × 16 evaluation grid. Model width and depth are
preserved. Add `--plots` to include figures during a smoke run.
