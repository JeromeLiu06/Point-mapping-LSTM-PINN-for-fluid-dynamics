import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from epjplus_bc.__main__ import main as train_cli
from epjplus_bc.data import cavity_data
from epjplus_bc.models import build_model
from epjplus_bc.physics import cavity_target, pde_loss, reference_fields
from epjplus_bc.protocol import FEM_SHA, MODELS, SIDES, get_protocol


def run(protocol, output, args, steps=2, batch=8, resume=None):
    command = ["smoke", protocol.experiment, "--case", str(protocol.case),
               "--model", protocol.model, "--steps", str(steps), "--device", args.device,
               "--output", str(output)]
    if batch:
        command.extend(("--smoke-batch", str(batch)))
    if protocol.experiment == "C" and args.dataset_dir is not None:
        command.extend(("--dataset-dir", str(args.dataset_dir)))
    if protocol.case == 4:
        command.extend(("--fem-reference", str(args.fem_reference)))
    if resume:
        command.extend(("--resume", str(resume)))
    with patch.object(sys, "argv", command):
        train_cli()
    checkpoint = torch.load(output / "checkpoint.pt", map_location="cpu", weights_only=True)
    assert checkpoint["iteration"] == steps
    assert all(int(state["step"]) == steps for state in checkpoint["optimizer"]["state"].values())
    initial = build_model(protocol).state_dict()
    assert any(not torch.equal(initial[key], value) for key, value in checkpoint["model"].items())
    assert all(torch.isfinite(value).all() for value in checkpoint["model"].values())
    with (output / "history.csv").open(newline="", encoding="utf-8") as stream:
        history = list(csv.DictReader(stream))
    assert int(history[-1]["iteration"]) == steps
    assert all(np.isfinite(float(value)) for row in history for value in row.values())
    with np.load(output / "predictions.npz", allow_pickle=False) as arrays:
        expected_rows = 14400 if protocol.experiment == "B" else {1: 19200, 2: 14400, 3: 72000, 4: 16641}[protocol.case]
        names = arrays["fields"].tolist()
        assert len(arrays["coordinates"]) == expected_rows
        assert arrays["reference"].shape == arrays["prediction"].shape == (expected_rows, len(names))
        assert np.isfinite(arrays["reference"]).all() and np.isfinite(arrays["prediction"]).all()
        if protocol.case == 4:
            assert names == ["u", "v", "speed"]
            assert arrays["fem_reference_sha256"].item() == FEM_SHA
            with np.load(args.fem_reference, allow_pickle=False) as fem:
                xy = arrays["coordinates"][:, :2].astype(np.float64)
                sample = xy * 512
                ij = np.minimum(sample.astype(int), 511)
                wx, wy = (sample - ij).T
                ix, iy = ij.T
                for channel, field in enumerate(("u", "v")):
                    z = fem[field]
                    expected = ((1-wx)*(1-wy)*z[iy, ix] + wx*(1-wy)*z[iy, ix+1]
                                + (1-wx)*wy*z[iy+1, ix] + wx*wy*z[iy+1, ix+1])
                    np.testing.assert_allclose(arrays["reference"][:, channel], expected, rtol=0, atol=3e-16)
    result = {"experiment": protocol.experiment, "case": protocol.case, "model": protocol.model,
              "parameters": protocol.parameters, "steps": steps, "batch_override": batch,
              "train_loss": float(history[-1]["train_total"]), "validation_loss": float(history[-1]["val_total"]),
              "evaluation_points": expected_rows, "fields": names, "status": "PASS"}
    print(json.dumps(result), flush=True)
    return result


def cavity_fingerprint(device):
    protocol = get_protocol("B", 4, "lstm1")
    data = cavity_data(protocol, torch.device(device))
    digest = hashlib.sha256()
    for group in ("col", *SIDES):
        for split, suffix in (("train", "tr"), ("val", "va")):
            z = data[f"{group}_{split}"][:, -1]
            fields = z[:, :2]
            if group != "col":
                fields = torch.cat((fields, cavity_target(z, group)), dim=-1)
            digest.update(f"{group}_{suffix}".encode())
            for field in fields.split(1, dim=-1):
                array = field.cpu().contiguous().numpy()
                digest.update(str(array.shape).encode("ascii"))
                digest.update(str(array.dtype).encode("ascii"))
                digest.update(array.tobytes())
    return digest.hexdigest()


def check_physics():
    for case in (1, 2, 3):
        protocol = get_protocol("C", case, "param")
        z = torch.rand(2, 4, 3, dtype=torch.float64)
        momentum, divergence = pde_loss(lambda x: reference_fields(x, case), z, protocol)
        assert float(momentum) < 1e-24 and float(divergence) < 1e-24
    z = torch.rand(2, 4, 3).requires_grad_(True)
    for model in ("lstm1", "lstm2", "rnn"):
        network = build_model(get_protocol("C", 1, model))
        last = network(z)[:, -1].sum()
        earlier_grad = torch.autograd.grad(last, z)[0][:, :-1].abs().max()
        assert (float(earlier_grad) == 0.0) == (model == "lstm1")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-dir", type=Path)
    parser.add_argument("--fem-reference", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--check-default-batches", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(min(torch.get_num_threads(), 4))
    torch.backends.mkldnn.enabled = False
    check_physics()
    args.output.mkdir(parents=True, exist_ok=False)
    results = []
    for experiment, cases in (("B", (4,)), ("C", (1, 2, 3, 4))):
        for case in cases:
            for model in MODELS[experiment]:
                protocol = get_protocol(experiment, case, model)
                results.append(run(protocol, args.output / f"{experiment}_{case}_{model}", args))
    protocol = get_protocol("C", 3, "lstm2")
    folder = args.output / "C_3_lstm2"
    first, resumed = args.output / "resume_first", args.output / "resume_second"
    run(protocol, first, args, steps=1)
    run(protocol, resumed, args, resume=first / "checkpoint.pt")
    original = torch.load(folder / "checkpoint.pt", map_location="cpu", weights_only=True)
    resumed_state = torch.load(resumed / "checkpoint.pt", map_location="cpu", weights_only=True)
    assert all(torch.equal(tensor, resumed_state["model"][key]) for key, tensor in original["model"].items())
    assert torch.equal(original["sampling_rng"], resumed_state["sampling_rng"])
    default_batches = []
    if args.check_default_batches:
        for result in results:
            protocol = get_protocol(result["experiment"], result["case"], result["model"])
            name = f"full_batch_{protocol.experiment}_{protocol.case}_{protocol.model}"
            default_batches.append(run(protocol, args.output / name, args, batch=None))
    summary = {
        "python": sys.version.split()[0], "torch": str(torch.__version__), "device": args.device,
        "gpu": torch.cuda.get_device_name(torch.device(args.device)) if args.device.startswith("cuda") else None,
        "results": results, "default_batches": default_batches, "rbc_resume_bitwise_equal": True,
        "manufactured_residual_and_state_dependency": "PASS",
        "b_data_fingerprint": cavity_fingerprint(args.device),
    }
    (args.output / "smoke_results.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
