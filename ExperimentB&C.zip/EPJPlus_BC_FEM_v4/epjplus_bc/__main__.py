import argparse
from pathlib import Path

import torch

from .protocol import get_protocol
from .train import train


def main():
    parser = argparse.ArgumentParser(description="EPJPlus Experiment B/C training")
    parser.add_argument("experiment", choices=("B", "C"))
    parser.add_argument("--case", type=int, required=True, choices=(1, 2, 3, 4))
    parser.add_argument("--model", required=True, choices=("pinn", "param", "rnn", "lstm1", "lstm2"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--dataset-dir", type=Path)
    parser.add_argument("--fem-reference", type=Path)
    parser.add_argument("--steps", type=int)
    parser.add_argument("--smoke-batch", type=int)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    try:
        protocol = get_protocol(args.experiment, args.case, args.model)
    except ValueError as exc:
        parser.error(str(exc))
    if args.smoke_batch is not None and args.steps is None:
        parser.error("--smoke-batch requires an explicit --steps")
    device = torch.device(("cuda" if torch.cuda.is_available() else "cpu")
                          if args.device == "auto" else args.device)
    if device.type == "cpu":
        torch.set_num_threads(min(torch.get_num_threads(), 4))
        torch.backends.mkldnn.enabled = False
    train(protocol, args.output, device, protocol.steps if args.steps is None else args.steps,
          args.smoke_batch, args.dataset_dir, args.fem_reference, args.resume)


if __name__ == "__main__":
    main()
