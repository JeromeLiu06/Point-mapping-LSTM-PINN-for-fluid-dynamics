import torch
from torch import nn


class PointMLP(nn.Module):
    def __init__(self, protocol):
        super().__init__()
        self.input_dim = protocol.input_dim
        width = protocol.width
        layers = [nn.Linear(self.input_dim, width), nn.Tanh()]
        for _ in range(protocol.layers - 1):
            layers.extend((nn.Linear(width, width), nn.Tanh()))
        layers.append(nn.Linear(width, protocol.physical.output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, coordinates):
        return self.net(coordinates[..., :self.input_dim])


class RecurrentPINN(nn.Module):
    def __init__(self, protocol):
        super().__init__()
        width = protocol.width
        self.reset = protocol.model == "lstm1"
        self.embed = nn.Linear(3, width)
        cell = nn.RNN if protocol.model == "rnn" else nn.LSTM
        self.core = cell(width, width, protocol.layers, batch_first=True)
        self.head = nn.Sequential(nn.Linear(width, width), nn.Tanh(),
                                  nn.Linear(width, protocol.physical.output_dim))

    def forward(self, coordinates):
        embedded = self.embed(coordinates)
        with torch.backends.cudnn.flags(enabled=False):
            if self.reset and embedded.shape[1] > 1:
                result = torch.cat([self.core(token)[0] for token in embedded.split(1, dim=1)], dim=1)
            else:
                result, _ = self.core(embedded)
        return self.head(result)


def build_model(protocol):
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(protocol.model_seed)
        model = (PointMLP(protocol) if protocol.model in ("pinn", "param")
                 else RecurrentPINN(protocol))
    assert sum(p.numel() for p in model.parameters()) == protocol.parameters
    return model
