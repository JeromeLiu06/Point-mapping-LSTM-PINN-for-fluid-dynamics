import math

import torch

from .protocol import SIDES


def reference_fields(coordinates, case):
    x, y, t = coordinates.unbind(dim=-1)
    if case == 1:
        decay = torch.exp(-t)
        u = decay * torch.sin(x) * torch.cos(y)
        v = -decay * torch.cos(x) * torch.sin(y)
        p = 0.25 * (torch.cos(2 * x) + torch.cos(2 * y)) * decay.square()
        return torch.stack((u, v, p), dim=-1)
    if case == 2:
        f = x**2 - 2 * x**3 + x**4
        g = y**3 - y**2
        u = f * (3 * y**2 - 2 * y)
        v = -(2 * x - 6 * x**2 + 4 * x**3) * g
        return torch.stack((u, v, x * (1 - x) * y * (1 - y)), dim=-1)
    if case == 3:
        sx, sy = torch.sin(math.pi * x), torch.sin(math.pi * y)
        cx, cy = torch.cos(math.pi * x), torch.cos(math.pi * y)
        st, ct = torch.sin(math.pi * t), torch.cos(math.pi * t)
        u = 2 * math.pi * sx.square() * sy * cy * st
        v = -2 * math.pi * sx * cx * sy.square() * st
        return torch.stack((u, v, 0.1 * cx * cy * ct, sx * sy * ct), dim=-1)
    raise ValueError("Case IV uses an independent FEM reference")


def gradient(value, coordinates):
    return torch.autograd.grad(value.sum(), coordinates, create_graph=True, retain_graph=True)[0]


def residuals(fields, differentiate, protocol):
    u, v, pressure, *thermal = fields.unbind(dim=-1)
    du, dv, dp = (differentiate(field) for field in (u, v, pressure))

    def advection(derivatives):
        return u * derivatives[..., 0] + v * derivatives[..., 1]

    def laplacian(derivatives):
        return sum(differentiate(derivatives[..., axis])[..., axis] for axis in (0, 1))

    viscosity = protocol.physical.viscosity
    ru = advection(du) + dp[..., 0] - viscosity * laplacian(du)
    rv = advection(dv) + dp[..., 1] - viscosity * laplacian(dv)
    if protocol.case in (1, 3):
        ru = ru + du[..., 2]
        rv = rv + dv[..., 2]
    parts = [ru, rv]
    if thermal:
        theta = thermal[0]
        dt = differentiate(theta)
        parts[1] = rv - protocol.physical.buoyancy * theta
        parts.append(dt[..., 2] + advection(dt) - protocol.physical.diffusivity * laplacian(dt))
    return torch.stack(parts, dim=-1), du[..., 0] + dv[..., 1]


def pde_loss(model, coordinates, protocol):
    z = coordinates.detach().requires_grad_(True)
    fields = model(z)
    if protocol.case == 4:
        force = 0.0
    else:
        reference_points = coordinates.detach().requires_grad_(True)
        force, _ = residuals(reference_fields(reference_points, protocol.case),
                             lambda f: gradient(f, reference_points), protocol)
        force = force.detach()

    if protocol.model in ("pinn", "param", "lstm1"):
        differential, continuity = residuals(fields, lambda f: gradient(f, z), protocol)
    else:
        indices = range(z.shape[1]) if protocol.experiment == "C" else (z.shape[1] - 1,)
        values = [
            residuals(fields[:, token], lambda f: gradient(f, z)[:, token], protocol)
            for token in indices
        ]
        differential = torch.stack([item[0] for item in values], dim=1)
        continuity = torch.stack([item[1] for item in values], dim=1)
    return (differential - force).square().sum(dim=-1).mean(), continuity.square().mean()


def cavity_target(coordinates, side):
    target = torch.zeros_like(coordinates[..., :2])
    if side == "top":
        x = coordinates[..., 0]
        target[..., 0] = (x > 0) & (x < 1)
    return target


def objective(model, draw, protocol):
    momentum, continuity = pde_loss(model, draw("col"), protocol)
    initial = momentum.new_zeros(())
    if protocol.physical.initial:
        z = draw("ic")
        initial = (model(z) - reference_fields(z, protocol.case)).square().mean()

    if protocol.case == 1:
        boundary = momentum.new_zeros(())
        for axis in ("x", "y"):
            a, b = draw(f"bc{axis}0", f"bc{axis}1")
            boundary = boundary + (model(a) - model(b)).square().mean()
    else:
        losses = []
        for side in SIDES:
            z = draw(side)
            predicted = model(z)
            if protocol.case == 4:
                error = (predicted[..., :2] - cavity_target(z, side)).square()
                losses.append(error.sum(dim=-1).mean() if protocol.experiment == "B" else error.mean())
            else:
                losses.append((predicted - reference_fields(z, protocol.case)).square().mean())
        boundary = sum(losses)
    total = (protocol.momentum_weight * momentum + protocol.continuity_weight * continuity
             + protocol.physical.initial_weight * initial + protocol.physical.boundary_weight * boundary)
    return dict(total=total, momentum=momentum, continuity=continuity, initial=initial, boundary=boundary)
