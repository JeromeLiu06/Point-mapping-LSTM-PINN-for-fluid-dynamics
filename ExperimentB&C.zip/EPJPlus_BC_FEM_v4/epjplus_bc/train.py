import csv
import json
from dataclasses import asdict
from time import perf_counter

import numpy as np
import torch

from .data import batch_draw, cavity_data, data_signature, fem_velocity, frozen_data, load_fem_velocity
from .models import build_model
from .physics import objective, reference_fields
from .protocol import FEM_SHA


@torch.no_grad()
def evaluate(model, data, protocol, device, fem_grid):
    windows = data["eval"]
    model.eval()
    predictions = torch.cat([model(chunk.to(device)).cpu() for chunk in windows.split(256)])
    if protocol.experiment == "B" or protocol.case in (1, 3):
        points, predictions = windows[:, -1], predictions[:, -1]
    else:
        count = int(data["eval_count"][0]) if protocol.case == 4 else windows.shape[0] * protocol.tokens
        points = windows.flatten(0, 1)[:count]
        predictions = predictions.flatten(0, 1)[:count]

    coordinates = points.numpy()
    if protocol.case == 4:
        return evaluate_case4(coordinates, predictions[:, :2].numpy(), fem_grid)
    names = ["u", "v", "p"] + (["theta"] if protocol.case == 3 else [])
    return field_metrics(coordinates, predictions.numpy(), reference_fields(points, protocol.case).numpy(), names)


def evaluate_case4(coordinates, predicted, fem_grid):
    reference = fem_velocity(fem_grid, coordinates)
    metrics, arrays = field_metrics(coordinates, predicted.astype(np.float64), reference, ["u", "v"])
    metrics["fem_reference_sha256"] = FEM_SHA
    arrays["fem_reference_sha256"] = np.array(FEM_SHA)
    return metrics, arrays


def field_metrics(coordinates, predicted, reference, names):
    if predicted.shape != reference.shape or not np.isfinite(predicted).all() or not np.isfinite(reference).all():
        raise ValueError("Prediction and reference must be finite arrays with matching shapes")

    def with_speed(values):
        return np.column_stack((values, np.linalg.norm(values[:, :2], axis=1)))

    primitive_count = len(names)
    names = names + ["speed"]
    predicted = with_speed(predicted)
    reference = with_speed(reference)
    error = predicted.astype(np.float64) - reference
    norms = np.linalg.norm(reference.astype(np.float64), axis=0)
    absolute = np.linalg.norm(error, axis=0)
    ratios = [float(a / b) if b > 0 else None for a, b in zip(absolute, norms)]
    primitive = ratios[:primitive_count]
    metrics = {
        "field_relative_l2": dict(zip(names, ratios)),
        "field_rmse": dict(zip(names, np.sqrt(np.mean(error**2, axis=0)).tolist())),
        "mean_primitive_relative_l2": None if None in primitive else sum(primitive) / primitive_count,
    }
    arrays = dict(coordinates=coordinates, fields=np.array(names), prediction=predicted,
                  reference=reference, error=error)
    return metrics, arrays


def train(protocol, output, device, iterations, batch_limit=None,
          dataset_dir=None, fem_reference=None, resume=None):
    if not 1 <= iterations <= protocol.steps:
        raise ValueError(f"Requested steps must be between 1 and {protocol.steps}")
    if batch_limit is not None and (
            batch_limit < protocol.tokens or batch_limit > protocol.val_initial
            or batch_limit % protocol.tokens):
        raise ValueError("Smoke batch must be a positive multiple of the sequence length, at most 256")
    if protocol.case == 4 and fem_reference is None:
        raise ValueError("Case IV requires --fem-reference with the new FEM v4 N=256 velocity file")
    if protocol.case != 4 and fem_reference is not None:
        raise ValueError("--fem-reference applies to Case IV only")
    fem_grid = load_fem_velocity(fem_reference) if fem_reference is not None else None
    if output.exists() and any(output.iterdir()):
        raise ValueError("Use a new empty output directory, including when resuming")
    data = cavity_data(protocol, device) if protocol.experiment == "B" else frozen_data(protocol, dataset_dir)
    model = build_model(protocol).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=protocol.learning_rate)
    sampling_rng = torch.Generator().manual_seed(protocol.sampling_seed)
    start_step, history = 0, []
    data_sha = data_signature(data) if protocol.experiment == "B" else protocol.physical.sha256
    signature = {"protocol": asdict(protocol), "physical": asdict(protocol.physical),
                 "training_data_sha256": data_sha, "smoke_batch": batch_limit}
    if resume is not None:
        state = torch.load(resume, map_location="cpu", weights_only=True)
        if state["signature"] != signature:
            raise ValueError("Checkpoint training protocol, model, dataset or batch size differs")
        start_step = state["iteration"]
        if start_step >= iterations:
            raise ValueError("Target step must exceed the checkpoint step")
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        sampling_rng.set_state(state["sampling_rng"])
        history = state["history"]

    output.mkdir(parents=True, exist_ok=True)
    metadata = dict(signature, target_iterations=iterations, start_step=start_step,
                    device=str(device), torch=str(torch.__version__),
                    fem_reference_sha256=FEM_SHA if fem_reference else None,
                    optimizer="Adam", dtype="float32")
    (output / "config.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    begin = perf_counter()
    for iteration in range(start_step + 1, iterations + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        draw = batch_draw(protocol, data, sampling_rng, "train", iteration, batch_limit)

        def on_device(*groups):
            values = draw(*groups)
            if len(groups) == 1:
                return values.to(device)
            return tuple(value.to(device) for value in values)

        losses = objective(model, on_device, protocol)
        loss = losses["total"]
        if not torch.isfinite(loss):
            raise FloatingPointError(f"Nonfinite objective at step {iteration}")
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), protocol.gradient_clip,
                                                   error_if_nonfinite=True)
        optimizer.step()
        if iteration == 1 or iteration % protocol.eval_every == 0 or iteration == iterations:
            model.eval()
            validation_rng = torch.Generator().manual_seed(protocol.validation_seed)
            draw = batch_draw(protocol, data, validation_rng, "val", iteration, batch_limit)
            validation = objective(model, on_device, protocol)
            row = {"iteration": iteration, "gradient_norm": float(grad_norm), "seconds": perf_counter() - begin}
            row.update({f"train_{k}": float(v.detach()) for k, v in losses.items()})
            row.update({f"val_{k}": float(v.detach()) for k, v in validation.items()})
            del validation
            if not all(np.isfinite(value) for value in row.values()):
                raise FloatingPointError(f"Nonfinite training or validation result at step {iteration}")
            history.append(row)
            state = dict(iteration=iteration, model=model.state_dict(), optimizer=optimizer.state_dict(),
                         sampling_rng=sampling_rng.get_state(), signature=signature, history=history)
            temporary = output / "checkpoint.tmp"
            torch.save(state, temporary)
            temporary.replace(output / "checkpoint.pt")
            print(f"{iteration:>6} train={row['train_total']:.7g} val={row['val_total']:.7g}", flush=True)
        del losses, loss

    metrics, arrays = evaluate(model, data, protocol, device, fem_grid)
    with (output / "history.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2, allow_nan=False), encoding="utf-8")
    np.savez_compressed(output / "predictions.npz", **arrays)
    return history
