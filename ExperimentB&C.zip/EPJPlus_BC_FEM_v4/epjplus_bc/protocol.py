from dataclasses import dataclass


SIDES = ("bottom", "top", "left", "right")
MODELS = {
    "B": ("pinn", "param", "lstm1", "lstm2"),
    "C": ("param", "rnn", "lstm1", "lstm2"),
}
FEM_SHA = "4c3eae0546dbd067dad4501d7cac9abe5aba239b6dfa53a022a96d9851eb265d"


@dataclass(frozen=True)
class Case:
    dataset: str
    sha256: str
    collocation: int
    initial: int
    boundary: int
    viscosity: float
    initial_weight: float
    boundary_weight: float
    output_dim: int = 3
    diffusivity: float = 0.0
    buoyancy: float = 0.0


CASES = {
    1: Case("case1_TGV", "00679415fd67af34afcd02235e6fbbd4c146721578cb0c8b6e3b8e0bd1f2581f",
            20000, 2400, 4800, 0.1, 10.0, 1.0),
    2: Case("case2_Lid", "32921ee4eca4b73e95332ab0b08af02e8707e784b26b6c61c6c237832d11bf96",
            22000, 0, 8800, 0.01, 0.0, 10.0),
    3: Case("case3_RBC", "536a7da0c4fec4d0157a359fd5c1d889befb269a8e2d8f3dfcb44df40d17e577",
            22000, 2400, 7200, 0.01, 10.0, 2.0, 4, 0.01, 1.0),
    4: Case("case4_Lid2", "f92b8898ffc7e977f5ab9294ca8b86377b24d4c767f836661e2410a2db6ab40b",
            22000, 0, 8800, 0.01, 0.0, 10.0),
}


@dataclass(frozen=True)
class Protocol:
    experiment: str
    case: int
    model: str
    steps: int
    tokens: int
    input_dim: int
    width: int
    layers: int
    parameters: int
    data_seed: int = 0
    model_seed: int = 0
    sampling_seed: int = 0
    validation_seed: int = 0
    learning_rate: float = 1e-4
    gradient_clip: float = 1.0
    eval_every: int = 500
    train_col: int = 1024
    train_boundary: int = 256
    train_initial: int = 256
    val_col: int = 512
    val_boundary: int = 256
    val_initial: int = 256
    train_ratio: float = 0.7
    momentum_weight: float = 1.0
    continuity_weight: float = 1.0

    @property
    def physical(self):
        return CASES[self.case]


def get_protocol(experiment, case, model):
    if experiment not in MODELS or model not in MODELS[experiment]:
        raise ValueError(f"Unsupported model {model!r} for Experiment {experiment}")
    if case not in CASES or (experiment == "B" and case != 4):
        raise ValueError(f"Unsupported Case {case} for Experiment {experiment}")
    width, layers = {
        "pinn": (128, 8), "param": (280, 9), "rnn": (354, 2),
        "lstm1": (192, 2), "lstm2": (192, 2),
    }[model]
    steps = 80000 if experiment == "C" or model == "lstm1" else 40000
    tokens = 4 if experiment == "C" or model == "lstm2" else 1
    input_dim = 2 if experiment == "B" and model in ("pinn", "param") else 3
    if experiment == "B":
        parameters = {"pinn": 116355, "param": 631123, "lstm1": 631299, "lstm2": 631299}[model]
    elif case == 3:
        parameters = {"param": 631684, "rnn": 631186, "lstm1": 631492, "lstm2": 631492}[model]
    else:
        parameters = {"param": 631403, "rnn": 630831, "lstm1": 631299, "lstm2": 631299}[model]
    return Protocol(experiment, case, model, steps, tokens, input_dim, width, layers, parameters,
                    model_seed=1 if experiment == "B" else 0)
