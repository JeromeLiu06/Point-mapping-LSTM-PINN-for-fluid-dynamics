import hashlib
from pathlib import Path

import numpy as np
import torch

from .protocol import FEM_SHA, SIDES


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def data_signature(data):
    digest = hashlib.sha256()
    for name, tensor in sorted(data.items()):
        if name == "eval":
            continue
        value = tensor.detach().cpu().contiguous().numpy()
        digest.update(f"{name}:{value.shape}:{value.dtype}".encode("ascii"))
        digest.update(value.tobytes())
    return digest.hexdigest()


def spatial_contexts(points, length, side=None):
    if length == 1:
        return points[:, None]
    if side in SIDES:
        axis = 0 if side in ("bottom", "top") else 1
        order = torch.argsort(points[:, axis])
    else:
        xy = (points[:, :2].cpu().numpy() * 65535).astype(np.uint32)

        def spread(value):
            for shift, mask in ((8, 0x00FF00FF), (4, 0x0F0F0F0F),
                                (2, 0x33333333), (1, 0x55555555)):
                value = (value | (value << shift)) & mask
            return value

        key = spread(xy[:, 0]) | (spread(xy[:, 1]) << 1)
        order = torch.from_numpy(np.argsort(key)).to(points.device)
    rows = torch.arange(len(points), device=points.device)
    offsets = torch.arange(length - 1, -1, -1, device=points.device)
    history = (rows[:, None] - offsets).clamp_min(0)
    sorted_contexts = points[order[history]]
    return sorted_contexts[torch.argsort(order)]


def cavity_data(protocol, device):
    def rng(offset):
        return torch.Generator(device=device).manual_seed(protocol.data_seed + offset)

    def pair(points, offset, side=None):
        order = torch.randperm(len(points), generator=rng(offset), device=device)
        n = int(protocol.train_ratio * len(points))
        return [spatial_contexts(points[indices], protocol.tokens, side)
                for indices in (order[:n], order[n:])]

    n = protocol.physical.collocation
    x = torch.rand(n, generator=rng(11), device=device)
    y = torch.rand(n, generator=rng(12), device=device)
    result = dict(zip(("col_train", "col_val"), pair(torch.stack((x, y, torch.zeros_like(x)), -1), 101)))
    for offset, side in enumerate(SIDES, 201):
        q = torch.rand(protocol.physical.boundary // 4, generator=rng(1000 + offset), device=device)
        zero, one = torch.zeros_like(q), torch.ones_like(q)
        x, y = {"bottom": (q, zero), "top": (q, one), "left": (zero, q), "right": (one, q)}[side]
        points = torch.stack((x, y, zero), dim=-1)
        result[f"{side}_train"], result[f"{side}_val"] = pair(points, offset, side)
    axis = torch.linspace(0.0, 1.0, 120, device=device)
    y, x = torch.meshgrid(axis, axis, indexing="ij")
    points = torch.stack((x.flatten(), y.flatten(), torch.zeros_like(x).flatten()), dim=-1)
    result["eval"] = spatial_contexts(points, protocol.tokens).cpu()
    return result


def frozen_data(protocol, directory):
    if directory is None:
        directory = Path(__file__).resolve().parents[1] / "datasets"
    path = directory / (protocol.physical.dataset + "_dataset_seed0.npz")
    if sha256(path) != protocol.physical.sha256:
        raise ValueError(f"Unexpected SHA-256 for {path}")
    with np.load(path, allow_pickle=False) as archive:
        if "eval_ref" in archive.files:
            raise ValueError(f"Embedded reference is not accepted in {path}")
        arrays = {key: torch.from_numpy(archive[key]) for key in archive.files}
    if not all(torch.isfinite(value).all() for value in arrays.values()):
        raise ValueError(f"Nonfinite input in {path}")
    return arrays


def batch_draw(protocol, data, generator, split, iteration, batch_limit=None):
    def draw(*groups):
        name = groups[0]
        category = {"col": "col", "ic": "initial"}.get(name, "boundary")
        tokens = batch_limit or getattr(protocol, f"{split}_{category}")
        arrays = [data[f"{key}_{split}"] for key in groups]
        if tokens % protocol.tokens:
            raise ValueError("Batch size must be divisible by the sequence length")
        size = tokens // protocol.tokens
        if protocol.experiment == "B":
            base = 100000 if split == "train" else 500000
            if name != "col":
                base += (SIDES.index(name) + 1) * 100000
            device = arrays[0].device
            batch_rng = torch.Generator(device=device).manual_seed(protocol.sampling_seed + base + iteration)
            indices = torch.randperm(len(arrays[0]), generator=batch_rng, device=device)[:size]
        else:
            indices = torch.randint(len(arrays[0]), (size,), generator=generator)
        samples = tuple(value[indices] for value in arrays)
        return samples if len(samples) > 1 else samples[0]

    return draw


def load_fem_velocity(path):
    if sha256(path) != FEM_SHA:
        raise ValueError("Reference SHA-256 mismatch: use levels/N256/velocity_reference_grid.npz from the FEM v4 package")
    with np.load(path, allow_pickle=False) as archive:
        return tuple(archive[key] for key in ("x", "y", "u", "v"))


def fem_velocity(grid, points):
    x, y, u, v = grid
    qx, qy = np.asarray(points[:, :2], dtype=np.float64).T
    if not np.isfinite((qx, qy)).all() or np.any((qx < x[0]) | (qx > x[-1]) | (qy < y[0]) | (qy > y[-1])):
        raise ValueError("FEM evaluation points must be finite and inside [0, 1] × [0, 1]")
    ix = np.searchsorted(x, qx, side="right").clip(1, len(x) - 1)
    iy = np.searchsorted(y, qy, side="right").clip(1, len(y) - 1)
    wx = (qx - x[ix - 1]) / (x[ix] - x[ix - 1])
    wy = (qy - y[iy - 1]) / (y[iy] - y[iy - 1])

    def interpolate(grid):
        lower = (1 - wx) * grid[iy - 1, ix - 1] + wx * grid[iy - 1, ix]
        upper = (1 - wx) * grid[iy, ix - 1] + wx * grid[iy, ix]
        return (1 - wy) * lower + wy * upper

    return np.column_stack((interpolate(u), interpolate(v)))
