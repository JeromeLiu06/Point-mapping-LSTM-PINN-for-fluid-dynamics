import argparse
import json
from pathlib import Path

import numpy as np

from epjplus_bc.data import load_fem_velocity
from epjplus_bc.train import evaluate_case4


def reevaluate(fem_path, predictions):
    grid = load_fem_velocity(fem_path)
    result = []
    with np.load(predictions, allow_pickle=False) as data:
        for key in sorted(name[:-3] for name in data.files if name.endswith("_xy")):
            metrics, _ = evaluate_case4(data[key + "_xy"], data[key + "_uv"], grid)
            experiment, model = key.split("_", 1)
            result.append(dict(experiment=experiment, model=model, points=len(data[key+"_xy"]), **metrics))
    return result


def main():
    parser = argparse.ArgumentParser(description="Reevaluate archived B/C Case IV velocities")
    parser.add_argument("--fem-reference", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / "archive/case4_velocity_predictions.npz"
    result = reevaluate(args.fem_reference, source)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
