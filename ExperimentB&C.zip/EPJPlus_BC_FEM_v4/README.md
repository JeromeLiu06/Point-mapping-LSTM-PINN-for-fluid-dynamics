# EPJPlus Experiments B/C · Case IV aligned to FEM v4

Extract the FEM data package and this package. Case IV requires the exact `levels/N256/velocity_reference_grid.npz` from the FEM package. B and C validate the same SHA-256 before training or archived prediction evaluation. Both use `[y,x]` bilinear sampling of u and v, derive speed from those components, and compute the arithmetic mean of the two componentwise relative L2 errors. Speed is reported separately. Pressure remains in the Navier–Stokes loss and is excluded from the Case IV comparison.

| Experiment | Cases | Models | Formal training steps | Case IV evaluation |
|---|---|---|---:|---|
| B | IV | `pinn`, `param`, `lstm2` | 40,000 | Native 120×120 |
| B | IV | `lstm1` | 80,000 | Native 120×120 |
| C | I–IV | `param`, `rnn`, `lstm1`, `lstm2` | 80,000 | Native 129×129 |

C loads the four bundled datasets by default. In Case IV all coordinate, window and split arrays are identical to the archived input. The historical embedded `eval_ref` was removed. B generates training points from its protocol. FEM data are for evaluation. The archive of eight historical velocity predictions contains their coordinates and unchanged predictions. `archive/provenance.json` records the source and SHA-256 of each archived prediction, and `archive/case4_metrics_on_v4.json` holds their reevaluated metrics.

From this directory, using a CUDA-capable PyTorch environment when selecting CUDA:

```powershell
$fem = '../Case4_FEM_v4/levels/N256/velocity_reference_grid.npz'
python -m epjplus_bc B --case 4 --model lstm1 --device cuda --fem-reference $fem --output runs/B4_lstm1
python -m epjplus_bc C --case 4 --model lstm2 --device cuda --fem-reference $fem --output runs/C4_lstm2
python smoke_test.py --device cuda --fem-reference $fem --output runs/smoke --check-default-batches
python reevaluate_case4.py --fem-reference $fem --output case4_metrics_on_v4.json
```

Set `$fem` to the actual extracted file. Add `--steps 2` for a short run. Supply a new output directory when using `--resume` with a checkpoint produced by this package. A Case IV run records the reference checksum in its config, predictions and metrics. See `reports/smoke_results.json` and the accompanying inventory for the verification scope.
